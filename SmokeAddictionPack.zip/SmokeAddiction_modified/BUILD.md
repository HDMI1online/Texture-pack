# Plugin bauen

Das Projekt unterstützt **zwei** Build-Systeme. Wähle eines:

## Variante A: Maven (empfohlen, einfacher)

Maven installieren falls noch nicht vorhanden:
```bash
sudo apt install maven
```

Im Projekt-Ordner:
```bash
mvn clean package
```

Fertige `.jar` liegt danach in `target/SmokeAddiction-1.0.0.jar`.

## Variante B: Gradle

Wenn du Gradle nutzen willst, hast du zwei Optionen:

**B1: System-Gradle installieren**
```bash
sudo apt install gradle
gradle build
```

**B2: Wrapper selbst erzeugen** (einmalig)

Wenn du den Wrapper für `./gradlew` willst, brauchst du Gradle einmal lokal:
```bash
sudo apt install gradle
gradle wrapper --gradle-version 8.10.2
```

Danach kannst du den System-Gradle wieder deinstallieren — der Wrapper lädt
seine eigene Version.

```bash
./gradlew build
```

Fertige `.jar` liegt danach in `build/libs/SmokeAddiction-1.0.0.jar`.

## Plugin auf den Server kopieren

```bash
cp target/SmokeAddiction-1.0.0.jar /pfad/zu/deinem/server/plugins/
# oder bei Gradle:
cp build/libs/SmokeAddiction-1.0.0.jar /pfad/zu/deinem/server/plugins/
```

Server neustarten, fertig.
