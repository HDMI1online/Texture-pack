# Resource Pack einrichten und erzwingen

Das `SmokeAddictionPack.zip` ändert nur die Custom-Items des Plugins — **alle Vanilla-Items (echtes Bambus, echtes Dried Kelp, Eimer etc.) bleiben unverändert**, weil das Pack ausschließlich `custom_model_data`-Overrides nutzt. Vanilla-Items haben keinen CMD und rendern weiter mit der Standard-Textur.

## Schritt 1: Pack hosten

Der Server kann ein Pack nur erzwingen, wenn es per **HTTPS** erreichbar ist. Du hast drei einfache Optionen:

**A) GitHub Releases** (empfohlen, kostenlos, stabil)
1. Repo erstellen, Release anlegen, `SmokeAddictionPack.zip` als Asset hochladen.
2. Direkt-URL kopieren: `https://github.com/<user>/<repo>/releases/download/v1.0/SmokeAddictionPack.zip`

**B) Eigener Webserver** (z. B. Nginx, Apache)
1. ZIP in dein Webroot legen
2. URL ist dann `https://deinedomain.tld/SmokeAddictionPack.zip`

**C) Dropbox / Google Drive**
- Funktioniert, ist aber unzuverlässig (Direktlink-Gefummel). Lieber A oder B.

## Schritt 2: SHA-1 ermitteln

Der Hash wird vom Plugin geprüft, damit der Client das Pack nicht einfach aus dem Cache lädt, wenn du es aktualisierst.

**Linux/Mac:**
```
sha1sum SmokeAddictionPack.zip
```

**Windows PowerShell:**
```
Get-FileHash SmokeAddictionPack.zip -Algorithm SHA1
```

40-stelligen Hex-String kopieren.

## Schritt 3: Plugin konfigurieren

Datei `plugins/SmokeAddiction/config.yml` öffnen und anpassen:

```yaml
resource-pack:
  enabled: true
  url: "https://github.com/dein-user/dein-repo/releases/download/v1.0/SmokeAddictionPack.zip"
  hash: "47275f6ceb4367abf1bef946a0e4dd71e668e0fe"   # dein SHA-1
  prompt: "Dieses Resource Pack ist für das Rauch-System erforderlich."
  delay-ticks: 20
```

`/reload confirm` oder Server-Restart. Beim nächsten Login wird das Pack erzwungen.

## Schritt 4 (optional): Auch `server.properties` setzen

Zusätzlich kannst du in `server.properties`:
```
resource-pack=https://github.com/.../SmokeAddictionPack.zip
resource-pack-sha1=47275f6ceb4367abf1bef946a0e4dd71e668e0fe
require-resource-pack=true
resource-pack-prompt=SmokeAddiction Pack erforderlich
```

Das Plugin macht das aber bereits — beides gleichzeitig kann zu doppelten Prompts führen. **Eines reicht.**

## Verhalten beim Login

- Spieler bekommt den Pack-Prompt mit der Option "Akzeptieren" oder "Abbrechen".
- Bei "Akzeptieren": Pack wird heruntergeladen (~30 KB), alle Custom-Items rendern mit den neuen Texturen.
- Bei "Abbrechen": Spieler wird gekickt (`Du musst das Resource Pack akzeptieren, um zu spielen.`).
- Bei Download-Fehler: Spieler wird gekickt mit Hinweis zum erneuten Verbinden.

## Was du bei Updates beachten musst

Wenn du Texturen änderst:
1. ZIP neu packen (wichtig: Inhalt von `SmokeAddictionPack/`, nicht den Ordner selbst).
2. Neue SHA-1 berechnen.
3. ZIP an dieselbe URL hochladen (oder neue URL setzen).
4. `config.yml` mit neuem Hash aktualisieren.
5. `/reload confirm` — beim nächsten Login wird der Client das neue Pack laden, weil der alte Cache-Hash nicht mehr passt.

## Troubleshooting

- **Spieler sieht Vanilla-Items statt Custom-Texturen:** Pack wurde nicht akzeptiert oder Download fehlgeschlagen. Server-Log und Client-Log prüfen (`%appdata%\.minecraft\logs\latest.log`).
- **`Hash mismatch`-Fehler:** Hash in der config stimmt nicht mit dem File überein. Neu berechnen.
- **Manche Items haben keine Custom-Texture:** Wahrscheinlich wurde `custom_model_data` beim Item-Crafting nicht gesetzt — das Plugin macht das automatisch, aber wenn du selbst Items per Befehl gibst, mit `/sa give …`. Vanilla-`/give` setzt kein CMD.
