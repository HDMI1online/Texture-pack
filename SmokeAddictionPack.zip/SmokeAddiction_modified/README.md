# SmokeAddiction

Realistisches Rauchsucht-System für Paper **1.21.1**.

## Features

- 5 Suchtstufen (1 = stärkste, 5 = schwächste)
- Nikotin-Leiste als BossBar (das Bukkit-API erlaubt keine echte Custom-Leiste unter der Hungerbar; BossBar ist die saubere Alternative)
- 5 Marken: Marlboro, Lucky Strike, Camel, Winston, L&M
- Schachteln (8 Zigaretten, stack 64) als platzierbare Blöcke (über unsichtbare ArmorStands)
- Zigaretten (stack 8), 45 s Rauchvorgang mit BossBar-Fortschritt, Lagerfeuer-Rauchpartikel bis 3 Blöcke nach oben
- Feuerzeug in Offhand erforderlich, verliert Haltbarkeit
- Speed-Effekt skaliert mit Nikotin (max. Speed IV)
- Ab Stufe 2: extrem schneller Sauerstoffverlust unter Wasser
- Entzug: Hungerverlust bis 3 Balken, 20 Min durchhalten = Stufe sinkt
- Vapes (Elfbar): 60 Züge, 7 Sorten/Farben, +0.5 Nikotin pro Zug
- Persistente Speicherung pro Spieler (YAML)
- Kein Nikotinverlust beim Logout

## Bauen

```bash
./gradlew build
# Ergebnis: build/libs/SmokeAddiction-1.0.0.jar
```

> Paper 1.21.1 benötigt Java 21. Stelle sicher, dass `JAVA_HOME` auf JDK 21 zeigt.

JAR nach `plugins/` kopieren und Server starten.

## Tabakanbau & Trocknen

Tabak wächst wild in **Jungle** (Jungle, Sparse Jungle, Bamboo Jungle) und **Sumpf-Biomen** (Swamp, Mangrove Swamp). Optisch sind das Sweet-Berry-Bushes mit angepassten Drops.

- **Naturspawn:** Beim Generieren neuer Chunks in Tabak-Biomen werden Patches von 3–7 Pflanzen verstreut.
- **Anbauen:** Tabaksamen auf Gras / Erde / Mud rechtsklicken — funktioniert nur in Tabak-Biomen.
- **Ernten:** Rechtsklick auf reife Pflanze (Stage 3) → 1–3 **frische** Tabakblätter + ggf. Samen, Pflanze fällt auf Stage 1 zurück.
- **Brechen:** Samen + bei reifer Pflanze auch frische Blätter.

**Trocknen:** Frischer Tabak (Tabakblatt frisch) muss im **Ofen** getrocknet werden, um daraus Zigaretten oder Shisha-Inhalt zu machen. Die Furnace-Recipe nutzt `RecipeChoice.ExactChoice`, sodass nur unser PDC-getaggter Rohtabak getrocknet wird – Vanilla-Zuckerrohr im Ofen tut nichts. Trockenzeit: 10 Sekunden (200 Ticks, wie Standard-Smelting), Erfahrung: 0.2.

### Crafting

Selbstgedrehte Zigarette in der Werkbank (shapeless):

```
3× Tabakblatt + 2× Papier  →  1× Selbstgedrehte Zigarette
```

Vanilla-Dried-Kelp wird **nicht** als Tabak akzeptiert (PDC-Check). Die selbstgedrehte Zigarette funktioniert wie jede andere Marken-Zigarette.

## Dorf-Händler

In jedem Dorf werden automatisch zwei Händler gespawnt, sobald ein Spieler in die Nähe der Glocke (Dorfzentrum) kommt:

**Zigaretten-Verkäufer** (Farmer-Beruf, goldener Name):
- 5× Tabakblatt = 10 Smaragde
- 1× Tabaksamen = 4 Smaragde
- 1× Schachtel jeder Marke = 16–29 Smaragde (zufällig pro Trade-Slot)
- 1× Feuerzeug = 6 Smaragde

**Vape-Verkäufer** (Cleric-Beruf, lila Name):
- 1× Elfbar in jeder Sorte = 16–24 Smaragde (zufällig pro Trade-Slot)

Beide Händler sind **invulnerable** und persistent – sie verschwinden nicht und können nicht getötet werden. Glocken werden per PDC markiert, damit die Händler nur einmal pro Dorf gespawnt werden.

## Shisha (Hookah)

Shisha als platzierbarer Block (intern unsichtbarer ArmorStand mit End-Rod auf dem Kopf).

**Crafting** (shapeless, 4 Zutaten → 2 Shishas):
- 1× Drachenei
- 1× Eimer
- 1× Endstab
- 1× Seltsamer Trank (Mundane Potion – wird per `PotionType` validiert)

Shishas sind nicht stapelbar (Maximalstack 1).

**Bedienung:**
- **Rechtsklick auf Block** mit Shisha im Inventar → platzieren
- **Sneak + Rechtsklick** auf Shisha → Inventar öffnen (Tabak + Wasser einfüllen)
- **Rechtsklick** auf Shisha → 30-Sekunden-Sitzung starten (BossBar zeigt Fortschritt)
- **Sneak während Sitzung** → abbrechen
- **Linksklick mit Netherit-Spitzhacke** → Shisha als Item zurück (andere Werkzeuge funktionieren nicht)

**Befüllen:**
Eine Tabak-Füllung (1 Tabakblatt) reicht für 5 Sitzungen. Wasser (1 Wassereimer, gibt leeren Eimer zurück) hält bis der Tabak aufgebraucht ist.

**Effekte einer Sitzung:**
- Nikotin auf 10 (Maximum, höher als Zigarette)
- 30 s Locator-Effekt: nahe Spieler werden via `GLOWING` markiert; Action-Bar zeigt Distanz zum nächsten
- Erstmaliger Zug → server-weiter Broadcast „<Spieler> hat zum ersten Mal an einer Shisha gezogen!"
- Bystander im Rauchradius (~6 Blöcke) bekommen passiv leicht Nikotin

**Optik:** Mehrlagige Partikel (CLOUD + CAMPFIRE_COSY_SMOKE + getönte DUST + LARGE_SMOKE) für sehr dichte, weit nach oben aufsteigende Rauchwolken.

> **Hinweis zur Nikotin-Skala:** Mit Einführung der Shisha ist das Nikotin-Maximum von 8 auf 10 angehoben. Zigaretten geben weiterhin +8 (~80 % der Leiste), Shisha füllt komplett auf 10.

## Fumot 12k (Premium-Vape)

Eine spezielle Vape im Stil der **Fumot Tornado Digital Box 12000**. Wird **nicht** verkauft, nur per `/sa give fumot` ausgegeben.

**Werte:**
- 120 Züge Lifetime (nicht wiederbefüllbar)
- 100 % Akku, der pro Zug 1 % verliert
- Pro Zug: -1 % Akku **und** -1 Liquid-Zug
- Pro Zug: +0.5 Nikotin (wie Standard-Vape)

**Anzeige (immer sichtbar im Hotbar-Tooltip):**
- Item-Name: `Fumot 12k │ 75% │ 95Z` mit farbigem Status
- Lore zeigt ASCII-Bars:
  ```
  Akku:  [######....]  75%
  Züge:  [#######...]  95/120
  ```
- Wird beim Konsum bzw. Laden in Echtzeit aktualisiert.

**Aufladen:**
- Wenn der Akku leer ist, **Item droppen** (Q-Taste) auf den Boden in der Nähe einer **aktiven Redstone-Quelle** (Redstone-Block, gepowerte Leitung, gedrückter Knopf/Hebel, aktiver Repeater/Comparator).
- Erkennungsradius: 1 Block in jede Richtung um das Item.
- Ladegeschwindigkeit: **1 % alle 12 Sekunden = 10 % alle 2 Minuten**.
- Während des Ladens: Funken-Partikel + Status `Lädt 50%` im Item-Namen + leise Klicks.
- Bei 100 %: lauter Beacon-Sound, grüne Happy-Villager-Partikel, Status `VOLL geladen!` in Grün.

**Wichtig:** Akku kann unbegrenzt oft geladen werden, **Liquid-Züge nicht**. Nach 120 Gesamt-Zügen ist die Vape permanent leer (Status `AUFGEBRAUCHT`).

## Befehle

| Befehl | Beschreibung |
|---|---|
| `/sa give cigarette <marke> [anzahl]` | Zigarette(n) geben |
| `/sa give pack <marke> [füllung]` | Schachtel geben |
| `/sa give vape <flavor>` | Elfbar geben |
| `/sa give lighter` | Feuerzeug geben |
| `/sa give tobacco [anzahl]` | Tabakblätter geben |
| `/sa give seeds [anzahl]` | Tabaksamen geben |
| `/sa give shisha [anzahl]` | Shisha geben |
| `/sa give fumot` | Fumot 12k geben (Premium-Vape, nicht käuflich) |
| `/sa spawnvendor <cigarette\|vape>` | Verkäufer manuell spawnen |
| `/sa refresh` | Trades aller Händler in 16 Blöcken neu auswürfeln |
| `/sa status [spieler]` | Sucht-Status anzeigen |
| `/sa reset [spieler]` | Sucht-Daten zurücksetzen |

Marken: `MARLBORO`, `LUCKY_STRIKE`, `CAMEL`, `WINSTON`, `L_AND_M`
Flavors: `BLUE_RAZZ`, `WATERMELON`, `MANGO_ICE`, `GRAPE`, `APPLE_PEACH`, `COTTON_CANDY`, `MENTHOL`

## Permissions

- `smokeaddiction.use` – Standard, jeder darf das System nutzen
- `smokeaddiction.admin` – darf `give` und `reset`

## Bedienung im Spiel

**Schachtel als Block:**
- Schachtel in Hand + Rechtsklick auf Block → platzieren
- Linksklick auf platzierte Schachtel → Zigarette entnehmen
- Rechtsklick auf platzierte Schachtel mit passender Zigarette → zurücklegen
- Sneak + Linksklick auf platzierte Schachtel → als Item zurückbekommen

**Rauchen:**
- Zigarette in Haupthand
- Feuerzeug (oder vanilla Flint and Steel) in Offhand
- Rechtsklick → 45 s Rauchvorgang startet
- Während des Vorgangs: kein Drop, kein Slot-Wechsel, kein Hand-Swap

**Vape:**
- Elfbar in Hand → Rechtsklick = Zug nehmen (Cooldown 1.5 s)

## Hinweise

- `BossBar` wird genutzt, weil Bukkit/Paper keine API hat, um eine eigene HUD-Leiste direkt unter der Hungerbar zu rendern. Das wäre nur per Resourcepack/clientseitigem Mod möglich.
- Die Schachtel als „Block“ ist ein unsichtbarer ArmorStand mit dem Schachtel-Item auf dem Kopf — das ist Standardpraxis für Custom-Blöcke ohne Resourcepack/Block-States.
