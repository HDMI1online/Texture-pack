package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.*;

/**
 * Verwaltet die Sidebar-Scoreboard-Anzeige mit Kills & Toden aller Spieler.
 *
 * Layout (Sidebar, links im HUD):
 *   ════════════
 *   💀 SmokeAddiction
 *   ────────────
 *   SpielerA  K:5 T:2
 *   SpielerB  K:1 T:8
 *   ...
 *
 * Global an/aus: config.yml scoreboard.enabled (default: true)
 * Pro Spieler:   /sa scoreboard hide|show
 *
 * Kills = PvP-Kills an anderen Spielern.
 * Tode  = alle Todesursachen.
 */
public class SaScoreboardManager {

    private static final String OBJ_NAME = "sa_kd";

    private final SmokeAddictionPlugin plugin;
    private org.bukkit.scoreboard.Scoreboard board;
    private Objective sidebarObj;
    private int frame = 0;
    private static final String[] TITLE_FRAMES = {
        "§6§l⚡ Rangliste ⚡", "§e§l⚡ Rangliste ⚡", "§6§l⚡ Rangliste ⚡"
    };

    public SaScoreboardManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        rebuild();
    }

    private void rebuild() {
        board = Bukkit.getScoreboardManager().getNewScoreboard();
        sidebarObj = board.registerNewObjective(OBJ_NAME, Criteria.DUMMY,
                Component.text("⚡ Rangliste ⚡", NamedTextColor.GOLD)
                        .decoration(TextDecoration.BOLD, true));
        sidebarObj.setDisplaySlot(DisplaySlot.SIDEBAR);
    }

    // ─── Öffentliche API ─────────────────────────────────────────────

    /** Aktualisiert Anzeige für alle Spieler und rotiert den Titel. */
    public void update() {
        if (!isGloballyEnabled()) return;

        // Animierter Titel
        sidebarObj.displayName(Component.text(TITLE_FRAMES[frame % TITLE_FRAMES.length]));
        frame++;

        // Alle Online-Spieler: Score = Kills (sinkend → höchste zuerst)
        // Minecraft Sidebar zeigt höchste Scores oben an.
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        // Leere Einträge raus (Spieler die nicht mehr online sind)
        for (String entry : new HashSet<>(board.getEntries())) {
            boolean stillOnline = players.stream().anyMatch(p -> p.getName().equals(entry));
            if (!stillOnline) {
                board.resetScores(entry);
            }
        }

        // Setze Kills-Scores. Wir nutzen den Score-Wert als Anzeigekennzahl;
        // der eigentliche Text-Entry enthält Name + Stats.
        // Um Reihenfolge und Text zu steuern nutzen wir Team-Prefixes.
        int rank = players.size();
        // Sortiere: meiste Kills zuerst, bei Gleichstand weniger Tode zuerst
        players.sort((a, b) -> {
            int ka = getKills(a), kb = getKills(b);
            if (ka != kb) return kb - ka;
            return getDeaths(a) - getDeaths(b);
        });

        for (Player p : players) {
            String entry = p.getName();
            // Score = Kills (Sidebar sortiert absteigend nach Wert)
            Score score = sidebarObj.getScore(entry);
            score.setScore(getKills(p));

            // Team für Prefix/Suffix (Name + Stats daneben)
            Team team = board.getTeam("sa_" + p.getName());
            if (team == null) {
                team = board.registerNewTeam("sa_" + p.getName());
                team.addEntry(entry);
            }
            team.prefix(Component.text("§7K:" + getKills(p) + " §cT:" + getDeaths(p) + "  "));
        }

        // Scoreboard an alle sichtbaren Spieler senden, Hauptboard für versteckte
        for (Player p : players) {
            boolean hidden = plugin.getPlayerDataManager().get(p).isScoreboardHidden();
            if (hidden) {
                p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            } else {
                p.setScoreboard(board);
            }
        }
    }

    /** Spieler einloggt: Scoreboard zuweisen (oder Haupt-Board wenn versteckt). */
    public void onJoin(Player p) {
        if (!isGloballyEnabled()) return;
        boolean hidden = plugin.getPlayerDataManager().get(p).isScoreboardHidden();
        p.setScoreboard(hidden ? Bukkit.getScoreboardManager().getMainScoreboard() : board);
    }

    /** Spieler ausloggt: Haupt-Board zurücksetzen. */
    public void onQuit(Player p) {
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    /** PvP-Kill eines Spielers registrieren. */
    public void addKill(Player killer) {
        PlayerData d = plugin.getPlayerDataManager().get(killer);
        d.setPvpKills(d.getPvpKills() + 1);
    }

    /** Zeigt oder versteckt das Scoreboard für diesen Spieler. */
    public void setHidden(Player p, boolean hidden) {
        plugin.getPlayerDataManager().get(p).setScoreboardHidden(hidden);
        p.setScoreboard(hidden
                ? Bukkit.getScoreboardManager().getMainScoreboard()
                : board);
    }

    public boolean isGloballyEnabled() {
        return plugin.getConfig().getBoolean("scoreboard.enabled", true);
    }

    // ─── Hilfsmethoden ────────────────────────────────────────────────

    private int getKills(Player p) {
        return plugin.getPlayerDataManager().get(p).getPvpKills();
    }

    private int getDeaths(Player p) {
        return plugin.getPlayerDataManager().get(p).getTotalDeaths();
    }
}
