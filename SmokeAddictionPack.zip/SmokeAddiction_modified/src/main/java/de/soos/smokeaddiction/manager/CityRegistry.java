package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Speichert die Locations bereits generierter Städte, damit nicht zwei Cities
 * zu nahe beieinander entstehen.
 */
public class CityRegistry {

    /** Mindestabstand zwischen zwei Stadtzentren (in Blöcken). */
    public static final double MIN_DISTANCE = 1500.0;

    private final SmokeAddictionPlugin plugin;
    private final File file;
    private final List<Location> cities = new ArrayList<>();

    public CityRegistry(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "cities.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        List<?> raw = cfg.getList("cities", new ArrayList<>());
        if (raw == null) return;
        for (Object o : raw) {
            if (!(o instanceof java.util.Map<?, ?> map)) continue;
            try {
                String worldName = String.valueOf(map.get("world"));
                int x = ((Number) map.get("x")).intValue();
                int y = ((Number) map.get("y")).intValue();
                int z = ((Number) map.get("z")).intValue();
                World w = Bukkit.getWorld(worldName);
                if (w != null) {
                    cities.add(new Location(w, x, y, z));
                } else {
                    // Welt evtl. noch nicht geladen; wir speichern Location ohne Welt-Ref
                    UUID uuid = UUID.fromString(String.valueOf(map.get("worldUid")));
                    World w2 = Bukkit.getWorld(uuid);
                    if (w2 != null) cities.add(new Location(w2, x, y, z));
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("Konnte City-Eintrag nicht laden: " + ex.getMessage());
            }
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<java.util.Map<String, Object>> list = new ArrayList<>();
        for (Location loc : cities) {
            java.util.Map<String, Object> map = new java.util.LinkedHashMap<>();
            map.put("world", loc.getWorld() != null ? loc.getWorld().getName() : "unknown");
            map.put("worldUid", loc.getWorld() != null ? loc.getWorld().getUID().toString() : "");
            map.put("x", loc.getBlockX());
            map.put("y", loc.getBlockY());
            map.put("z", loc.getBlockZ());
            list.add(map);
        }
        cfg.set("cities", list);
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Konnte cities.yml nicht speichern", e);
        }
    }

    /** Prüft ob in der Nähe der gegebenen Location bereits eine Stadt existiert. */
    public boolean isCityNearby(Location loc) {
        for (Location c : cities) {
            if (c.getWorld() != loc.getWorld()) continue;
            if (c.distanceSquared(loc) < MIN_DISTANCE * MIN_DISTANCE) return true;
        }
        return false;
    }

    public void register(Location loc) {
        cities.add(loc.clone());
        save();
    }

    public List<Location> getCities() { return cities; }
}
