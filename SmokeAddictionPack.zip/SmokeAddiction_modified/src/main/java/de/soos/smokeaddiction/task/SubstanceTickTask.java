package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tickt jede Sekunde, um Substanz-Phasen-Übergänge auf jedem Online-Spieler zu prüfen.
 */
public class SubstanceTickTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public SubstanceTickTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getSubstanceManager().tick(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Substance-Tick-Fehler für " + p.getName()
                        + ": " + ex.getMessage());
            }
        }
    }
}
