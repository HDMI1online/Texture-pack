package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Verarbeitet das Trinken von Monster White (sofortiger Konsum wie Bier/Jäger,
 * kein Halten nötig – siehe {@link AlcoholListener} für das gleiche Grundmuster).
 */
public class MonsterListener implements Listener {

    private static final long COOLDOWN_MS = 1000L;

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, Long> lastDrink = new HashMap<>();

    public MonsterListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item == null) return;
        ItemManager im = plugin.getItemManager();
        if (!im.isMonsterWhite(item)) return;

        if (e.getAction() == Action.RIGHT_CLICK_BLOCK
                && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.ENCHANTING_TABLE) return;

        e.setCancelled(true);
        e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);

        long now = System.currentTimeMillis();
        long last = lastDrink.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < COOLDOWN_MS) return;
        lastDrink.put(p.getUniqueId(), now);

        p.swingMainHand();
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.8f, 1.4f);
        consumeOne(p);
        plugin.getMonsterManager().onConsume(p);
    }

    /** Vanilla-Consume komplett abfangen, um Honey-Bottle-Effekte zu verhindern. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        ItemStack item = e.getItem();
        if (item == null) return;
        if (plugin.getItemManager().isMonsterWhite(item)) {
            e.setCancelled(true);
        }
    }

    private void consumeOne(Player p) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null) return;
        int amt = hand.getAmount();
        if (amt <= 1) {
            p.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(amt - 1);
        }
    }
}
