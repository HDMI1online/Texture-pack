package de.soos.smokeaddiction.model;

import org.bukkit.Color;

/**
 * Bekannte Zigarettenmarken. Farben werden für die Schachtel-Optik (Lederrüstung-Tönung)
 * und Anzeigenamen genutzt.
 */
public enum CigaretteBrand {

    MARLBORO("Marlboro",  Color.fromRGB(200,  30,  30)),
    LUCKY_STRIKE("Lucky Strike", Color.fromRGB(220,  20,  20)),
    CAMEL("Camel",     Color.fromRGB(210, 180,  90)),
    WINSTON("Winston",   Color.fromRGB( 30,  30, 200)),
    L_AND_M("L&M",       Color.fromRGB( 30, 130,  60)),
    SELFMADE("Selbstgedreht", Color.fromRGB(110,  70,  40)),
    HERB_JOINT("Joint",  Color.fromRGB( 80, 150,  60)),
    RAUCHZUCKER_CIG("Crack-Zigarette", Color.fromRGB(220, 200, 80)),
    LEAF_CIG("Leaf-Zigarette", Color.fromRGB(60, 130, 50));

    private final String displayName;
    private final Color color;

    CigaretteBrand(String displayName, Color color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() { return displayName; }
    public Color getColor()        { return color; }

    public static CigaretteBrand fromName(String name) {
        if (name == null) return MARLBORO;
        for (CigaretteBrand b : values()) {
            if (b.name().equalsIgnoreCase(name)) return b;
        }
        return MARLBORO;
    }
}
