package de.soos.smokeaddiction.util;

import org.bukkit.Bukkit;
import org.bukkit.inventory.meta.ItemMeta;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Cross-Version-Helper für Custom Model Data.
 *
 * Setzt sowohl strings als auch floats in der CustomModelDataComponent (1.21.4+),
 * damit sowohl 'select' als auch 'range_dispatch' Matching im Resource Pack
 * funktioniert. Fällt bei alten Servern auf den Legacy-Integer-Setter zurück.
 */
public final class CustomModelDataHelper {

    private CustomModelDataHelper() {}

    private static final AtomicBoolean DIAG_LOGGED = new AtomicBoolean(false);

    public static void apply(ItemMeta meta, int cmdValue) {
        if (meta == null) return;

        boolean newApiSucceeded = false;
        String diagPath = "none";
        Throwable lastErr = null;
        try {
            Method getComp = meta.getClass().getMethod("getCustomModelDataComponent");
            Object comp = getComp.invoke(meta);
            if (comp != null) {
                try {
                    Method setStrings = comp.getClass().getMethod("setStrings", List.class);
                    setStrings.invoke(comp, Collections.singletonList(String.valueOf(cmdValue)));
                    diagPath = "strings";
                } catch (Throwable t) { lastErr = t; }

                try {
                    Method setFloats = comp.getClass().getMethod("setFloats", List.class);
                    setFloats.invoke(comp, Collections.singletonList((float) cmdValue));
                    diagPath = diagPath.equals("none") ? "floats" : diagPath + "+floats";
                } catch (Throwable t) { lastErr = t; }

                Method setComp = meta.getClass().getMethod("setCustomModelDataComponent",
                        Class.forName("org.bukkit.inventory.meta.components.CustomModelDataComponent"));
                setComp.invoke(meta, comp);
                newApiSucceeded = true;
            }
        } catch (Throwable t) { lastErr = t; }

        if (!newApiSucceeded) {
            try {
                meta.setCustomModelData(cmdValue);
                diagPath = "legacy-int";
            } catch (Throwable t) { lastErr = t; }
        }

        // Einmalig loggen wie's gelaufen ist (nur beim ersten Item)
        if (DIAG_LOGGED.compareAndSet(false, true)) {
            String msg = "[SmokeAddiction] CustomModelData mode: " + diagPath
                    + " (cmdValue=" + cmdValue + ", newApi=" + newApiSucceeded + ")";
            if (lastErr != null) msg += " lastError=" + lastErr.getClass().getSimpleName()
                    + ": " + lastErr.getMessage();
            try {
                Bukkit.getLogger().info(msg);
            } catch (Throwable ignored) {
                System.out.println(msg);
            }
        }
    }
}
