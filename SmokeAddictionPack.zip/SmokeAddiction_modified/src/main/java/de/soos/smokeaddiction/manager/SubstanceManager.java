package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.SubstanceType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Zentraler Manager für alle Custom-Substanzen.
 *
 * Pro Spieler werden zwei Phasen-Timer pro Substanz gespeichert:
 *   - effectUntil:    Hauptwirkung läuft bis zu diesem Zeitpunkt
 *   - withdrawalUntil:Nach Hauptwirkung läuft Entzug bis zu diesem Zeitpunkt
 *
 * Alle Phasen-Übergänge werden vom SubstanceTickTask jede Sekunde geprüft.
 *
 * Persistenz: Wirkungs- und Entzugs-Deadlines werden beim Logout in PlayerData
 * gesichert und beim nächsten Login wiederhergestellt (siehe restoreFromPlayerData/
 * persistToPlayerData), damit ein Rejoin Effekte und Entzüge nicht mehr löscht.
 */
public class SubstanceManager {

    /** Pro-Spieler-Status. */
    public static class State {
        public SubstanceType active;
        public long effectUntil;       // 0 = kein Effekt
        public long withdrawalUntil;   // 0 = kein Withdrawal
        public long effectStartedAt;   // Zeitpunkt des Konsums (für Bar-Progress)
        public long withdrawalStartedAt; // Zeitpunkt des Withdrawal-Beginns
        public GameMode previousGameMode; // für Magikzucker-Restore
        public boolean magikzuckerWasActive; // für Drop-Logik im BlockBreakListener
        // Eine BossBar pro Substanz-Slot (Wirkung + Entzug je eigene Bar)
        public final java.util.EnumMap<SubstanceType, net.kyori.adventure.bossbar.BossBar> effectBars
                = new java.util.EnumMap<>(SubstanceType.class);
        public final java.util.EnumMap<SubstanceType, net.kyori.adventure.bossbar.BossBar> withdrawalBars
                = new java.util.EnumMap<>(SubstanceType.class);
        // Aktiver Effekt + Withdrawal können UNTERSCHIEDLICHE Substanzen sein
        // (z.B. LSD-Wirkung läuft noch, während Crack-Entzug bereits begonnen hat)
        // Wir speichern deshalb effectUntil/withdrawalUntil/effectStartedAt pro Substanz:
        public final java.util.EnumMap<SubstanceType, Long> perEffectUntil
                = new java.util.EnumMap<>(SubstanceType.class);
        public final java.util.EnumMap<SubstanceType, Long> perWithdrawalUntil
                = new java.util.EnumMap<>(SubstanceType.class);
        public final java.util.EnumMap<SubstanceType, Long> perEffectStartedAt
                = new java.util.EnumMap<>(SubstanceType.class);
        public final java.util.EnumMap<SubstanceType, Long> perWithdrawalStartedAt
                = new java.util.EnumMap<>(SubstanceType.class);
    }

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, State> states = new HashMap<>();

    public SubstanceManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public State getState(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> {
            State s = new State();
            restoreFromPlayerData(p, s);
            return s;
        });
    }

    /**
     * Liest beim ersten Zugriff (typischerweise Login) gespeicherte Wirkungs-/
     * Entzugs-Deadlines aus {@link de.soos.smokeaddiction.model.PlayerData} und
     * übernimmt nur noch nicht abgelaufene Einträge in den frischen State.
     * Dadurch überleben aktive Substanz-Effekte UND Entzüge einen Rejoin –
     * der nächste SubstanceTickTask-Durchlauf (max. 1s später) zeigt BossBar
     * und Effekte automatisch wieder an.
     */
    private void restoreFromPlayerData(Player p, State s) {
        var d = plugin.getPlayerDataManager().get(p);
        long now = System.currentTimeMillis();
        for (var e : d.getSubstanceEffectUntilMap().entrySet()) {
            if (e.getValue() != null && e.getValue() > now) {
                s.perEffectUntil.put(e.getKey(), e.getValue());
                // Startzeitpunkt unbekannt (Server-Neustart/Rejoin) -> "jetzt" als Basis,
                // sorgt nur für eine kurzzeitig leicht ungenaue Fortschrittsanzeige,
                // die eigentliche Deadline bleibt exakt korrekt.
                s.perEffectStartedAt.put(e.getKey(), now);
            }
        }
        for (var e : d.getSubstanceWithdrawalUntilMap().entrySet()) {
            if (e.getValue() != null && e.getValue() > now) {
                s.perWithdrawalUntil.put(e.getKey(), e.getValue());
                s.perWithdrawalStartedAt.put(e.getKey(), now);
            }
        }
    }

    /**
     * Schreibt die aktuellen Wirkungs-/Entzugs-Deadlines in PlayerData, damit sie
     * beim nächsten Login wiederhergestellt werden können. Wird vom PlayerListener
     * beim Logout VOR dem Entladen aufgerufen.
     */
    public void persistToPlayerData(Player p) {
        State s = states.get(p.getUniqueId());
        var d = plugin.getPlayerDataManager().get(p);
        d.getSubstanceEffectUntilMap().clear();
        d.getSubstanceWithdrawalUntilMap().clear();
        if (s == null) return;
        long now = System.currentTimeMillis();
        for (var e : s.perEffectUntil.entrySet()) {
            if (e.getValue() != null && e.getValue() > now) {
                d.getSubstanceEffectUntilMap().put(e.getKey(), e.getValue());
            }
        }
        for (var e : s.perWithdrawalUntil.entrySet()) {
            if (e.getValue() != null && e.getValue() > now) {
                d.getSubstanceWithdrawalUntilMap().put(e.getKey(), e.getValue());
            }
        }
    }

    public void unload(UUID id) {
        org.bukkit.entity.Player p = plugin.getServer().getPlayer(id);
        if (p != null) clearRainbowTeam(p);
        State s = states.get(id);
        if (s != null && p != null) {
            s.effectBars.values().forEach(p::hideBossBar);
            s.withdrawalBars.values().forEach(p::hideBossBar);
            s.effectBars.clear();
            s.withdrawalBars.clear();
        }
        states.remove(id);
    }

    // ============================================================
    // 1. MAGIKZUCKER – kann alles abbauen, danach Adventure Mode
    // ============================================================
    public void applyMagikzucker(Player p) {
        State s = getState(p);
        long now = System.currentTimeMillis();

        // Falls noch Adventure-Mode-Entzug vom letzten Konsum aktiv ist: aufheben
        if (p.getGameMode() == GameMode.ADVENTURE) {
            GameMode restore = s.previousGameMode != null ? s.previousGameMode : GameMode.SURVIVAL;
            p.setGameMode(restore);
            s.previousGameMode = null;
        }
        net.kyori.adventure.bossbar.BossBar oldWit = s.withdrawalBars.remove(SubstanceType.MAGIKZUCKER);
        if (oldWit != null) p.hideBossBar(oldWit);
        s.perWithdrawalUntil.put(SubstanceType.MAGIKZUCKER, 0L);

        // Dauer 3-5 Min
        int seconds = ThreadLocalRandom.current().nextInt(3 * 60, 5 * 60 + 1);
        s.active = SubstanceType.MAGIKZUCKER;
        s.effectStartedAt = now;
        s.effectUntil = now + (long) seconds * 1000L;
        s.withdrawalUntil = s.effectUntil + 5L * 60L * 1000L;
        // Per-Substanz-Tracking für Multi-BossBar
        s.perEffectStartedAt.put(SubstanceType.MAGIKZUCKER, now);
        s.perEffectUntil.put(SubstanceType.MAGIKZUCKER, s.effectUntil);
        s.perWithdrawalUntil.put(SubstanceType.MAGIKZUCKER, s.withdrawalUntil);
        s.magikzuckerWasActive = true;

        // (Adventure-Mode-Restore passiert bereits oben vor dem Neu-Setzen der Werte)

        // Ultra-Haste: Effekt 255 (max) für instant-mining auf normalen Blöcken.
        p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,
                seconds * 20, 254, true, true, true));

        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_BREATH, 1.0f, 1.8f);
        p.getWorld().spawnParticle(Particle.WHITE_ASH,
                p.getEyeLocation().add(0, 0.1, 0),
                30, 0.2, 0.1, 0.2, 0.05);
        p.sendMessage(Component.text("Kokain geschnupft!", NamedTextColor.LIGHT_PURPLE));
        p.sendMessage(Component.text("Du baust jetzt alles in 1 Klick ab für "
                + (seconds / 60) + " Min " + (seconds % 60) + " s.",
                NamedTextColor.GRAY));
    }

    /** Wird vom Tick aufgerufen, wenn Magikzucker abläuft. */
    private void endMagikzucker(Player p, State s) {
        // Haste entfernen
        p.removePotionEffect(PotionEffectType.HASTE);
        // Adventure als Withdrawal: kann nichts mehr abbauen
        if (p.getGameMode() == GameMode.SURVIVAL) {
            s.previousGameMode = p.getGameMode();
            p.setGameMode(GameMode.ADVENTURE);
        }
        p.sendMessage(Component.text("Der Kokain-Rausch klingt ab.",
                NamedTextColor.GOLD));
        p.sendMessage(Component.text("5 Minuten Adventure-Mode als Entzug.",
                NamedTextColor.RED));
    }

    private void endMagikzuckerWithdrawal(Player p, State s) {
        if (p.getGameMode() == GameMode.ADVENTURE) {
            GameMode restore = s.previousGameMode != null ? s.previousGameMode : GameMode.SURVIVAL;
            p.setGameMode(restore);
        }
        s.previousGameMode = null;
        s.magikzuckerWasActive = false;
        p.sendMessage(Component.text("Der Entzug ist vorbei.", NamedTextColor.GREEN));
    }

    // ============================================================
    // 2. TABLETTE – Stärke 10 für 10 Min, danach Schwäche 3 für 5 Min
    // ============================================================
    public void applyTablette(Player p) {
        State s = getState(p);
        long now = System.currentTimeMillis();

        // Falls noch eine Schwäche-Nachwirkung vom letzten Trip aktiv ist:
        // entfernen, da der neue Konsum den Entzug überschreibt.
        p.removePotionEffect(PotionEffectType.WEAKNESS);
        net.kyori.adventure.bossbar.BossBar oldWit = s.withdrawalBars.remove(SubstanceType.TABLETTE);
        if (oldWit != null) p.hideBossBar(oldWit);
        s.perWithdrawalUntil.put(SubstanceType.TABLETTE, 0L);

        s.active = SubstanceType.TABLETTE;
        s.effectStartedAt = now;
        s.effectUntil = now + 10L * 60L * 1000L;
        s.withdrawalUntil = s.effectUntil + 5L * 60L * 1000L;
        // Per-Substanz-Tracking für Multi-BossBar
        s.perEffectStartedAt.put(SubstanceType.TABLETTE, now);
        s.perEffectUntil.put(SubstanceType.TABLETTE, s.effectUntil);
        s.perWithdrawalUntil.put(SubstanceType.TABLETTE, s.withdrawalUntil);

        // Strength II = amplifier 1 → +3 zusätzlicher Schaden pro Hit (1.21 Vanilla-Skalierung).
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH,
                10 * 60 * 20, 1, true, true, true));

        // Glowing für 10 Min – die Color cyclet der Tick-Task durch alle Regenbogenfarben
        p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                10 * 60 * 20, 0, true, false, false));

        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0f, 1.4f);
        p.sendMessage(Component.text("LSD geschluckt!", NamedTextColor.AQUA));
        p.sendMessage(Component.text("+3 Schaden für 10 Min.",
                NamedTextColor.GRAY));
    }

    private void endTablette(Player p, State s) {
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.GLOWING);
        clearRainbowTeam(p);
        // Schwäche 3 (= amplifier 2)
        p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,
                5 * 60 * 20, 2, true, true, true));
        p.sendMessage(Component.text("Das LSD wirkt nicht mehr.",
                NamedTextColor.GOLD));
        p.sendMessage(Component.text("5 Min Schwäche III als Nachwirkung.",
                NamedTextColor.RED));
    }

    private void endTabletteWithdrawal(Player p, State s) {
        p.removePotionEffect(PotionEffectType.WEAKNESS);
        p.sendMessage(Component.text("Du fühlst dich wieder normal.",
                NamedTextColor.GREEN));
    }

    // ============================================================
    // 3. RAUCHZUCKER – Resistance + Absorption für 6 Min,
    //                  danach 3 Min Blindness + Slowness II + ScreenShake
    // ============================================================
    public void applyRauchzucker(Player p) {
        State s = getState(p);
        long now = System.currentTimeMillis();

        // Falls noch Blindness/Slowness vom letzten Entzug aktiv sind: entfernen
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.SLOWNESS);
        net.kyori.adventure.bossbar.BossBar oldWit = s.withdrawalBars.remove(SubstanceType.RAUCHZUCKER);
        if (oldWit != null) p.hideBossBar(oldWit);
        s.perWithdrawalUntil.put(SubstanceType.RAUCHZUCKER, 0L);

        s.active = SubstanceType.RAUCHZUCKER;
        s.effectStartedAt = now;
        s.effectUntil = now + 6L * 60L * 1000L;
        s.withdrawalUntil = s.effectUntil + 3L * 60L * 1000L;
        // Per-Substanz-Tracking für Multi-BossBar
        s.perEffectStartedAt.put(SubstanceType.RAUCHZUCKER, now);
        s.perEffectUntil.put(SubstanceType.RAUCHZUCKER, s.effectUntil);
        s.perWithdrawalUntil.put(SubstanceType.RAUCHZUCKER, s.withdrawalUntil);

        // Resistance IV (wie Turtle Master) + Absorption IV
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,
                6 * 60 * 20, 3, true, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION,
                6 * 60 * 20, 3, true, true, true));
        // Notch-Apple-artiger Regen-Bonus
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
                6 * 60 * 20, 1, true, true, true));

        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.6f, 1.4f);
        p.sendMessage(Component.text("Crack konsumiert!",
                NamedTextColor.YELLOW));
        p.sendMessage(Component.text("Stark geschützt für 6 Min.",
                NamedTextColor.GRAY));
    }

    private void endRauchzucker(Player p, State s) {
        p.removePotionEffect(PotionEffectType.RESISTANCE);
        p.removePotionEffect(PotionEffectType.ABSORPTION);
        p.removePotionEffect(PotionEffectType.REGENERATION);
        // Withdrawal: 3 Min Blindness + Slowness II
        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS,
                3 * 60 * 20, 0, true, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                3 * 60 * 20, 1, true, true, true));
        p.sendMessage(Component.text("Der Schutz lässt nach.", NamedTextColor.GOLD));
        p.sendMessage(Component.text("3 Min Orientierungslosigkeit.",
                NamedTextColor.RED));
    }

    private void endRauchzuckerWithdrawal(Player p, State s) {
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.SLOWNESS);
        p.sendMessage(Component.text("Du siehst wieder klar.",
                NamedTextColor.GREEN));
    }

    /** Während Rauchzucker-Withdrawal: kleines Camera-Jitter (ScreenShake-Approximation). */
    public void tickScreenShake(Player p) {
        // Mini-Teleport-Jitter (sehr klein, sieht wie Camera-Wackeln aus)
        Location l = p.getLocation();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        float yawJitter   = (rnd.nextFloat() - 0.5f) * 4f;
        float pitchJitter = (rnd.nextFloat() - 0.5f) * 2f;
        // Wir setzen nur die Rotation, nicht die Position – das wirkt wie Screen-Shake
        p.setRotation(l.getYaw() + yawJitter, Math.max(-90, Math.min(90, l.getPitch() + pitchJitter)));
    }

    // ============================================================
    // 4. LEAF – Reinigt alles
    // ============================================================
    public void applyLeaf(Player p) {
        State s = getState(p);

        // Alle PotionEffects entfernen
        for (PotionEffect e : p.getActivePotionEffects()) {
            p.removePotionEffect(e.getType());
        }

        // Eigene Substanz-States entfernen
        if (p.getGameMode() == GameMode.ADVENTURE && s.previousGameMode != null) {
            p.setGameMode(s.previousGameMode);
        } else if (p.getGameMode() == GameMode.ADVENTURE) {
            p.setGameMode(GameMode.SURVIVAL);
        }
        s.active = null;
        s.effectUntil = 0L;
        s.withdrawalUntil = 0L;
        s.previousGameMode = null;
        s.magikzuckerWasActive = false;
        // Multi-BossBar-Maps leeren und alle Bars verstecken
        s.effectBars.values().forEach(p::hideBossBar);
        s.withdrawalBars.values().forEach(p::hideBossBar);
        s.effectBars.clear();
        s.withdrawalBars.clear();
        s.perEffectUntil.clear();
        s.perWithdrawalUntil.clear();
        s.perEffectStartedAt.clear();
        s.perWithdrawalStartedAt.clear();
        clearRainbowTeam(p);

        // Heilkraut-Withdrawal beenden
        var pd = plugin.getPlayerDataManager().get(p);
        pd.setHerbBuffUntilMillis(0L);
        pd.setHerbWithdrawalUntilMillis(0L);
        plugin.getHerbManager().removeBossBars(p);

        // Promille zurücksetzen
        pd.setBloodAlcohol(0.0);
        plugin.getAlcoholManager().removeBossBar(p);
        plugin.getAlcoholManager().clearAlcoholEffects(p);

        // Nikotin: nur Withdrawal beenden, NICHT die Sucht (das wäre zu mächtig)
        pd.setInWithdrawal(false);
        pd.setWithdrawalStartMillis(0L);

        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.6f);
        p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER,
                p.getLocation().add(0, 1, 0),
                20, 0.5, 1.0, 0.5, 0.0);
        p.sendMessage(Component.text("Du fühlst dich wie neugeboren.",
                NamedTextColor.GREEN));
        p.sendMessage(Component.text("Alle Effekte und Entzüge sind weg.",
                NamedTextColor.GRAY));
    }

    // ============================================================
    // 5. SPRITZE – Fliegen für 4 Min, danach 5 Min nicht springen
    // ============================================================
    public void applySpritze(Player p) {
        State s = getState(p);
        long now = System.currentTimeMillis();
        int seconds = ThreadLocalRandom.current().nextInt(3 * 60, 5 * 60 + 1);
        s.active = SubstanceType.SPRITZE;
        s.effectStartedAt = now;
        s.effectUntil = now + (long) seconds * 1000L;
        s.withdrawalUntil = s.effectUntil + 5L * 60L * 1000L;
        // Per-Substanz-Tracking für Multi-BossBar
        s.perEffectStartedAt.put(SubstanceType.SPRITZE, now);
        s.perEffectUntil.put(SubstanceType.SPRITZE, s.effectUntil);
        s.perWithdrawalUntil.put(SubstanceType.SPRITZE, s.withdrawalUntil);

        p.setAllowFlight(true);
        p.setFlying(true);

        p.playSound(p.getLocation(), Sound.ITEM_AXE_STRIP, 0.6f, 1.8f);
        p.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR,
                p.getEyeLocation(),
                5, 0.1, 0.1, 0.1, 0);
        p.sendMessage(Component.text("Heroin gesetzt!", NamedTextColor.LIGHT_PURPLE));
        p.sendMessage(Component.text("Du kannst " + (seconds / 60) + " Min "
                + (seconds % 60) + " s fliegen.", NamedTextColor.GRAY));
    }

    private void endSpritze(Player p, State s) {
        if (p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
        p.sendMessage(Component.text("Das Heroin wirkt nicht mehr.", NamedTextColor.GOLD));
        p.sendMessage(Component.text("5 Min kein Springen möglich.",
                NamedTextColor.RED));
    }

    private void endSpritzeWithdrawal(Player p, State s) {
        p.sendMessage(Component.text("Du kannst wieder springen.",
                NamedTextColor.GREEN));
    }

    /** Ist der Spieler aktuell im Spritze-Withdrawal (= Sprung-Block)? */
    public boolean isInSpritzeWithdrawal(Player p) {
        State s = getState(p);
        if (s.active != SubstanceType.SPRITZE) {
            // Withdrawal-Phase wird nur abgelaufen wenn vorher SPRITZE aktiv war
            return false;
        }
        long now = System.currentTimeMillis();
        return now > s.effectUntil && now < s.withdrawalUntil;
    }

    /** Hat der Spieler aktuell Magikzucker aktiv? */
    public boolean hasMagikzuckerActive(Player p) {
        State s = getState(p);
        if (s.active != SubstanceType.MAGIKZUCKER) return false;
        return System.currentTimeMillis() < s.effectUntil;
    }

    /** Hat der Spieler aktuell Magic-Mushroom-Mob-Ignore aktiv? */
    public boolean isMagicMushroomActive(Player p) {
        State s = getState(p);
        if (s.active != SubstanceType.MAGIC_MUSHROOM) return false;
        return System.currentTimeMillis() < s.effectUntil;
    }

    // ============================================================
    // 6. MAGIC MUSHROOM – 5 Min Mob-Ignore, dann zufällige Nachwirkung
    // ============================================================
    public void applyMagicMushroom(Player p) {
        State s = getState(p);
        long now = System.currentTimeMillis();

        // Falls noch eine Nachwirkung vom letzten Trip aktiv ist: entfernen
        p.removePotionEffect(PotionEffectType.HUNGER);
        p.removePotionEffect(PotionEffectType.NAUSEA);
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.POISON);
        net.kyori.adventure.bossbar.BossBar oldWit = s.withdrawalBars.remove(SubstanceType.MAGIC_MUSHROOM);
        if (oldWit != null) p.hideBossBar(oldWit);
        s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, 0L);

        s.active = SubstanceType.MAGIC_MUSHROOM;
        s.effectStartedAt = now;
        s.effectUntil = now + 5L * 60L * 1000L;
        // Nachwirkung-Dauer wird in endMagicMushroom gesetzt (variabel je nach Effekt)
        // Vorerst auf 0, damit kein Withdrawal-Triggering passiert vor end
        s.withdrawalUntil = 0;
        // Per-Substanz-Tracking für Multi-BossBar
        s.perEffectStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
        s.perEffectUntil.put(SubstanceType.MAGIC_MUSHROOM, s.effectUntil);
        s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, s.withdrawalUntil);

        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_BURP, 0.8f, 0.6f);
        p.getWorld().spawnParticle(Particle.WITCH,
                p.getEyeLocation(), 30, 0.5, 0.5, 0.5, 0.05);
        p.sendMessage(Component.text("Du isst den Pilz ...", NamedTextColor.LIGHT_PURPLE));
        p.sendMessage(Component.text("Mobs ignorieren dich für 5 Min.",
                NamedTextColor.GRAY));
    }

    /** Wird vom Tick aufgerufen, wenn Magic Mushroom abläuft. Würfelt Nachwirkung. */
    private void endMagicMushroom(Player p, State s) {
        long now = System.currentTimeMillis();
        int roll = ThreadLocalRandom.current().nextInt(4);
        switch (roll) {
            case 0: {
                // 3 Min extremer Hunger – Hunger-Effekt der den Wert auf 2 fallen lässt
                p.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER,
                        3 * 60 * 20, 4, true, true, true));
                s.perWithdrawalStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
                s.withdrawalUntil = now + 3L * 60L * 1000L;
                s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, now + 3L * 60L * 1000L);
                p.sendMessage(Component.text("Nachwirkung: extremer Hunger (3 Min)",
                        NamedTextColor.RED));
                break;
            }
            case 1: {
                // 5 Min Screenshake (Nausea wirkt wie Camera-Jitter, plus tickScreenShake-Pings)
                p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,
                        5 * 60 * 20, 0, true, true, true));
                s.perWithdrawalStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
                s.withdrawalUntil = now + 5L * 60L * 1000L;
                s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, now + 5L * 60L * 1000L);
                p.sendMessage(Component.text("Nachwirkung: Übelkeit (5 Min)",
                        NamedTextColor.RED));
                break;
            }
            case 2: {
                // 5 Min Blindheit
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS,
                        5 * 60 * 20, 0, true, true, true));
                s.perWithdrawalStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
                s.withdrawalUntil = now + 5L * 60L * 1000L;
                s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, now + 5L * 60L * 1000L);
                p.sendMessage(Component.text("Nachwirkung: Blindheit (5 Min)",
                        NamedTextColor.RED));
                break;
            }
            case 3:
            default: {
                // 15 sek Vergiftung
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON,
                        15 * 20, 1, true, true, true));
                s.perWithdrawalStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
                s.perWithdrawalStartedAt.put(SubstanceType.MAGIC_MUSHROOM, now);
                s.withdrawalUntil = now + 15L * 1000L;
                s.perWithdrawalUntil.put(SubstanceType.MAGIC_MUSHROOM, now + 15L * 1000L);
                p.sendMessage(Component.text("Nachwirkung: Vergiftung (15 s)",
                        NamedTextColor.RED));
                break;
            }
        }
    }

    private void endMagicMushroomWithdrawal(Player p, State s) {
        p.removePotionEffect(PotionEffectType.HUNGER);
        p.removePotionEffect(PotionEffectType.NAUSEA);
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.POISON);
        p.sendMessage(Component.text("Der Trip ist vorbei.", NamedTextColor.GREEN));
    }

    // ============================================================
    // Tick (vom SubstanceTickTask aufgerufen)
    // ============================================================
    public void tick(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null) return;
        long now = System.currentTimeMillis();

        // Alle aktiven Substanzen durchgehen (multi-substance support)
        for (SubstanceType type : SubstanceType.values()) {
            long effUntil  = s.perEffectUntil.getOrDefault(type, 0L);
            long witUntil  = s.perWithdrawalUntil.getOrDefault(type, 0L);

            // Phase 1 → Phase 2 (Effekt läuft aus)
            if (effUntil > 0 && now >= effUntil) {
                s.perEffectUntil.put(type, 0L);
                s.perWithdrawalStartedAt.put(type, now);
                switch (type) {
                    case MAGIKZUCKER:    endMagikzucker(p, s);    break;
                    case TABLETTE:       endTablette(p, s);       break;
                    case RAUCHZUCKER:    endRauchzucker(p, s);    break;
                    case SPRITZE:        endSpritze(p, s);        break;
                    case MAGIC_MUSHROOM: endMagicMushroom(p, s);  break;
                    default: break;
                }
                // Sync legacy fields for compatibility
                if (s.active == type) { s.effectUntil = 0; s.withdrawalStartedAt = now; }
            }

            // Phase 2 → Phase 3 (Entzug endet)
            if (witUntil > 0 && now >= witUntil) {
                s.perWithdrawalUntil.put(type, 0L);
                switch (type) {
                    case MAGIKZUCKER:    endMagikzuckerWithdrawal(p, s);    break;
                    case TABLETTE:       endTabletteWithdrawal(p, s);       break;
                    case RAUCHZUCKER:    endRauchzuckerWithdrawal(p, s);    break;
                    case SPRITZE:        endSpritzeWithdrawal(p, s);        break;
                    case MAGIC_MUSHROOM: endMagicMushroomWithdrawal(p, s);  break;
                    default: break;
                }
                if (s.active == type) { s.withdrawalUntil = 0; s.active = null; }
                // Bar entfernen
                net.kyori.adventure.bossbar.BossBar wb = s.withdrawalBars.remove(type);
                if (wb != null) p.hideBossBar(wb);
            }
        }

        // Periodische Effekte
        long rauchWithUntil = s.perWithdrawalUntil.getOrDefault(SubstanceType.RAUCHZUCKER, 0L);
        long rauchEffUntil  = s.perEffectUntil.getOrDefault(SubstanceType.RAUCHZUCKER, 0L);
        if (rauchWithUntil > 0 && now < rauchWithUntil && rauchEffUntil == 0) tickScreenShake(p);

        long tabEffUntil = s.perEffectUntil.getOrDefault(SubstanceType.TABLETTE, 0L);
        if (tabEffUntil > 0 && now < tabEffUntil) tickRainbowGlow(p);

        // BossBar-Anzeige
        updateBossBar(p, s, now);
    }

    /** Aktualisiert alle Substanz-BossBars (eine pro aktiver Substanz/Entzug). */
    private void updateBossBar(Player p, State s, long now) {
        for (SubstanceType type : SubstanceType.values()) {
            long effUntil    = s.perEffectUntil.getOrDefault(type, 0L);
            long witUntil    = s.perWithdrawalUntil.getOrDefault(type, 0L);
            long effStarted  = s.perEffectStartedAt.getOrDefault(type, 0L);
            long witStarted  = s.perWithdrawalStartedAt.getOrDefault(type, 0L);

            boolean inEffect     = effUntil > 0 && now < effUntil;
            boolean inWithdrawal = witUntil > 0 && now < witUntil;

            String drugName = drugDisplayName(type);

            // Wirkungsbar
            if (inEffect) {
                long rem  = effUntil - now;
                long tot  = effUntil - effStarted;
                float prog = tot > 0 ? Math.max(0f, Math.min(1f, (float) rem / tot)) : 0f;
                net.kyori.adventure.bossbar.BossBar.Color color = effectBarColor(type);
                net.kyori.adventure.text.Component label = net.kyori.adventure.text.Component.text(
                        drugName + " · Wirkung: " + formatTime(rem),
                        net.kyori.adventure.text.format.NamedTextColor.WHITE);
                net.kyori.adventure.bossbar.BossBar bar = s.effectBars.get(type);
                if (bar == null) {
                    bar = net.kyori.adventure.bossbar.BossBar.bossBar(label, prog, color,
                            net.kyori.adventure.bossbar.BossBar.Overlay.NOTCHED_10);
                    s.effectBars.put(type, bar);
                    p.showBossBar(bar);
                } else {
                    bar.name(label); bar.color(color); bar.progress(prog);
                }
            } else {
                net.kyori.adventure.bossbar.BossBar bar = s.effectBars.remove(type);
                if (bar != null) p.hideBossBar(bar);
            }

            // Entzugsbar erst zeigen wenn Wirkung wirklich vorbei (Eintritt des Entzugs)
            if (inWithdrawal && effUntil == 0) {
                long rem  = witUntil - now;
                long tot  = witStarted > 0 ? witUntil - witStarted : rem;
                float prog = tot > 0 ? Math.max(0f, Math.min(1f, (float) rem / tot)) : 0f;
                net.kyori.adventure.text.Component label = net.kyori.adventure.text.Component.text(
                        drugName + " · Entzug: " + formatTime(rem),
                        net.kyori.adventure.text.format.NamedTextColor.WHITE);
                net.kyori.adventure.bossbar.BossBar bar = s.withdrawalBars.get(type);
                if (bar == null) {
                    bar = net.kyori.adventure.bossbar.BossBar.bossBar(label, prog,
                            net.kyori.adventure.bossbar.BossBar.Color.YELLOW,
                            net.kyori.adventure.bossbar.BossBar.Overlay.NOTCHED_10);
                    s.withdrawalBars.put(type, bar);
                    p.showBossBar(bar);
                } else {
                    bar.name(label); bar.progress(prog);
                }
            } else {
                net.kyori.adventure.bossbar.BossBar bar = s.withdrawalBars.remove(type);
                if (bar != null) p.hideBossBar(bar);
            }
        }
    }

    private String drugDisplayName(SubstanceType t) {
        if (t == null) return "?";
        switch (t) {
            case MAGIKZUCKER:    return "Kokain";
            case TABLETTE:       return "LSD";
            case RAUCHZUCKER:    return "Crack";
            case SPRITZE:        return "Heroin";
            case LEAF:           return "Leaf";
            case MAGIC_MUSHROOM: return "Magic Mushroom";
        }
        return "?";
    }

    private net.kyori.adventure.bossbar.BossBar.Color effectBarColor(SubstanceType t) {
        if (t == null) return net.kyori.adventure.bossbar.BossBar.Color.WHITE;
        switch (t) {
            case MAGIKZUCKER:    return net.kyori.adventure.bossbar.BossBar.Color.WHITE;
            case TABLETTE:       return net.kyori.adventure.bossbar.BossBar.Color.PURPLE;
            case RAUCHZUCKER:    return net.kyori.adventure.bossbar.BossBar.Color.YELLOW;
            case SPRITZE:        return net.kyori.adventure.bossbar.BossBar.Color.GREEN;
            case LEAF:           return net.kyori.adventure.bossbar.BossBar.Color.GREEN;
            case MAGIC_MUSHROOM: return net.kyori.adventure.bossbar.BossBar.Color.PINK;
        }
        return net.kyori.adventure.bossbar.BossBar.Color.WHITE;
    }

    /** Formatiert Zeit als "Xm YYs". */
    private String formatTime(long ms) {
        long totalSec = Math.max(0, ms / 1000L);
        long min = totalSec / 60;
        long sec = totalSec % 60;
        if (min > 0) return min + "m " + (sec < 10 ? "0" : "") + sec + "s";
        return sec + "s";
    }

    /**
     * Wechselt die Glow-Color des Spielers zyklisch durch alle 16 Vanilla-Farben.
     * Dafür wird pro Spieler ein Scoreboard-Team angelegt, das den Spieler enthält
     * und dessen Color jede Sekunde rotiert wird.
     */
    private static final org.bukkit.ChatColor[] RAINBOW = {
            org.bukkit.ChatColor.RED, org.bukkit.ChatColor.GOLD, org.bukkit.ChatColor.YELLOW,
            org.bukkit.ChatColor.GREEN, org.bukkit.ChatColor.AQUA, org.bukkit.ChatColor.BLUE,
            org.bukkit.ChatColor.LIGHT_PURPLE, org.bukkit.ChatColor.DARK_PURPLE
    };
    private final Map<UUID, Integer> rainbowIndex = new HashMap<>();

    private void tickRainbowGlow(Player p) {
        try {
            org.bukkit.scoreboard.Scoreboard sb = plugin.getServer().getScoreboardManager().getMainScoreboard();
            String teamName = "sa_rb_" + p.getName();
            if (teamName.length() > 16) teamName = teamName.substring(0, 16);
            org.bukkit.scoreboard.Team team = sb.getTeam(teamName);
            if (team == null) {
                team = sb.registerNewTeam(teamName);
                team.addEntry(p.getName());
            }
            int idx = rainbowIndex.getOrDefault(p.getUniqueId(), 0);
            team.setColor(RAINBOW[idx % RAINBOW.length]);
            rainbowIndex.put(p.getUniqueId(), idx + 1);
        } catch (Throwable ignored) {
            // Sollte ein Spieler bereits in einem anderen Team sein, ignorieren.
        }
    }

    private void clearRainbowTeam(Player p) {
        try {
            org.bukkit.scoreboard.Scoreboard sb = plugin.getServer().getScoreboardManager().getMainScoreboard();
            String teamName = "sa_rb_" + p.getName();
            if (teamName.length() > 16) teamName = teamName.substring(0, 16);
            org.bukkit.scoreboard.Team team = sb.getTeam(teamName);
            if (team != null) team.unregister();
        } catch (Throwable ignored) {}
        rainbowIndex.remove(p.getUniqueId());
    }
}
