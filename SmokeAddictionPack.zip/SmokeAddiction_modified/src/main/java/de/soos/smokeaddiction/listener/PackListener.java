package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.manager.PackBlockManager;
import de.soos.smokeaddiction.model.CigaretteBrand;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Schachtel-System:
 *  - Rechtsklick auf einen Block mit Schachtel-Item in der Hand -> als Block platzieren
 *  - Linksklick auf platzierte Schachtel -> Zigarette entnehmen
 *  - Rechtsklick auf platzierte Schachtel mit Zigarette -> zurücklegen
 *  - Sneak + Linksklick (oder Schaden) -> Schachtel als Item zurück
 */
public class PackListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public PackListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    /** Schachtel als Block platzieren (Rechtsklick gegen einen Block). */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlace(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        ItemManager im = plugin.getItemManager();
        if (!im.isPack(item)) return;
        if (p.isSneaking()) return; // beim Sneak nicht platzieren (Spieler will evtl. mit Block interagieren)

        e.setCancelled(true);

        // Position oberhalb des angeklickten Blocks
        Location target = e.getClickedBlock().getLocation().add(
                e.getBlockFace().getModX(),
                e.getBlockFace().getModY(),
                e.getBlockFace().getModZ()
        );

        // Prüfen ob an dieser Stelle schon eine Schachtel steht (verhindert "Despawn"-Effekt)
        org.bukkit.util.BoundingBox checkBox = new org.bukkit.util.BoundingBox(
                target.getX() + 0.2, target.getY() + 0.0, target.getZ() + 0.2,
                target.getX() + 0.8, target.getY() + 1.0, target.getZ() + 0.8);
        for (org.bukkit.entity.Entity ent : target.getWorld().getNearbyEntities(checkBox)) {
            if (plugin.getPackBlockManager().isPackEntity(ent)) {
                p.sendMessage(net.kyori.adventure.text.Component.text(
                        "Hier steht bereits eine Schachtel.",
                        net.kyori.adventure.text.format.NamedTextColor.RED));
                return;
            }
        }

        // Schachtel-ArmorStand platzieren
        plugin.getPackBlockManager().place(target, item);

        // Eine Schachtel aus dem Stack abziehen
        if (p.getGameMode() != GameMode.CREATIVE) {
            int amt = item.getAmount();
            if (amt <= 1) p.getInventory().setItemInMainHand(null);
            else item.setAmount(amt - 1);
        }
        p.playSound(target, Sound.BLOCK_WOOD_PLACE, 0.8f, 1.2f);
    }

    /**
     * Linksklick auf Schachtel-Entity: Zigarette entnehmen oder Schachtel abbauen (mit Sneak).
     *
     * In Paper 1.21 feuert EntityDamageByEntityEvent für ArmorStands mit bestimmten Flags nicht
     * mehr zuverlässig. Stattdessen nutzen wir PlayerAnimationEvent (Arm-Schwung) + Raycast.
     */
    @EventHandler(ignoreCancelled = true)
    public void onLeftClickEntity(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof ArmorStand as)) return;
        PackBlockManager pbm = plugin.getPackBlockManager();
        if (!pbm.isPackEntity(as)) return;
        e.setCancelled(true);
        handlePackLeftClick(p, as);
    }

    /** Fallback für Paper 1.21: PlayerAnimationEvent + Raycast, falls EntityDamage nicht feuert. */
    @EventHandler(ignoreCancelled = true)
    public void onSwingArm(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        // Raycast: Trifft der Blick einen Pack-ArmorStand innerhalb von 4 Blöcken?
        org.bukkit.util.RayTraceResult ray = p.getWorld().rayTraceEntities(
                p.getEyeLocation(),
                p.getEyeLocation().getDirection(),
                4.0,
                entity -> entity instanceof ArmorStand as2
                        && plugin.getPackBlockManager().isPackEntity(as2));
        if (ray == null || !(ray.getHitEntity() instanceof ArmorStand as)) return;
        handlePackLeftClick(p, as);
    }

    private void handlePackLeftClick(Player p, ArmorStand as) {
        PackBlockManager pbm = plugin.getPackBlockManager();
        ItemManager im = plugin.getItemManager();
        ItemStack packItem = pbm.getPackItem(as);
        if (packItem == null) return;
        CigaretteBrand brand = im.getBrand(packItem);
        int contents = im.getPackContents(packItem);

        if (p.isSneaking()) {
            // Schachtel abbauen -> als Item zurück
            ItemStack drop = packItem.clone();
            drop.setAmount(1);
            p.getWorld().dropItemNaturally(as.getLocation().add(0, 1, 0), drop);
            pbm.remove(as);
            p.playSound(as.getLocation(), Sound.BLOCK_WOOD_BREAK, 0.8f, 1.0f);
            return;
        }

        // Zigarette entnehmen
        if (contents <= 0) {
            p.sendMessage(Component.text("Die Schachtel ist leer. Sneak + Linksklick zum Abbauen.",
                    NamedTextColor.GRAY));
            return;
        }
        ItemStack cig = pbm.popCigarette(as, brand);
        cig.setAmount(1);
        java.util.Map<Integer, ItemStack> overflow = p.getInventory().addItem(cig);
        for (ItemStack rest : overflow.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
        pbm.setContents(as, contents - 1);
        p.playSound(as.getLocation(), Sound.ITEM_BUNDLE_REMOVE_ONE, 0.8f, 1.4f);
    }

    /**
     * Rechtsklick auf Schachtel-Entity mit Zigarette: zurücklegen / auffüllen.
     *
     * - Normaler Rechtsklick: eine Zigarette einlegen
     * - Sneak + Rechtsklick:  so viele Zigaretten einlegen wie möglich (Schachtel auffüllen)
     */
    @EventHandler(ignoreCancelled = true)
    public void onRightClickEntity(PlayerInteractAtEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!(e.getRightClicked() instanceof ArmorStand as)) return;
        PackBlockManager pbm = plugin.getPackBlockManager();
        if (!pbm.isPackEntity(as)) return;

        e.setCancelled(true);

        Player p = e.getPlayer();
        ItemManager im = plugin.getItemManager();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!im.isCigarette(hand)) {
            p.sendMessage(Component.text("Halte Zigaretten in der Hand zum Einlegen. "
                    + "(Sneak + Rechtsklick = auffüllen)",
                    NamedTextColor.GRAY));
            return;
        }

        // Marken müssen übereinstimmen
        CigaretteBrand handBrand = im.getBrand(hand);
        CigaretteBrand packBrand = pbm.getBrand(as);
        if (handBrand != packBrand) {
            p.sendMessage(Component.text("Diese Zigarette gehört nicht in diese Schachtel (" 
                    + packBrand.getDisplayName() + ").", NamedTextColor.RED));
            return;
        }

        int contents = pbm.getContents(as);
        if (contents >= 8) {
            p.sendMessage(Component.text("Die Schachtel ist bereits voll (8/8).", NamedTextColor.GRAY));
            return;
        }

        boolean sneaking = p.isSneaking();
        boolean creative = p.getGameMode() == GameMode.CREATIVE;

        if (sneaking) {
            // Auffüllen: so viele wie möglich aus dem Stack in die Schachtel legen
            int freePlätze = 8 - contents;
            int verfügbar  = creative ? freePlätze : hand.getAmount();
            int einzulegen = Math.min(freePlätze, verfügbar);

            if (!creative) {
                int rest = hand.getAmount() - einzulegen;
                if (rest <= 0) p.getInventory().setItemInMainHand(null);
                else hand.setAmount(rest);
            }
            // Jede einzelne Zigarette mit Enchants in Queue speichern
            for (int i = 0; i < einzulegen; i++) pbm.pushCigarette(as, hand);
            pbm.setContents(as, contents + einzulegen);
            p.sendMessage(Component.text("+" + einzulegen + " Zigaretten eingelegt ("
                    + (contents + einzulegen) + "/8).", NamedTextColor.GREEN));
            p.playSound(as.getLocation(), Sound.ITEM_BUNDLE_INSERT, 1.0f, 1.0f);
        } else {
            // Einzeln einlegen
            if (!creative) {
                int amt = hand.getAmount();
                if (amt <= 1) p.getInventory().setItemInMainHand(null);
                else hand.setAmount(amt - 1);
            }
            pbm.pushCigarette(as, hand);
            pbm.setContents(as, contents + 1);
            p.playSound(as.getLocation(), Sound.ITEM_BUNDLE_INSERT, 0.8f, 1.2f);
        }
    }
}
