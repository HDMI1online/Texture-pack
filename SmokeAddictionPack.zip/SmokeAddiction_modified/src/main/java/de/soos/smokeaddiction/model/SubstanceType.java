package de.soos.smokeaddiction.model;

/** Alle Custom-Substanzen. */
public enum SubstanceType {
    MAGIKZUCKER,
    TABLETTE,
    RAUCHZUCKER,
    LEAF,
    SPRITZE,
    MAGIC_MUSHROOM
}
