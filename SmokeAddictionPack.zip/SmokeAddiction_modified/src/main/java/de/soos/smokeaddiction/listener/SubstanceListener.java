package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Verarbeitet:
 *   - Rechtsklick-Konsum von Magikzucker, Rauchzucker, Leaf, Spritze
 *   - Vanilla-Eat von Tablette
 *   - Block-Break-Override während Magikzucker (alle Blöcke abbaubar, Drops nur bei normalen)
 *   - Sprung-Block während Spritze-Withdrawal
 */
public class SubstanceListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public SubstanceListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    // ============================================================
    // Konsum: Rechtsklick (Magikzucker, Rauchzucker, Leaf, Spritze)
    // ============================================================
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        ItemManager im = plugin.getItemManager();

        if (im.isMagikzucker(item)) {
            e.setCancelled(true);
            consumeOne(p, item);
            plugin.getSubstanceManager().applyMagikzucker(p);
            return;
        }
        if (im.isSpritze(item)) {
            e.setCancelled(true);
            consumeOne(p, item);
            plugin.getSubstanceManager().applySpritze(p);
            return;
        }
        // Rauchzucker und Leaf werden NICHT direkt konsumiert –
        // sie werden in der Werkbank zu Zigaretten verarbeitet.
    }

    // ============================================================
    // Konsum: Tablette (LSD) via Rechtsklick – unabhängig vom Hunger
    // ============================================================
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTabletteConsume(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item == null) return;

        if (plugin.getItemManager().isTablette(item)) {
            e.setCancelled(true);
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY); // verhindert Vanilla-Essens-Logik
            consumeOne(p, item);
            plugin.getSubstanceManager().applyTablette(p);
            p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EAT, 0.8f, 1.2f);
            return;
        }
    }

    // ============================================================
    // Konsum: Magic Mushroom – Vanilla-Pufferfish-Effekte verhindern
    // ============================================================
    @EventHandler(ignoreCancelled = true)
    public void onMushroomConsume(PlayerItemConsumeEvent e) {
        ItemStack item = e.getItem();
        if (item == null) return;

        if (plugin.getItemManager().isMagicMushroom(item)) {
            e.setCancelled(true);
            consumeOne(e.getPlayer(), item);
            plugin.getSubstanceManager().applyMagicMushroom(e.getPlayer());
        }
    }

    private void consumeOne(Player p, ItemStack hand) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        int amt = hand.getAmount();
        if (amt <= 1) {
            p.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(amt - 1);
        }
    }

    // ============================================================
    // Magikzucker: erlaubt das Abbauen unzerstörbarer Blöcke (Bedrock etc.)
    // ============================================================

    /** Erlaubt Linksklick-Break auf unzerstörbare Blöcke während Magikzucker. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClickUnbreakable(PlayerInteractEvent e) {
        if (e.getAction() != Action.LEFT_CLICK_BLOCK) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!plugin.getSubstanceManager().hasMagikzuckerActive(p)) return;

        Block b = e.getClickedBlock();
        if (b == null) return;
        if (!isUnbreakable(b.getType())) return;

        // Unzerstörbarer Block: in 1 Klick brechen, KEINE Drops
        e.setCancelled(true);
        b.setType(Material.AIR, true);
        b.getWorld().playSound(b.getLocation(),
                org.bukkit.Sound.BLOCK_STONE_BREAK, 1.0f, 0.5f);
    }

    /** Stellt sicher dass NORMALE Block-Drops während Magikzucker funktionieren (Vanilla-Verhalten). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        // Mit Haste 255 bricht der Spieler im Survival-Mode normale Blöcke instant.
        // Die Vanilla-Drop-Logik greift dann wie gewohnt – nichts zu tun.
    }

    private boolean isUnbreakable(Material m) {
        switch (m) {
            case BEDROCK:
            case BARRIER:
            case COMMAND_BLOCK:
            case CHAIN_COMMAND_BLOCK:
            case REPEATING_COMMAND_BLOCK:
            case STRUCTURE_BLOCK:
            case STRUCTURE_VOID:
            case JIGSAW:
            case END_PORTAL_FRAME:
            case END_PORTAL:
            case NETHER_PORTAL:
            case LIGHT:
                return true;
            default:
                return false;
        }
    }

    // ============================================================
    // Spritze-Withdrawal: Springen blockieren via Velocity-Reset
    // ============================================================
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJump(org.bukkit.event.player.PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!plugin.getSubstanceManager().isInSpritzeWithdrawal(p)) return;
        // Wenn Spieler aufwärts beschleunigt UND auf dem Boden war: das ist ein Sprung
        // Wir reseten die Y-Velocity auf 0
        if (e.getFrom().getY() < e.getTo().getY()
                && (e.getTo().getY() - e.getFrom().getY()) > 0.05
                && p.getVelocity().getY() > 0
                && !p.isFlying()) {
            // Prüfen: war Spieler eben am Boden?
            if (e.getFrom().clone().subtract(0, 0.1, 0).getBlock().getType().isSolid()) {
                p.setVelocity(p.getVelocity().setY(0));
            }
        }
    }

    // ============================================================
    // Magic Mushroom: Mobs ignorieren den Spieler
    // ============================================================
    @EventHandler(ignoreCancelled = true)
    public void onMobTarget(org.bukkit.event.entity.EntityTargetLivingEntityEvent e) {
        if (!(e.getTarget() instanceof Player p)) return;
        if (!plugin.getSubstanceManager().isMagicMushroomActive(p)) return;
        e.setCancelled(true);
        e.setTarget(null);
    }

    /** Verhindert das Platzieren von Leaf als Block. */
    @EventHandler(ignoreCancelled = true)
    public void onLeafPlace(BlockPlaceEvent e) {
        ItemStack item = e.getItemInHand();
        if (plugin.getItemManager().isLeaf(item)) {
            e.setCancelled(true);
        }
    }
}