package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tickt jede Sekunde alle ONLINE-Spieler:
 *  - reduziert Nikotin gemäß Sucht-Stufe
 *  - wendet Entzug-Hunger-Verlust an
 *  - wendet Speed-Effekt an
 *  - wendet schnellen Sauerstoff-Verlust unter Wasser an
 *
 * Offline-Spieler werden NICHT verarbeitet (Anforderung: kein Nikotinverlust beim Logout).
 */
public class NicotineDecayTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public NicotineDecayTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getNicotineManager().tick(p);
                plugin.getNicotineManager().applyWithdrawalHungerLoss(p);
                plugin.getNicotineManager().applyWaterAirLossIfNeeded(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Fehler im Decay-Task für " + p.getName() + ": " + ex.getMessage());
            }
        }
    }
}
