package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Verarbeitet das Trinken von Bier und Jägermeister.
 *
 * Da wir HONEY_BOTTLE als Vanilla-Material nutzen, würde Vanilla-Code beim Rechtsklick
 * automatisch eine 32-Tick-Trinkanimation starten und dabei +6 Saturation geben.
 * Das übernehmen wir, fügen aber unsere Promille- und Heilungs-Logik hinzu, indem
 * wir auf {@link PlayerItemConsumeEvent} reagieren.
 *
 * Für den schnelleren Jägermeister: wir cancellen das normale Trink-Event und
 * verarbeiten es nach einer kürzeren Cooldown-Phase selbst.
 */
public class AlcoholListener implements Listener {

    /** Cooldown in Millisekunden zwischen zwei Jäger-Schlucken (Schnell-Trinken). */
    private static final long JAEGER_COOLDOWN_MS = 800L;

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, Long> lastJaeger = new HashMap<>();

    public AlcoholListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    /** Bier + Jäger: sofortiger Konsum via Rechtsklick (Luft + Block), kein Halten nötig. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item == null) return;
        ItemManager im = plugin.getItemManager();

        // Zaubertisch nicht abfangen
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK
                && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.ENCHANTING_TABLE) return;

        if (im.isBeer(item)) {
            e.setCancelled(true);
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
            long now = System.currentTimeMillis();
            long last = lastJaeger.getOrDefault(p.getUniqueId(), 0L); // gleicher Cooldown-Map
            if (now - last < 1200L) return; // 1.2s Cooldown für Bier
            lastJaeger.put(p.getUniqueId(), now);
            p.swingMainHand();
            p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.8f, 0.9f);
            consumeOne(p, EquipmentSlot.HAND);
            plugin.getAlcoholManager().onBeerConsumed(p);
            return;
        }

        if (im.isJaeger(item)) {
            e.setCancelled(true);
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
            long now = System.currentTimeMillis();
            long last = lastJaeger.getOrDefault(p.getUniqueId(), 0L);
            if (now - last < JAEGER_COOLDOWN_MS) return;
            lastJaeger.put(p.getUniqueId(), now);
            p.swingMainHand();
            p.playSound(p.getLocation(), Sound.ITEM_BOTTLE_FILL, 0.6f, 1.8f);
            consumeOne(p, EquipmentSlot.HAND);
            plugin.getAlcoholManager().onJaegerConsumed(p);
            return;
        }
    }

    /** Vanilla-Consume komplett abfangen um Honey-Bottle-Effekte zu verhindern. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        ItemStack item = e.getItem();
        if (item == null) return;
        ItemManager im = plugin.getItemManager();
        if (im.isBeer(item) || im.isJaeger(item)) {
            e.setCancelled(true); // Vanilla-Saturation/Effekt unterdrücken
        }
    }

    private void consumeOne(Player p, EquipmentSlot slot) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        ItemStack hand = p.getInventory().getItem(slot);
        if (hand == null) return;
        int amt = hand.getAmount();
        if (amt <= 1) {
            p.getInventory().setItem(slot, null);
        } else {
            hand.setAmount(amt - 1);
        }
        // Leeres Glas zurückgeben? Honey-Bottle gibt vanilla-mäßig keinen leeren Bottle zurück
        // (Honey-Bottle = ITEM_BOTTLE_DRINK), aber für Bier/Jäger lassen wir es weg – ist ein
        // "Einweg-Getränk".
    }
}
