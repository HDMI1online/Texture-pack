// AUTO-GENERIERT von gen_models.py – nicht von Hand bearbeiten
package de.soos.smokeaddiction.util;

import de.soos.smokeaddiction.model.CigaretteBrand;
import de.soos.smokeaddiction.model.VapeFlavor;

/** Custom Model Data Werte für das Resource Pack. */
public final class CMDValues {
    private CMDValues() {}

    public static final int CIGARETTE_MARLBORO = 710001;
    public static final int CIGARETTE_LUCKY_STRIKE = 710002;
    public static final int CIGARETTE_CAMEL = 710003;
    public static final int CIGARETTE_WINSTON = 710004;
    public static final int CIGARETTE_L_AND_M = 710005;
    public static final int CIGARETTE_SELFMADE = 710006;

    /** Burn-Stufen: Basis-CMD + Offset → halbe, niedrige, fast-aus Stufe. */
    public static final int CIG_BURN_HALF_OFFSET = 100;
    public static final int CIG_BURN_LOW_OFFSET  = 200;
    public static final int CIG_BURN_END_OFFSET  = 300;
    public static final int PACK_MARLBORO = 720001;
    public static final int PACK_LUCKY_STRIKE = 720002;
    public static final int PACK_CAMEL = 720003;
    public static final int PACK_WINSTON = 720004;
    public static final int PACK_L_AND_M = 720005;
    public static final int PACK_SELFMADE = 720006;
    public static final int VAPE_BLUE_RAZZ = 730001;
    public static final int VAPE_WATERMELON = 730002;
    public static final int VAPE_MANGO_ICE = 730003;
    public static final int VAPE_GRAPE = 730004;
    public static final int VAPE_APPLE_PEACH = 730005;
    public static final int VAPE_COTTON_CANDY = 730006;
    public static final int VAPE_MENTHOL = 730007;
    public static final int VAPE_VOZOL_40K = 730008;
    public static final int VAPE_RANDM_PEACH_ICE          = 830001;
    public static final int VAPE_RANDM_PINK_LEMONADE      = 830002;
    public static final int VAPE_RANDM_STRAWBERRY_KIWI    = 830003;
    public static final int VAPE_RANDM_WILD_BERRY_CHERRY  = 830004;
    public static final int FUMOT12K = 740001;
    public static final int SHISHA = 750001;
    public static final int TOBACCO_RAW = 760001;
    public static final int TOBACCO_DRIED = 770001;
    public static final int TOBACCO_SEEDS = 780001;
    public static final int LIGHTER = 790001;
    public static final int BEER    = 800001;
    public static final int JAEGER  = 800002;
    public static final int MONSTER_WHITE = 800003;
    public static final int HERB_RAW   = 810001;
    public static final int HERB_DRIED = 810002;
    public static final int HERB_SEEDS = 810003;
    public static final int CIGARETTE_HERB_JOINT = 710007;
    public static final int CIGARETTE_RAUCHZUCKER = 710008;
    public static final int CIGARETTE_LEAF = 710009;

    // Custom-Substanzen
    public static final int MAGIKZUCKER  = 820001;
    public static final int TABLETTE     = 820002;
    public static final int RAUCHZUCKER  = 820003;
    public static final int LEAF         = 820004;
    public static final int SPRITZE      = 820005;
    public static final int MAGIC_MUSHROOM = 820006;

    public static int forCigarette(CigaretteBrand brand) {
        switch (brand) {
            case MARLBORO:        return CIGARETTE_MARLBORO;
            case LUCKY_STRIKE:    return CIGARETTE_LUCKY_STRIKE;
            case CAMEL:           return CIGARETTE_CAMEL;
            case WINSTON:         return CIGARETTE_WINSTON;
            case L_AND_M:         return CIGARETTE_L_AND_M;
            case SELFMADE:        return CIGARETTE_SELFMADE;
            case HERB_JOINT:      return CIGARETTE_HERB_JOINT;
            case RAUCHZUCKER_CIG: return CIGARETTE_RAUCHZUCKER;
            case LEAF_CIG:        return CIGARETTE_LEAF;
            default:              return CIGARETTE_MARLBORO;
        }
    }

    public static int forPack(CigaretteBrand brand) {
        switch (brand) {
            case MARLBORO:     return PACK_MARLBORO;
            case LUCKY_STRIKE: return PACK_LUCKY_STRIKE;
            case CAMEL:        return PACK_CAMEL;
            case WINSTON:      return PACK_WINSTON;
            case L_AND_M:      return PACK_L_AND_M;
            case SELFMADE:     return PACK_SELFMADE;
            default:           return PACK_MARLBORO;
        }
    }

    public static int forVape(VapeFlavor flavor) {
        switch (flavor) {
            case BLUE_RAZZ:    return VAPE_BLUE_RAZZ;
            case WATERMELON:   return VAPE_WATERMELON;
            case MANGO_ICE:    return VAPE_MANGO_ICE;
            case GRAPE:        return VAPE_GRAPE;
            case APPLE_PEACH:  return VAPE_APPLE_PEACH;
            case COTTON_CANDY: return VAPE_COTTON_CANDY;
            case MENTHOL:      return VAPE_MENTHOL;
            case VOZOL_40K:    return VAPE_VOZOL_40K;
            case RANDM_PEACH_ICE:         return VAPE_RANDM_PEACH_ICE;
            case RANDM_PINK_LEMONADE:     return VAPE_RANDM_PINK_LEMONADE;
            case RANDM_STRAWBERRY_KIWI:   return VAPE_RANDM_STRAWBERRY_KIWI;
            case RANDM_WILD_BERRY_CHERRY: return VAPE_RANDM_WILD_BERRY_CHERRY;
            default:           return VAPE_BLUE_RAZZ;
        }
    }
}