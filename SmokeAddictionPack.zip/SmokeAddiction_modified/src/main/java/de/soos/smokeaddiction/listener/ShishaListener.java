package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.manager.ShishaManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Vereint alle Spieler-Interaktionen mit der Shisha:
 *  - Rechtsklick mit Shisha-Item auf Block       -> platzieren
 *  - Rechtsklick auf Shisha-Entity (kein Sneak)  -> Sitzung starten
 *  - Sneak + Rechtsklick auf Shisha-Entity       -> GUI öffnen (Tabak/Wasser)
 *  - Linksklick mit Netherit-Spitzhacke          -> abbauen, Item zurück
 *  - Andere Werkzeuge                            -> kein Effekt
 *  - GUI-Klicks                                  -> Tabak/Wasser einfüllen
 */
public class ShishaListener implements Listener {

    public static final int SLOT_TOBACCO = 2;
    public static final int SLOT_STATUS  = 4;
    public static final int SLOT_WATER   = 6;

    private final SmokeAddictionPlugin plugin;

    /** Map: Spieler-UUID -> ArmorStand-UUID, solange dessen Shisha-GUI offen ist. */
    private final Map<UUID, UUID> openByPlayer = new HashMap<>();

    public ShishaListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    // ============ PLATZIEREN ============

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlace(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;

        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (!plugin.getItemManager().isShisha(item)) return;
        if (p.isSneaking()) return; // beim Sneak nicht platzieren

        e.setCancelled(true);

        Location target = e.getClickedBlock().getLocation().add(
                e.getBlockFace().getModX(),
                e.getBlockFace().getModY(),
                e.getBlockFace().getModZ()
        );

        plugin.getShishaManager().place(target);

        if (p.getGameMode() != GameMode.CREATIVE) {
            int amt = item.getAmount();
            if (amt <= 1) p.getInventory().setItemInMainHand(null);
            else item.setAmount(amt - 1);
        }
        p.playSound(target, Sound.BLOCK_LANTERN_PLACE, 1.0f, 1.2f);
    }

    // ============ ABBAUEN (Sneak + Linksklick mit beliebigem Werkzeug) ============

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof ArmorStand as)) return;
        if (!plugin.getShishaManager().isShishaEntity(as)) return;
        e.setCancelled(true);
        if (!(e.getDamager() instanceof Player p)) return;
        handleShishaBreak(p, as);
    }

    /** Fallback für Paper 1.21: PlayerAnimationEvent + Raycast. */
    @EventHandler(ignoreCancelled = true)
    public void onSwingArm(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        if (!p.isSneaking()) return;
        org.bukkit.util.RayTraceResult ray = p.getWorld().rayTraceEntities(
                p.getEyeLocation(),
                p.getEyeLocation().getDirection(),
                4.0,
                entity -> entity instanceof ArmorStand as2
                        && plugin.getShishaManager().isShishaEntity(as2));
        if (ray == null || !(ray.getHitEntity() instanceof ArmorStand as)) return;
        handleShishaBreak(p, as);
    }

    private void handleShishaBreak(Player p, ArmorStand as) {
        if (!p.isSneaking()) return;
        // Falls jemand gerade an der Shisha zieht: Sitzung abbrechen
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (plugin.getShishaManager().isInSession(online)) {
                plugin.getShishaManager().cancelSession(online);
            }
        }
        as.getWorld().dropItemNaturally(as.getLocation().add(0, 0.5, 0),
                plugin.getItemManager().createShisha(1));
        plugin.getShishaManager().remove(as);
        p.playSound(as.getLocation(), Sound.BLOCK_LANTERN_BREAK, 1.0f, 1.0f);
    }

    // ============ RECHTSKLICK AUF SHISHA ============

    @EventHandler(ignoreCancelled = true)
    public void onRightClickEntity(PlayerInteractAtEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!(e.getRightClicked() instanceof ArmorStand as)) return;
        if (!plugin.getShishaManager().isShishaEntity(as)) return;

        e.setCancelled(true);

        Player p = e.getPlayer();
        ShishaManager sm = plugin.getShishaManager();

        // Sneak + Rechtsklick -> Inventar öffnen
        if (p.isSneaking()) {
            openInventory(p, as);
            return;
        }

        // Bereits in Session?
        if (sm.isInSession(p)) {
            return;
        }

        // Vorbedingungen prüfen
        if (!sm.hasWater(as)) {
            p.sendMessage(Component.text("Diese Shisha hat kein Wasser. Sneak + Rechtsklick zum Befüllen.",
                    NamedTextColor.RED));
            return;
        }
        if (sm.getRemainingUses(as) <= 0) {
            p.sendMessage(Component.text("Diese Shisha ist leer. Sneak + Rechtsklick zum Befüllen.",
                    NamedTextColor.RED));
            return;
        }

        // Sitzung starten
        sm.startSession(p, as);
    }

    // ============ INVENTAR-GUI ============

    private void openInventory(Player p, ArmorStand as) {
        Inventory inv = Bukkit.createInventory(null, 9,
                Component.text("Shisha", NamedTextColor.LIGHT_PURPLE));

        // Hintergrund: violette Glasplatten, Funktions-Slots leer
        ItemStack pane = decoPane();
        for (int i = 0; i < 9; i++) inv.setItem(i, pane);

        ItemManager im = plugin.getItemManager();
        ShishaManager sm = plugin.getShishaManager();

        // Tabak-Slot (zeigt aktuellen Stand)
        inv.setItem(SLOT_TOBACCO, makeSlotIndicator(
                Material.DRIED_KELP,
                "Tabak einlegen",
                "Klicke mit Tabakblatt zum Befüllen.",
                "Verbleibend: " + sm.getRemainingUses(as) + " Züge"));

        // Wasser-Slot
        inv.setItem(SLOT_WATER, makeSlotIndicator(
                Material.WATER_BUCKET,
                "Wasser einfüllen",
                "Klicke mit Wassereimer zum Befüllen.",
                sm.hasWater(as) ? "Befüllt" : "Leer"));

        // Status (mittiger Slot)
        boolean ready = sm.isReady(as);
        inv.setItem(SLOT_STATUS, makeSlotIndicator(
                ready ? Material.LIME_DYE : Material.GRAY_DYE,
                ready ? "Bereit" : "Nicht bereit",
                ready ? "Schließe das Menü und ziehe per Rechtsklick." : "Tabak und Wasser einfüllen!"));

        p.openInventory(inv);
        openByPlayer.put(p.getUniqueId(), as.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        UUID shishaUuid = openByPlayer.get(p.getUniqueId());
        if (shishaUuid == null) return; // GUI gehört nicht uns

        // Shift-Click oder Number-Key vom Spieler-Inventar in die Shisha hinein blockieren,
        // sonst könnten Items in invalid Slots landen.
        if (e.getClick().isShiftClick() || e.getClick() == org.bukkit.event.inventory.ClickType.NUMBER_KEY) {
            e.setCancelled(true);
            return;
        }

        // Klicks im Spieler-Inventar (unten) NICHT canceln – Spieler darf seine Items bewegen
        if (e.getClickedInventory() != e.getView().getTopInventory()) {
            return;
        }

        // Ab hier: Klick ist im Shisha-GUI (oben). Wir cancellen, weil wir die Slots manuell verwalten.
        e.setCancelled(true);

        org.bukkit.entity.Entity ent = plugin.getServer().getEntity(shishaUuid);
        if (!(ent instanceof ArmorStand as) || !plugin.getShishaManager().isShishaEntity(as)) {
            return;
        }

        ItemManager im = plugin.getItemManager();
        ShishaManager sm = plugin.getShishaManager();
        ItemStack cursor = e.getCursor();

        if (e.getSlot() == SLOT_TOBACCO) {
            if (cursor == null || cursor.getType() == Material.AIR) return;
            int uses = sm.getRemainingUses(as);
            if (uses >= ShishaManager.FILL_USES) {
                p.sendMessage(Component.text("Die Shisha ist bereits voll.",
                        NamedTextColor.GRAY));
                return;
            }
            // Akzeptierte Füllstoffe: Tabak, Zigaretten/Joints, Leaf, Rauchzucker,
            // Magikzucker, Spritze, Magic Mushroom, Tablette
            boolean accepted = im.isTobacco(cursor)
                    || im.isCigarette(cursor)
                    || im.isLeaf(cursor)
                    || im.isRauchzucker(cursor)
                    || im.isMagikzucker(cursor)
                    || im.isSpritze(cursor)
                    || im.isMagicMushroom(cursor)
                    || im.isTablette(cursor);
            if (!accepted) {
                p.sendMessage(Component.text("Das kann nicht in die Shisha gefüllt werden.",
                        NamedTextColor.RED));
                return;
            }
            cursor.setAmount(cursor.getAmount() - 1);
            if (cursor.getAmount() <= 0) e.getView().setCursor(null);
            sm.setRemainingUses(as, ShishaManager.FILL_USES);
            p.playSound(p.getLocation(), Sound.ITEM_BUNDLE_INSERT, 0.8f, 1.4f);
            refreshInventory(e.getInventory(), as);
            return;
        }
        if (e.getSlot() == SLOT_WATER) {
            if (cursor != null && cursor.getType() == Material.WATER_BUCKET) {
                if (sm.hasWater(as)) {
                    p.sendMessage(Component.text("Die Shisha enthält bereits Wasser.",
                            NamedTextColor.GRAY));
                    return;
                }
                // Eimer leer zurückgeben
                cursor.setType(Material.BUCKET);
                sm.setWater(as, true);
                p.playSound(p.getLocation(), Sound.ITEM_BUCKET_EMPTY, 0.8f, 1.0f);
                refreshInventory(e.getInventory(), as);
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p) {
            openByPlayer.remove(p.getUniqueId());
        }
    }

    private void refreshInventory(Inventory inv, ArmorStand as) {
        ShishaManager sm = plugin.getShishaManager();
        inv.setItem(SLOT_TOBACCO, makeSlotIndicator(
                Material.DRIED_KELP,
                "Tabak einlegen",
                "Klicke mit Tabakblatt zum Befüllen.",
                "Verbleibend: " + sm.getRemainingUses(as) + " Züge"));
        inv.setItem(SLOT_WATER, makeSlotIndicator(
                Material.WATER_BUCKET,
                "Wasser einfüllen",
                "Klicke mit Wassereimer zum Befüllen.",
                sm.hasWater(as) ? "Befüllt" : "Leer"));
        boolean ready = sm.isReady(as);
        inv.setItem(SLOT_STATUS, makeSlotIndicator(
                ready ? Material.LIME_DYE : Material.GRAY_DYE,
                ready ? "Bereit" : "Nicht bereit",
                ready ? "Schließe das Menü und ziehe per Rechtsklick." : "Tabak und Wasser einfüllen!"));
    }

    // ============ Helpers ============

    private ItemStack decoPane() {
        ItemStack pane = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta m = pane.getItemMeta();
        if (m != null) {
            m.displayName(Component.text(" "));
            pane.setItemMeta(m);
        }
        return pane;
    }

    private ItemStack makeSlotIndicator(Material mat, String name, String... lore) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        if (m != null) {
            m.displayName(Component.text(name, NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false));
            java.util.List<Component> ls = new java.util.ArrayList<>();
            for (String l : lore) {
                ls.add(Component.text(l, NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false));
            }
            m.lore(ls);
            i.setItemMeta(m);
        }
        return i;
    }
}
