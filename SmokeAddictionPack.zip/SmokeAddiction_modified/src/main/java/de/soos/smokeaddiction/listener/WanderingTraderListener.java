package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Material;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;

import java.util.ArrayList;
import java.util.List;

/**
 * Wenn ein Wandering Trader spawnt, werden zufällig 1-2 Plugin-Trades hinzugefügt:
 *   - Heroin (Spritze)        → 38 Emeralds
 *   - Cannabis (getrocknet)   → 20 Emeralds
 *   - Leaf                    → 30 Emeralds
 *
 * Zusätzlich GARANTIERT (immer, unabhängig vom Zufalls-Pool):
 *   - Fumot 12k               → 12 Emeralds
 *
 * Zusätzlich mit unabhängiger Chance (egal was oben gewählt wurde):
 *   - Vape Vozol 40k          → 20 Emeralds (40% Chance, unabhängig von den anderen Trades)
 *   - Vape Randm 15k          → 15 Emeralds (45% Chance, zufällige Sorte, unabhängig von den anderen Trades)
 *
 * Jeder Trade hat 4 maxUses, kein Reset nach Tag-Wechsel.
 */
public class WanderingTraderListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public WanderingTraderListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (!(e.getEntity() instanceof WanderingTrader trader)) return;

        // Nur bei Naturspawn, nicht bei /summon oder Plugin-Spawns
        // (sonst nervt das im Test)
        // Trotzdem ergänzen wir Trades — der User möchte das ja.

        List<MerchantRecipe> recipes = new ArrayList<>(trader.getRecipes());
        de.soos.smokeaddiction.manager.ItemManager im = plugin.getItemManager();

        // Alle möglichen Plugin-Trades vorbereiten
        List<MerchantRecipe> pluginTrades = new ArrayList<>();

        // Heroin: 38 Emeralds → 1 Heroin
        MerchantRecipe heroin = new MerchantRecipe(im.createSpritze(1), 0, 4, false);
        heroin.addIngredient(new ItemStack(Material.EMERALD, 38));
        pluginTrades.add(heroin);

        // Cannabis getrocknet: 20 Emeralds → 1 Cannabis
        MerchantRecipe cannabis = new MerchantRecipe(im.createHerbDried(1), 0, 6, false);
        cannabis.addIngredient(new ItemStack(Material.EMERALD, 20));
        pluginTrades.add(cannabis);

        // Leaf: 30 Emeralds → 1 Leaf
        MerchantRecipe leaf = new MerchantRecipe(im.createLeaf(1), 0, 3, false);
        leaf.addIngredient(new ItemStack(Material.EMERALD, 30));
        pluginTrades.add(leaf);

        // Zufällig 1-2 Trades hinzufügen
        java.util.Collections.shuffle(pluginTrades);
        int count = 1 + java.util.concurrent.ThreadLocalRandom.current().nextInt(2);
        for (int i = 0; i < count && i < pluginTrades.size(); i++) {
            recipes.add(pluginTrades.get(i));
        }

        trader.setRecipes(recipes);

        // Fumot 12k: GARANTIERT mindestens 1 Trade, unabhängig vom Zufalls-Pool oben.
        // 12 Emeralds → 1 Fumot 12k
        List<MerchantRecipe> withFumot = new ArrayList<>(trader.getRecipes());
        MerchantRecipe fumot = new MerchantRecipe(im.createFumot(), 0, 4, false);
        fumot.addIngredient(new ItemStack(Material.EMERALD, 12));
        withFumot.add(fumot);
        trader.setRecipes(withFumot);

        // Vape Vozol 40k: 40% Chance, unabhängig von den 1-2 zufälligen Trades oben.
        // 20 Emeralds → 1 Vape Vozol 40k (400 Züge, Akku reicht für 150 Züge/Ladung)
        if (java.util.concurrent.ThreadLocalRandom.current().nextDouble() < 0.40) {
            List<MerchantRecipe> withVozol = new ArrayList<>(trader.getRecipes());
            MerchantRecipe vozol = new MerchantRecipe(im.createVozol(), 0, 4, false);
            vozol.addIngredient(new ItemStack(Material.EMERALD, 20));
            withVozol.add(vozol);
            trader.setRecipes(withVozol);
        }

        // Vape Randm 15k: 45% Chance, unabhängig von den anderen Trades.
        // 15 Emeralds → 1 Vape Randm 15k (zufällige Sorte, 150 Liquid, Akku reicht für 50/Ladung)
        if (java.util.concurrent.ThreadLocalRandom.current().nextDouble() < 0.45) {
            de.soos.smokeaddiction.model.VapeFlavor[] flavors =
                    de.soos.smokeaddiction.model.VapeFlavor.randmFlavors();
            de.soos.smokeaddiction.model.VapeFlavor flavor =
                    flavors[java.util.concurrent.ThreadLocalRandom.current().nextInt(flavors.length)];
            List<MerchantRecipe> withRandm = new ArrayList<>(trader.getRecipes());
            MerchantRecipe randm = new MerchantRecipe(im.createRandm(flavor), 0, 4, false);
            randm.addIngredient(new ItemStack(Material.EMERALD, 15));
            withRandm.add(randm);
            trader.setRecipes(withRandm);
        }
    }
}
