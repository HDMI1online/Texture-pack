package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Lädt und speichert PlayerData persistent als YAML.
 * Pro Spieler wird eine Datei in plugins/SmokeAddiction/players/<uuid>.yml gehalten.
 */
public class PlayerDataManager {

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    private final File folder;

    public PlayerDataManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "players");
        if (!folder.exists() && !folder.mkdirs()) {
            plugin.getLogger().warning("Konnte Spielerdaten-Ordner nicht erstellen: " + folder);
        }
    }

    /** Liefert PlayerData aus dem Cache oder lädt sie aus der Datei (oder erstellt neue). */
    public PlayerData get(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data != null) return data;
        data = load(uuid);
        cache.put(uuid, data);
        return data;
    }

    public PlayerData get(Player player) {
        return get(player.getUniqueId());
    }

    private PlayerData load(UUID uuid) {
        File file = new File(folder, uuid + ".yml");
        if (!file.exists()) {
            return new PlayerData(uuid);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        PlayerData d = new PlayerData(uuid);
        d.setAddicted(cfg.getBoolean("addicted", false));
        d.setAddictionLevel(cfg.getInt("addictionLevel", 0));
        d.setTotalCigarettesSmoked(cfg.getInt("totalCigarettesSmoked", 0));
        d.setNicotineLevel(cfg.getDouble("nicotineLevel", 0.0));
        d.setLastDecayMillis(cfg.getLong("lastDecayMillis", System.currentTimeMillis()));
        d.setWithdrawalStartMillis(cfg.getLong("withdrawalStartMillis", 0L));
        d.setInWithdrawal(cfg.getBoolean("inWithdrawal", false));
        d.setShishaUsed(cfg.getBoolean("shishaUsed", false));
        d.setVapeUsed(cfg.getBoolean("vapeUsed", false));
        d.setBloodAlcohol(cfg.getDouble("bloodAlcohol", 0.0));
        d.setLastAlcDecayMillis(cfg.getLong("lastAlcDecayMillis", System.currentTimeMillis()));
        d.setHerbBuffUntilMillis(cfg.getLong("herbBuffUntilMillis", 0L));
        d.setHerbWithdrawalUntilMillis(cfg.getLong("herbWithdrawalUntilMillis", 0L));

        org.bukkit.configuration.ConfigurationSection effSec =
                cfg.getConfigurationSection("substanceEffectUntil");
        if (effSec != null) {
            for (String key : effSec.getKeys(false)) {
                try {
                    d.getSubstanceEffectUntilMap().put(
                            de.soos.smokeaddiction.model.SubstanceType.valueOf(key), effSec.getLong(key));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        org.bukkit.configuration.ConfigurationSection witSec =
                cfg.getConfigurationSection("substanceWithdrawalUntil");
        if (witSec != null) {
            for (String key : witSec.getKeys(false)) {
                try {
                    d.getSubstanceWithdrawalUntilMap().put(
                            de.soos.smokeaddiction.model.SubstanceType.valueOf(key), witSec.getLong(key));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        d.setMonsterStacks(cfg.getInt("monsterStacks", 0));
        d.setMonsterUntilMillis(cfg.getLong("monsterUntilMillis", 0L));
        d.setResourcePackDisabled(cfg.getBoolean("resourcePackDisabled", false));
        d.setTutorialSeen(cfg.getBoolean("tutorialSeen", false));
        d.setScoreboardHidden(cfg.getBoolean("scoreboardHidden", false));
        d.setPvpKills(cfg.getInt("pvpKills", 0));
        d.setTotalDeaths(cfg.getInt("totalDeaths", 0));
        return d;
    }

    public void save(UUID uuid) {
        PlayerData d = cache.get(uuid);
        if (d == null) return;
        File file = new File(folder, uuid + ".yml");
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("addicted", d.isAddicted());
        cfg.set("addictionLevel", d.getAddictionLevel());
        cfg.set("totalCigarettesSmoked", d.getTotalCigarettesSmoked());
        cfg.set("nicotineLevel", d.getNicotineLevel());
        cfg.set("lastDecayMillis", d.getLastDecayMillis());
        cfg.set("withdrawalStartMillis", d.getWithdrawalStartMillis());
        cfg.set("inWithdrawal", d.isInWithdrawal());
        cfg.set("shishaUsed", d.hasUsedShisha());
        cfg.set("vapeUsed", d.hasUsedVape());
        cfg.set("bloodAlcohol", d.getBloodAlcohol());
        cfg.set("lastAlcDecayMillis", d.getLastAlcDecayMillis());
        cfg.set("herbBuffUntilMillis", d.getHerbBuffUntilMillis());
        cfg.set("herbWithdrawalUntilMillis", d.getHerbWithdrawalUntilMillis());
        for (var e : d.getSubstanceEffectUntilMap().entrySet()) {
            cfg.set("substanceEffectUntil." + e.getKey().name(), e.getValue());
        }
        for (var e : d.getSubstanceWithdrawalUntilMap().entrySet()) {
            cfg.set("substanceWithdrawalUntil." + e.getKey().name(), e.getValue());
        }
        cfg.set("monsterStacks", d.getMonsterStacks());
        cfg.set("monsterUntilMillis", d.getMonsterUntilMillis());
        cfg.set("resourcePackDisabled", d.isResourcePackDisabled());
        cfg.set("tutorialSeen", d.hasTutorialSeen());
        cfg.set("scoreboardHidden", d.isScoreboardHidden());
        cfg.set("pvpKills", d.getPvpKills());
        cfg.set("totalDeaths", d.getTotalDeaths());
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Fehler beim Speichern von " + uuid, e);
        }
    }

    public void saveAll() {
        for (UUID uuid : cache.keySet()) {
            save(uuid);
        }
    }

    /** Spieler hat sich ausgeloggt – Daten speichern und aus dem Cache entfernen. */
    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
    }

    public Map<UUID, PlayerData> getCache() { return cache; }
}
