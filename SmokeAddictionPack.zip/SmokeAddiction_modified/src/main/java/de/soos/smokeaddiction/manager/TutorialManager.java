package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.Title.Times;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Zeigt neuen Spielern (oder auf Anfrage via /sa tutorial) eine
 * animierte Einführung ins SmokeAddiction-System.
 *
 * Die Sequenz besteht aus Slides – jede hat:
 *  - startTick: ab welchem Tick sie aktiv wird (20 Ticks = 1s)
 *  - title   : großer Title-Text
 *  - subtitle: kleiner Untertitel
 *  - chat    : einmalige Chat-Zeile ~0.75s nach Slide-Start (oder null)
 *  - sound   : Sound beim Slide-Start (oder null)
 */
public class TutorialManager {

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, BukkitTask> running = new HashMap<>();

    private static final Slide[] SLIDES = {
        new Slide( 0,
            Component.text("SmokeAddiction", NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true),
            Component.text("Willkommen auf dem Server!", NamedTextColor.GRAY),
            null,
            Sound.BLOCK_NOTE_BLOCK_HARP),
        new Slide(30,
            Component.text("Zigaretten", NamedTextColor.YELLOW).decoration(TextDecoration.BOLD, true),
            Component.text("Beim Zigaretten-Händler in der City kaufen.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Jede Zigarette erhöht deine ", NamedTextColor.GRAY))
                .append(Component.text("Nikotin-Sucht", NamedTextColor.RED))
                .append(Component.text(" – 5 Stufen!", NamedTextColor.GRAY)),
            Sound.ENTITY_EXPERIENCE_ORB_PICKUP),
        new Slide(60,
            Component.text("Vapes", NamedTextColor.AQUA).decoration(TextDecoration.BOLD, true),
            Component.text("Beim Vape-Händler oder Wandernden Händler.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Elfbar · Fumot 12k · Vozol 40k · Randm 15k", NamedTextColor.WHITE)),
            Sound.ENTITY_EXPERIENCE_ORB_PICKUP),
        new Slide(90,
            Component.text("Substanzen", NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.BOLD, true),
            Component.text("In Mineshaft-Truhen & Nether-Bastionen.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Kokain · LSD · Crack · Heroin · Magic Mushrooms", NamedTextColor.RED)),
            Sound.ENTITY_PLAYER_BREATH),
        new Slide(120,
            Component.text("Cannabis", NamedTextColor.GREEN).decoration(TextDecoration.BOLD, true),
            Component.text("Wächst wild in Dschungel & Savanne.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Joint rauchen → Regeneration II, danach 4 Min. kein Heilen", NamedTextColor.GREEN)),
            Sound.BLOCK_GRASS_PLACE),
        new Slide(150,
            Component.text("Alkohol & Energy", NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true),
            Component.text("Beim Getränke-Händler in der City.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Bier & Jäger = Promille  ·  ", NamedTextColor.YELLOW))
                .append(Component.text("Monster White", NamedTextColor.WHITE))
                .append(Component.text(" = Speed & Schild", NamedTextColor.AQUA)),
            Sound.ENTITY_GENERIC_DRINK),
        new Slide(180,
            Component.text("Cities & Dealer-Dörfer", NamedTextColor.YELLOW).decoration(TextDecoration.BOLD, true),
            Component.text("Entstehen automatisch in der Welt.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("City", NamedTextColor.YELLOW))
                .append(Component.text(": Händler + Casino  ·  ", NamedTextColor.GRAY))
                .append(Component.text("Dealer-Dorf", NamedTextColor.RED))
                .append(Component.text(": tief im Mineshaft", NamedTextColor.GRAY)),
            Sound.BLOCK_BELL_USE),
        new Slide(210,
            Component.text("Nikotin-Entzug", NamedTextColor.RED).decoration(TextDecoration.BOLD, true),
            Component.text("Vergiss nicht zu rauchen …", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Ohne Zigarette sinkt der Spiegel – ", NamedTextColor.GRAY))
                .append(Component.text("Entzug", NamedTextColor.RED))
                .append(Component.text(" droht!", NamedTextColor.GRAY)),
            Sound.ENTITY_WITHER_HURT),
        new Slide(240,
            Component.text("Viel Spaß!", NamedTextColor.GREEN).decoration(TextDecoration.BOLD, true),
            Component.text("Du weißt jetzt alles Wichtige.", NamedTextColor.GRAY),
            Component.text("» ", NamedTextColor.DARK_GRAY)
                .append(Component.text("Tipp: ", NamedTextColor.GRAY))
                .append(Component.text("/sa tutorial", NamedTextColor.AQUA))
                .append(Component.text(" um das Tutorial erneut zu sehen.", NamedTextColor.GRAY)),
            Sound.UI_TOAST_CHALLENGE_COMPLETE),
        new Slide(270, null, null, null, null), // Ende-Marker
    };

    public TutorialManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isRunning(Player p) {
        return running.containsKey(p.getUniqueId());
    }

    public void stop(Player p) {
        BukkitTask task = running.remove(p.getUniqueId());
        if (task != null) task.cancel();
        p.clearTitle();
        p.sendMessage(Component.text("Tutorial übersprungen.", NamedTextColor.GRAY));
    }

    public void start(Player p) {
        BukkitTask old = running.remove(p.getUniqueId());
        if (old != null) old.cancel();

        p.sendMessage(Component.empty());
        p.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
        p.sendMessage(Component.text("   ★  SmokeAddiction – Einführung  ★", NamedTextColor.YELLOW)
                .decoration(TextDecoration.BOLD, true));
        p.sendMessage(Component.text("   Tippe ", NamedTextColor.GRAY)
                .append(Component.text("/sa tutorial skip", NamedTextColor.WHITE))
                .append(Component.text(" zum Überspringen.", NamedTextColor.GRAY)));
        p.sendMessage(Component.text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", NamedTextColor.GOLD));
        p.sendMessage(Component.empty());

        BukkitTask task = new BukkitRunnable() {
            int tick = 0;
            int slideIdx = 0;

            @Override
            public void run() {
                if (!p.isOnline()) { cancel(); running.remove(p.getUniqueId()); return; }

                // Auf nächste Slide vorschalten?
                while (slideIdx + 1 < SLIDES.length
                        && tick >= SLIDES[slideIdx + 1].startTick) {
                    slideIdx++;
                }

                Slide slide = SLIDES[slideIdx];

                // Ende-Slide
                if (slide.title == null) {
                    p.clearTitle();
                    plugin.getPlayerDataManager().get(p).setTutorialSeen(true);
                    running.remove(p.getUniqueId());
                    cancel();
                    return;
                }

                int localTick = tick - slide.startTick;

                // Auf Slide-Start: Title anzeigen, Chat-Zeile und Sound abspielen
                if (localTick == 0) {
                    int nextStart = SLIDES[Math.min(slideIdx + 1, SLIDES.length - 1)].startTick;
                    int displayMs = Math.max(500, (nextStart - slide.startTick - 3) * 50);

                    Times times = Times.times(
                            Duration.ofMillis(200),
                            Duration.ofMillis(displayMs),
                            Duration.ofMillis(400));
                    p.showTitle(Title.title(slide.title, slide.subtitle, times));

                    if (slide.chat != null) {
                        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                            if (p.isOnline()) p.sendMessage(slide.chat);
                        }, 15L);
                    }
                    if (slide.sound != null) {
                        p.playSound(p.getLocation(), slide.sound, 1.0f, 1.0f);
                    }
                }

                // Dezente Rauch-Partikel kontinuierlich
                if (tick % 8 == 0) {
                    p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                            p.getEyeLocation().add(0.0, 0.5, 0.0),
                            2, 0.2, 0.2, 0.2, 0.01);
                }

                tick++;
            }
        }.runTaskTimer(plugin, 20L, 1L);

        running.put(p.getUniqueId(), task);
    }

    private record Slide(int startTick, Component title, Component subtitle,
                         Component chat, Sound sound) {}
}
