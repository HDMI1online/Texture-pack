package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.CigaretteBrand;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapelessRecipe;

/**
 * Registriert und entfernt Bukkit-Crafting-Rezepte.
 *
 * Aktuell: 1 Tabakblatt (DRIED_KELP) + 1 Papier -> 1 selbstgedrehte Zigarette.
 * Ein zusätzlicher CraftingListener prüft per PrepareItemCraftEvent den
 * PersistentDataContainer der Zutaten, damit normales Vanilla-DRIED_KELP
 * NICHT als Tabak akzeptiert wird.
 */
public class RecipeManager {

    private final SmokeAddictionPlugin plugin;
    private NamespacedKey selfmadeKey;
    private NamespacedKey shishaKey;
    private NamespacedKey dryKey;
    private NamespacedKey jointKey;
    private NamespacedKey dryHerbKey;
    private NamespacedKey rauchzuckerCigKey;
    private NamespacedKey leafCigKey;
    private NamespacedKey magicMushroomKey;
    private final java.util.List<NamespacedKey> packKeys = new java.util.ArrayList<>();

    public RecipeManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public void registerRecipes() {
        selfmadeKey = new NamespacedKey(plugin, "selfmade_cigarette");
        shishaKey   = new NamespacedKey(plugin, "shisha");
        dryKey      = new NamespacedKey(plugin, "dry_tobacco");
        jointKey    = new NamespacedKey(plugin, "herb_joint");
        dryHerbKey  = new NamespacedKey(plugin, "dry_herb");
        rauchzuckerCigKey = new NamespacedKey(plugin, "rauchzucker_cig");
        leafCigKey        = new NamespacedKey(plugin, "leaf_cig");
        magicMushroomKey  = new NamespacedKey(plugin, "magic_mushroom");

        // === Selbstgedrehte Zigarette ===
        // ExactChoice prüft PDC: nur unser getrockneter Tabak matcht, nicht Vanilla-DRIED_KELP
        ItemStack result = plugin.getItemManager().createCigarette(CigaretteBrand.SELFMADE, 1);
        ShapelessRecipe rec = new ShapelessRecipe(selfmadeKey, result);
        ItemStack tobaccoTemplate = plugin.getItemManager().createTobacco(1);
        ItemStack paperTemplate   = new ItemStack(Material.PAPER);
        RecipeChoice.ExactChoice tobaccoChoice = new RecipeChoice.ExactChoice(tobaccoTemplate);
        rec.addIngredient(tobaccoChoice);
        rec.addIngredient(tobaccoChoice);
        rec.addIngredient(tobaccoChoice);
        RecipeChoice.MaterialChoice paperChoice = new RecipeChoice.MaterialChoice(Material.PAPER);
        rec.addIngredient(paperChoice);
        rec.addIngredient(paperChoice);
        try { Bukkit.removeRecipe(selfmadeKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(rec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Selfmade-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Shisha (2x Output) ===
        ItemStack shishaResult = plugin.getItemManager().createShisha(2);
        ShapelessRecipe shishaRec = new ShapelessRecipe(shishaKey, shishaResult);
        shishaRec.addIngredient(Material.DRAGON_EGG);
        shishaRec.addIngredient(Material.BUCKET);
        shishaRec.addIngredient(Material.END_ROD);
        // Akzeptiert jede POTION-Variante; CraftingListener prüft, ob es eine Mundane Potion ist.
        shishaRec.addIngredient(Material.POTION);
        try { Bukkit.removeRecipe(shishaKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(shishaRec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Shisha-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Tabak trocknen (Ofen) ===
        // Frischer Tabak (Material.SUGAR_CANE mit unserem PDC) -> getrockneter Tabak
        // ExactChoice prüft Item-Ähnlichkeit inkl. Metadaten (PDC), damit Vanilla-Zuckerrohr
        // NICHT versehentlich getrocknet wird.
        ItemStack rawTemplate   = plugin.getItemManager().createTobaccoRaw(1);
        ItemStack driedTemplate = plugin.getItemManager().createTobacco(1);
        try {
            FurnaceRecipe dry = new FurnaceRecipe(dryKey, driedTemplate,
                    new RecipeChoice.ExactChoice(rawTemplate),
                    0.2f, 200);
            try { Bukkit.removeRecipe(dryKey); } catch (Throwable ignored) {}
            Bukkit.addRecipe(dry);
        } catch (Exception ex) {
            plugin.getLogger().warning("Konnte Trockne-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Heilkraut trocknen (Ofen) ===
        ItemStack herbRawTemplate   = plugin.getItemManager().createHerbRaw(1);
        ItemStack herbDriedTemplate = plugin.getItemManager().createHerbDried(1);
        try {
            FurnaceRecipe dryHerb = new FurnaceRecipe(dryHerbKey, herbDriedTemplate,
                    new RecipeChoice.ExactChoice(herbRawTemplate),
                    0.2f, 200);
            try { Bukkit.removeRecipe(dryHerbKey); } catch (Throwable ignored) {}
            Bukkit.addRecipe(dryHerb);
        } catch (Exception ex) {
            plugin.getLogger().warning("Konnte Heilkraut-Trocknen nicht registrieren: " + ex.getMessage());
        }

        // === Joint (Herb-Zigarette) ===
        ItemStack jointResult = plugin.getItemManager().createCigarette(CigaretteBrand.HERB_JOINT, 1);
        ShapelessRecipe jointRec = new ShapelessRecipe(jointKey, jointResult);
        ItemStack herbTemplate = plugin.getItemManager().createHerbDried(1);
        RecipeChoice.ExactChoice herbChoice = new RecipeChoice.ExactChoice(herbTemplate);
        jointRec.addIngredient(herbChoice);
        jointRec.addIngredient(herbChoice);
        jointRec.addIngredient(herbChoice);
        RecipeChoice.MaterialChoice jointPaperChoice = new RecipeChoice.MaterialChoice(Material.PAPER);
        jointRec.addIngredient(jointPaperChoice);
        jointRec.addIngredient(jointPaperChoice);
        try { Bukkit.removeRecipe(jointKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(jointRec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Joint-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Rauchzucker-Zigarette ===
        ItemStack rauchResult = plugin.getItemManager().createCigarette(CigaretteBrand.RAUCHZUCKER_CIG, 1);
        ShapelessRecipe rauchRec = new ShapelessRecipe(rauchzuckerCigKey, rauchResult);
        ItemStack rauchTemplate = plugin.getItemManager().createRauchzucker(1);
        rauchRec.addIngredient(new RecipeChoice.ExactChoice(rauchTemplate));
        RecipeChoice.MaterialChoice rauchPaperChoice = new RecipeChoice.MaterialChoice(Material.PAPER);
        rauchRec.addIngredient(rauchPaperChoice);
        rauchRec.addIngredient(rauchPaperChoice);
        try { Bukkit.removeRecipe(rauchzuckerCigKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(rauchRec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Rauchzucker-Cig-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Leaf-Zigarette ===
        ItemStack leafResult = plugin.getItemManager().createCigarette(CigaretteBrand.LEAF_CIG, 1);
        ShapelessRecipe leafRec = new ShapelessRecipe(leafCigKey, leafResult);
        ItemStack leafTemplate = plugin.getItemManager().createLeaf(1);
        leafRec.addIngredient(new RecipeChoice.ExactChoice(leafTemplate));
        RecipeChoice.MaterialChoice leafPaperChoice = new RecipeChoice.MaterialChoice(Material.PAPER);
        leafRec.addIngredient(leafPaperChoice);
        leafRec.addIngredient(leafPaperChoice);
        try { Bukkit.removeRecipe(leafCigKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(leafRec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Leaf-Cig-Recipe nicht registrieren: " + ex.getMessage());
        }

        // === Magic Mushroom ===
        // 1× Vanilla-Pilz (rot oder braun) + 5× Cannabis getrocknet → 1× Magic Mushroom
        ItemStack mmResult = plugin.getItemManager().createMagicMushroom(1);
        ShapelessRecipe mmRec = new ShapelessRecipe(magicMushroomKey, mmResult);
        ItemStack cannabisDriedTemplate = plugin.getItemManager().createHerbDried(1);
        mmRec.addIngredient(new RecipeChoice.MaterialChoice(
                Material.RED_MUSHROOM, Material.BROWN_MUSHROOM));
        RecipeChoice.ExactChoice cannabisChoice = new RecipeChoice.ExactChoice(cannabisDriedTemplate);
        mmRec.addIngredient(cannabisChoice);
        mmRec.addIngredient(cannabisChoice);
        mmRec.addIngredient(cannabisChoice);
        mmRec.addIngredient(cannabisChoice);
        mmRec.addIngredient(cannabisChoice);
        try { Bukkit.removeRecipe(magicMushroomKey); } catch (Throwable ignored) {}
        try { Bukkit.addRecipe(mmRec); }
        catch (Exception ex) {
            plugin.getLogger().warning("Konnte Magic-Mushroom-Recipe nicht registrieren: " + ex.getMessage());
        }

        // Schachtel-Rezept: 8x Zigarette (gleiche Marke) + 1x Paper = 1 volle Schachtel
        for (de.soos.smokeaddiction.model.CigaretteBrand brand : de.soos.smokeaddiction.model.CigaretteBrand.values()) {
            NamespacedKey packKey = new NamespacedKey(plugin, "pack_" + brand.name().toLowerCase());
            packKeys.add(packKey);
            ShapelessRecipe packRec = new ShapelessRecipe(
                    packKey, plugin.getItemManager().createPack(brand, 8));
            RecipeChoice.ExactChoice cigChoice = new RecipeChoice.ExactChoice(
                    plugin.getItemManager().createCigarette(brand, 1));
            for (int i = 0; i < 8; i++) packRec.addIngredient(cigChoice);
            packRec.addIngredient(new RecipeChoice.MaterialChoice(Material.PAPER));
            try { Bukkit.addRecipe(packRec); }
            catch (Exception ex) {
                plugin.getLogger().warning("Schachtel-Rezept " + brand + " konnte nicht registriert werden: " + ex.getMessage());
            }
        }
    }

    public void unregisterRecipes() {
        if (selfmadeKey != null) {
            try { Bukkit.removeRecipe(selfmadeKey); } catch (Throwable ignored) {}
        }
        if (shishaKey != null) {
            try { Bukkit.removeRecipe(shishaKey); } catch (Throwable ignored) {}
        }
        if (dryKey != null) {
            try { Bukkit.removeRecipe(dryKey); } catch (Throwable ignored) {}
        }
        if (jointKey != null) {
            try { Bukkit.removeRecipe(jointKey); } catch (Throwable ignored) {}
        }
        if (dryHerbKey != null) {
            try { Bukkit.removeRecipe(dryHerbKey); } catch (Throwable ignored) {}
        }
        if (rauchzuckerCigKey != null) {
            try { Bukkit.removeRecipe(rauchzuckerCigKey); } catch (Throwable ignored) {}
        }
        if (leafCigKey != null) {
            try { Bukkit.removeRecipe(leafCigKey); } catch (Throwable ignored) {}
        }
        for (NamespacedKey k : packKeys) {
            try { Bukkit.removeRecipe(k); } catch (Throwable ignored) {}
        }
    }

    public NamespacedKey getSelfmadeKey() { return selfmadeKey; }
    public NamespacedKey getShishaKey()   { return shishaKey; }
    public NamespacedKey getJointKey()    { return jointKey; }
    public NamespacedKey getRauchzuckerCigKey() { return rauchzuckerCigKey; }
    public NamespacedKey getLeafCigKey()        { return leafCigKey; }

    /** Schaltet alle Plugin-Rezepte im Rezeptbuch des Spielers frei. */
    public void discoverAll(org.bukkit.entity.Player p) {
        java.util.List<NamespacedKey> keys = new java.util.ArrayList<>();
        if (selfmadeKey       != null) keys.add(selfmadeKey);
        if (shishaKey         != null) keys.add(shishaKey);
        if (jointKey          != null) keys.add(jointKey);
        if (rauchzuckerCigKey != null) keys.add(rauchzuckerCigKey);
        if (leafCigKey        != null) keys.add(leafCigKey);
        if (magicMushroomKey  != null) keys.add(magicMushroomKey);
        if (dryKey            != null) keys.add(dryKey);
        if (dryHerbKey        != null) keys.add(dryHerbKey);
        for (NamespacedKey k : keys) {
            try { p.discoverRecipe(k); } catch (Throwable ignored) {}
        }
    }
}
