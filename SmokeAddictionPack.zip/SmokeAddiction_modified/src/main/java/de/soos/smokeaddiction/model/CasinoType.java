package de.soos.smokeaddiction.model;

import org.bukkit.Material;

/**
 * Verschiedene Casino-Automaten mit unterschiedlichem Einsatz und Gewinn-Pool.
 * Der Block-Material identifiziert den Typ visuell.
 */
public enum CasinoType {
    BRONZE("Bronze-Slots",     Material.COPPER_BLOCK),
    SILVER("Silber-Slots",     Material.IRON_BLOCK),
    GOLD("Gold-Slots",         Material.GOLD_BLOCK),
    DRUGS("Substanz-Slots",    Material.AMETHYST_BLOCK),
    DRINK("Bar-Slots",         Material.HONEY_BLOCK);

    public final String displayName;
    public final Material blockMaterial;

    CasinoType(String displayName, Material blockMaterial) {
        this.displayName = displayName;
        this.blockMaterial = blockMaterial;
    }

    public static CasinoType fromMaterial(Material m) {
        for (CasinoType t : values()) {
            if (t.blockMaterial == m) return t;
        }
        return null;
    }
}
