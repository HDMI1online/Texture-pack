package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;

import java.net.URI;
import java.util.UUID;

/**
 * Erzwingt das SmokeAddiction Resource Pack beim Login.
 * Verwendet die Adventure-ResourcePackRequest-API (Paper 1.20.5+).
 */
public class ResourcePackListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public ResourcePackListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();

        if (plugin.getConfig().getBoolean("resource-pack.enabled", true)
                // Persönliche Opt-Out-Präferenz: hat der Spieler das Pack für sich selbst
                // deaktiviert (/sa resourcepack disable), wird es ihm beim Login nicht
                // aufgedrängt – andere Spieler sind davon unberührt.
                && !plugin.getPlayerDataManager().get(p).isResourcePackDisabled()) {
            pushPack(p);
        }

        // Hinweis auf den Command für alle Spieler – 10s Verzögerung,
        // damit er nicht sofort im Login-Rauschen untergeht.
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            p.sendMessage(Component.text("Resource Pack: ", NamedTextColor.GRAY)
                    .append(Component.text("/sa resourcepack <enable|disable|load>",
                            NamedTextColor.AQUA))
                    .append(Component.text(" zum An-/Abschalten oder einmaligen Laden für dich.",
                            NamedTextColor.GRAY)));
        }, 200L); // 10 Sekunden
    }

    /**
     * Schickt das Resource Pack an einen Spieler. Wird vom Login-Handler aufgerufen
     * (wenn resource-pack.enabled true ist), kann aber auch unabhängig vom
     * enabled-Status manuell ausgelöst werden (siehe {@code /sa resourcepack load}
     * in {@link SmokeCommand}).
     */
    public void pushPack(Player p) {
        String url    = plugin.getConfig().getString("resource-pack.url", "");
        String hashHx = plugin.getConfig().getString("resource-pack.hash", "");
        String prompt = plugin.getConfig().getString("resource-pack.prompt",
                "Dieses Resource Pack ist für das Rauch-System erforderlich.");
        long delay    = plugin.getConfig().getLong("resource-pack.delay-ticks", 20L);

        if (url == null || url.isBlank() || url.startsWith("https://EXAMPLE.COM")) {
            plugin.getLogger().warning("resource-pack.url ist nicht gesetzt – "
                    + "Pack wird NICHT erzwungen. Bitte config.yml anpassen.");
            return;
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            try {
                ResourcePackInfo.Builder infoBuilder = ResourcePackInfo.resourcePackInfo()
                        .id(UUID.nameUUIDFromBytes(url.getBytes()))
                        .uri(URI.create(url));

                String cleanHash = (hashHx != null) ? hashHx.trim() : "";
                if (!cleanHash.isEmpty()) {
                    infoBuilder.hash(cleanHash);
                }

                ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                        .packs(infoBuilder.build())
                        .prompt(Component.text(prompt))
                        .required(true)
                        .build();

                p.sendResourcePacks(request);
            } catch (Throwable ex) {
                plugin.getLogger().warning("Pack-Push fehlgeschlagen für "
                        + p.getName() + ": " + ex.getMessage());
            }
        }, delay);
    }

    @EventHandler
    public void onStatus(PlayerResourcePackStatusEvent e) {
        if (!plugin.getConfig().getBoolean("resource-pack.enabled", true)) return;

        Player p = e.getPlayer();
        switch (e.getStatus()) {
            case DECLINED:
                p.kick(Component.text("Du musst das Resource Pack akzeptieren, um zu spielen.",
                        NamedTextColor.RED));
                break;
            case FAILED_DOWNLOAD:
                p.kick(Component.text("Resource Pack konnte nicht heruntergeladen werden. "
                        + "Bitte erneut verbinden.", NamedTextColor.RED));
                break;
            case ACCEPTED:
            case SUCCESSFULLY_LOADED:
            default:
                // ok
        }
    }
}
