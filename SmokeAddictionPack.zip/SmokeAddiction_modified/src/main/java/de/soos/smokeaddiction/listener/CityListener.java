package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Triggert die Generierung einer City bei zufällig ausgewählten neu geladenen Chunks.
 *
 * Wahrscheinlichkeit: 0.1 % pro neuem Chunk in geeigneten Biomen
 * (= ähnlich selten wie Vanilla-Dörfer).
 *
 * Mindestabstand zwischen zwei Cities: 1500 Blöcke (über CityRegistry).
 */
public class CityListener implements Listener {

    private static final double SPAWN_CHANCE = 0.0025; // war 0.005 → halbiert

    /** Biome, in denen Cities entstehen können (relativ flach + offen). */
    private static final Set<Biome> CITY_BIOMES = new java.util.HashSet<>(java.util.Arrays.asList(
            Biome.PLAINS, Biome.SUNFLOWER_PLAINS,
            Biome.SAVANNA, Biome.SAVANNA_PLATEAU,
            Biome.MEADOW, Biome.FOREST, Biome.BIRCH_FOREST,
            Biome.DARK_FOREST
    ));

    private final SmokeAddictionPlugin plugin;

    public CityListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        // isNewChunk() ist in 1.21.x unzuverlässig (Mojang hat die Semantik geändert).
        // Wir verlassen uns auf die Distanzprüfung in CityRegistry, um Doppel-Spawns zu vermeiden.
        Chunk c = e.getChunk();
        World w = c.getWorld();

        // Nur in der Overworld
        if (w.getEnvironment() != World.Environment.NORMAL) return;

        if (ThreadLocalRandom.current().nextDouble() > SPAWN_CHANCE) return;

        int cx = c.getX() * 16 + 8;
        int cz = c.getZ() * 16 + 8;
        int cy = w.getHighestBlockYAt(cx, cz);

        // Nur in passenden Biomen
        Biome b = w.getBiome(cx, cy, cz);
        if (!CITY_BIOMES.contains(b)) return;

        Location loc = new Location(w, cx, cy, cz);
        if (plugin.getCityRegistry().isCityNearby(loc)) return;

        // Ozean oder Wasser-nahes Spawn vermeiden
        if (cy < 60) return;

        // Build im nächsten Tick triggern
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getCityGenerator().buildCity(loc);
            plugin.getLogger().info("City wird gebaut bei "
                    + cx + "/" + cy + "/" + cz + " (Biom: " + b + ")");
        });
    }
}
