package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Speichert Locations aller natürlich gespawnten Tabak-Bushes.
 * Analog zur HerbBushRegistry – damit man beim Abbauen unterscheiden kann
 * ob ein Sweet-Berry-Bush vom Spieler gepflanzt wurde (→ vanilla Beeren)
 * oder natürlich als Tabak gespawnt ist (→ Tabak-Drop).
 */
public class TobaccoBushRegistry {

    private final SmokeAddictionPlugin plugin;
    private final File file;
    private final Set<String> entries = new HashSet<>();

    public TobaccoBushRegistry(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "tobacco_bushes.yml");
        load();
    }

    private static String key(World w, int x, int y, int z) {
        return w.getUID() + ":" + x + "," + y + "," + z;
    }
    private static String key(Location loc) {
        return key(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    private static String key(Block b) {
        return key(b.getWorld(), b.getX(), b.getY(), b.getZ());
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        List<String> list = cfg.getStringList("entries");
        entries.addAll(list);
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("entries", new ArrayList<>(entries));
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Konnte tobacco_bushes.yml nicht speichern: " + e.getMessage());
        }
    }

    public boolean isTobacco(Block b)    { return entries.contains(key(b)); }
    public boolean isTobacco(Location l) { return entries.contains(key(l)); }

    public void register(Block b)        { entries.add(key(b)); }
    public void register(Location l)     { entries.add(key(l)); }

    public void unregister(Block b)      { entries.remove(key(b)); }
    public void unregister(Location l)   { entries.remove(key(l)); }

    public int size() { return entries.size(); }
}
