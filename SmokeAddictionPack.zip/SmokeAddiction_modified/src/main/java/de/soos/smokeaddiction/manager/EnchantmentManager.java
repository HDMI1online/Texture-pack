package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.util.Keys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * Verwaltet Custom-Enchantments für Zigaretten/Joints (Munis I-III) und
 * Vapes (Haltbarkeit, Mehr Rauch).
 *
 * Statt Vanilla-Enchantments zu missbrauchen oder NMS-Custom-Enchants zu registrieren,
 * speichern wir Enchant-Level in PDC-Tags. Das Item bekommt zusätzlich UNBREAKING
 * (rein cosmetisch für den Glanz-Effekt) und versteckt die Anzeige via HIDE_ENCHANTS,
 * stattdessen wird im Lore unsere Custom-Anzeige geschrieben.
 */
public class EnchantmentManager {

    public enum EnchantType {
        MUNIS("Munis", 3),
        DURABILITY("Haltbarkeit", 1),
        MORE_SMOKE("Mehr Rauch", 1);

        public final String displayName;
        public final int maxLevel;
        EnchantType(String n, int max) { this.displayName = n; this.maxLevel = max; }
    }

    private final SmokeAddictionPlugin plugin;

    public EnchantmentManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public int getMunis(ItemStack item)      { return getLevel(item, Keys.ENCH_MUNIS); }
    public int getDurability(ItemStack item) { return getLevel(item, Keys.ENCH_DURABILITY); }
    public int getMoreSmoke(ItemStack item)  { return getLevel(item, Keys.ENCH_MORE_SMOKE); }

    private int getLevel(ItemStack item, org.bukkit.NamespacedKey key) {
        if (item == null || !item.hasItemMeta()) return 0;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        Integer v = pdc.get(key, PersistentDataType.INTEGER);
        return v != null ? v : 0;
    }

    /** Setzt einen Enchant-Level auf das Item, aktualisiert Lore und Glow. */
    public void apply(ItemStack item, EnchantType type, int level) {
        if (item == null) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        org.bukkit.NamespacedKey key = switch (type) {
            case MUNIS      -> Keys.ENCH_MUNIS;
            case DURABILITY -> Keys.ENCH_DURABILITY;
            case MORE_SMOKE -> Keys.ENCH_MORE_SMOKE;
        };
        meta.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, level);

        // Spezialfall: Haltbarkeit auf Vape → Puffs auffüllen auf 120
        if (type == EnchantType.DURABILITY) {
            Integer puffs = meta.getPersistentDataContainer()
                    .get(Keys.VAPE_PUFFS, PersistentDataType.INTEGER);
            if (puffs != null) {
                meta.getPersistentDataContainer().set(Keys.VAPE_PUFFS,
                        PersistentDataType.INTEGER, Math.min(120, puffs + 60));
            }
        }

        // Cosmetisches Glow-Enchant
        if (!meta.hasEnchant(Enchantment.UNBREAKING)) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        item.setItemMeta(meta);
        rebuildLore(item);
    }

    /**
     * Schreibt die Custom-Enchant-Anzeige im Lore über die existierenden
     * Beschreibungs-Zeilen (am Anfang).
     */
    public void rebuildLore(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();

        // Existierende Lore lesen, eigene Enchant-Zeilen rausfiltern
        List<Component> oldLore = meta.lore();
        List<Component> newLore = new ArrayList<>();
        if (oldLore != null) {
            for (Component c : oldLore) {
                String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                        .plainText().serialize(c);
                // Enchant-Zeilen erkennen wir am Präfix "✦ "
                if (plain.startsWith("✦ ")) continue;
                newLore.add(c);
            }
        }

        // Aktuelle Enchant-Zeilen oben einsetzen
        List<Component> enchantLines = new ArrayList<>();
        int munis = getLevel(item, Keys.ENCH_MUNIS);
        if (munis > 0) {
            enchantLines.add(Component.text("✦ Munis " + roman(munis))
                    .color(NamedTextColor.LIGHT_PURPLE)
                    .decoration(TextDecoration.ITALIC, false));
        }
        int dur = getLevel(item, Keys.ENCH_DURABILITY);
        if (dur > 0) {
            enchantLines.add(Component.text("✦ Haltbarkeit " + roman(dur))
                    .color(NamedTextColor.LIGHT_PURPLE)
                    .decoration(TextDecoration.ITALIC, false));
        }
        int smoke = getLevel(item, Keys.ENCH_MORE_SMOKE);
        if (smoke > 0) {
            enchantLines.add(Component.text("✦ Mehr Rauch " + roman(smoke))
                    .color(NamedTextColor.LIGHT_PURPLE)
                    .decoration(TextDecoration.ITALIC, false));
        }

        // Enchant-Zeilen am Anfang (vor dem rest) einsetzen
        if (!enchantLines.isEmpty()) {
            enchantLines.add(Component.empty());
        }
        enchantLines.addAll(newLore);
        meta.lore(enchantLines);
        item.setItemMeta(meta);
    }

    private String roman(int n) {
        switch (n) {
            case 1: return "I";
            case 2: return "II";
            case 3: return "III";
            case 4: return "IV";
            case 5: return "V";
            default: return String.valueOf(n);
        }
    }
}
