package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Verwaltet die Nikotin-Leiste (BossBar), den natürlichen Abbau,
 * Entzugserscheinungen und Sucht-Stufen-Aufstieg/-Abstieg.
 *
 * Die Nikotin-Leiste wird als BossBar angezeigt – das ist die nächst-mögliche
 * Equivalent zu "unter der Hungerbar" innerhalb der Bukkit/Paper-API.
 */
public class NicotineManager {

    private final SmokeAddictionPlugin plugin;
    private final PlayerDataManager playerDataManager;

    // BossBar: Nikotin-Level (nur wenn süchtig)
    private final Map<UUID, BossBar> bossBars = new HashMap<>();
    // BossBar: Nikotin-Entzug (GOLD, nur während Entzug)
    private final Map<UUID, BossBar> withdrawalBars = new HashMap<>();
    // Zeitstempel Entzug-Start für Progress
    private final Map<UUID, Long> withdrawalBarStart = new HashMap<>();

    // 20 Minuten Entzug ohne Konsum -> Heilung (Stufe sinkt)
    public static final long WITHDRAWAL_HEAL_MILLIS = 5L * 60L * 1000L;

    // Max. Speed-Effekt-Amplifier (entspricht Speed 4 → amplifier 3)
    public static final int MAX_SPEED_AMPLIFIER = 3;

    public NicotineManager(SmokeAddictionPlugin plugin, PlayerDataManager pdm) {
        this.plugin = plugin;
        this.playerDataManager = pdm;
    }

    // === BossBar ===

    /** Erstellt/zeigt die Bar für süchtige Spieler, entfernt sie für geheilte. */
    public void updateBossBar(Player player) {
        PlayerData d = playerDataManager.get(player);
        if (!d.isAddicted()) {
            removeBossBar(player);
            return;
        }
        BossBar bar = bossBars.computeIfAbsent(player.getUniqueId(), k -> {
            BossBar b = BossBar.bossBar(Component.empty(), 0f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
            player.showBossBar(b);
            return b;
        });

        float progress = (float) Math.max(0.0, Math.min(1.0, d.getNicotineLevel() / PlayerData.NICOTINE_MAX));
        bar.progress(progress);

        BossBar.Color color;
        if (progress > 0.6f)       color = BossBar.Color.GREEN;
        else if (progress > 0.3f)  color = BossBar.Color.YELLOW;
        else                       color = BossBar.Color.RED;
        bar.color(color);

        Component title = Component.text("Nikotin: ", NamedTextColor.WHITE)
                .append(Component.text(String.format("%.1f / %.0f", d.getNicotineLevel(), PlayerData.NICOTINE_MAX),
                        NamedTextColor.AQUA))
                .append(Component.text("   |   Sucht-Stufe: ", NamedTextColor.GRAY))
                .append(Component.text(String.valueOf(d.getAddictionLevel()),
                        addictionColor(d.getAddictionLevel())));
        bar.name(title);

        // Nikotin-Entzugs-Bar (GOLD)
        if (d.isInWithdrawal()) {
            long now = System.currentTimeMillis();
            long witStart = d.getWithdrawalStartMillis();
            long witEnd   = witStart + WITHDRAWAL_HEAL_MILLIS;
            float witProgress = (WITHDRAWAL_HEAL_MILLIS > 0)
                    ? Math.max(0f, Math.min(1f, (float)(witEnd - now) / WITHDRAWAL_HEAL_MILLIS))
                    : 0f;
            long remMs = Math.max(0, witEnd - now);
            long remSec = remMs / 1000L;
            String timeStr = (remSec >= 60)
                    ? (remSec / 60) + "m " + (remSec % 60 < 10 ? "0" : "") + (remSec % 60) + "s"
                    : remSec + "s";
            Component witTitle = Component.text("Nikotin-Entzug: ", NamedTextColor.GOLD)
                    .append(Component.text(timeStr, NamedTextColor.YELLOW))
                    .append(Component.text("  (Suchtstufe sinkt nach Ablauf)", NamedTextColor.GRAY));
            BossBar witBar = withdrawalBars.computeIfAbsent(player.getUniqueId(), k -> {
                BossBar b = BossBar.bossBar(witTitle, witProgress,
                        BossBar.Color.YELLOW, BossBar.Overlay.NOTCHED_20);
                player.showBossBar(b);
                return b;
            });
            witBar.name(witTitle);
            witBar.progress(witProgress);
        } else {
            BossBar witBar = withdrawalBars.remove(player.getUniqueId());
            if (witBar != null) player.hideBossBar(witBar);
        }
    }

    private NamedTextColor addictionColor(int lvl) {
        switch (lvl) {
            case 1: return NamedTextColor.DARK_RED;
            case 2: return NamedTextColor.RED;
            case 3: return NamedTextColor.GOLD;
            case 4: return NamedTextColor.YELLOW;
            case 5: return NamedTextColor.GREEN;
            default: return NamedTextColor.GRAY;
        }
    }

    public void removeBossBar(Player player) {
        BossBar bar = bossBars.remove(player.getUniqueId());
        if (bar != null) player.hideBossBar(bar);
        BossBar witBar = withdrawalBars.remove(player.getUniqueId());
        if (witBar != null) player.hideBossBar(witBar);
        withdrawalBarStart.remove(player.getUniqueId());
    }

    // === Konsum / Decay / Entzug ===

    /** Spieler hat eine Zigarette zu Ende geraucht. */
    public void onCigaretteFinished(Player player) {
        consume(player, PlayerData.NICOTINE_PER_CIG, ConsumeKind.CIGARETTE);
    }

    /**
     * Spieler hat eine 30-Sekunden Shisha-Sitzung erfolgreich beendet.
     * Füllt den Nikotin-Balken auf das Maximum (10) und beendet einen aktiven Entzug.
     */
    public void onShishaSession(Player player) {
        consume(player, PlayerData.NICOTINE_PER_SHISHA, ConsumeKind.SHISHA);
    }

    /**
     * Passiver Effekt für Bystander, die im Shisha-Rauch stehen.
     * Gibt etwas Nikotin (leichter Effekt), macht aber bei Erstkontakt süchtig.
     */
    public void onPassiveSmoke(Player player, double amount) {
        PlayerData d = playerDataManager.get(player);
        boolean firstTime = !d.isAddicted();
        if (firstTime) {
            d.setAddicted(true);
            d.setAddictionLevel(5);
            player.sendMessage(Component.text("Du atmest Shisha-Rauch ein und wirst nikotin-süchtig.",
                    NamedTextColor.RED));
        }
        d.setNicotineLevel(Math.min(PlayerData.NICOTINE_MAX, d.getNicotineLevel() + amount));
        d.setLastDecayMillis(System.currentTimeMillis());
        updateBossBar(player);
        applyEffects(player);
    }

    /** Spieler hat einen Vape-Zug genommen. */
    public void onVapePuff(Player player) {
        checkFirstVapeAchievement(player);
        consume(player, PlayerData.NICOTINE_PER_PUFF, ConsumeKind.VAPE);
    }

    /**
     * Wie {@link #onVapePuff(Player)}, aber mit einer frei wählbaren Nikotin-Menge.
     * Wird von der Randm 15k genutzt, deren Stärke-Modi (Leicht/Normal/Stark/Surge)
     * unterschiedliche Mengen geben.
     */
    public void onVapePuffAmount(Player player, double amount) {
        checkFirstVapeAchievement(player);
        consume(player, amount, ConsumeKind.VAPE);
    }

    /** Broadcastet beim allerersten Vape-Zug eines Spielers ein Achievement (egal welche Vape-Sorte). */
    private void checkFirstVapeAchievement(Player player) {
        PlayerData d = playerDataManager.get(player);
        if (d.hasUsedVape()) return;
        d.setVapeUsed(true);
        Component msg = Component.text(player.getName() + " hat zum ersten Mal an einer Vape gezogen!",
                NamedTextColor.LIGHT_PURPLE);
        plugin.getServer().broadcast(msg);
        player.getWorld().playSound(player.getLocation(),
                Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
    }

    /** Art des Konsums. Bestimmt u. a. ob für Sucht-Aufstieg gezählt wird. */
    private enum ConsumeKind { CIGARETTE, SHISHA, VAPE }

    /**
     * Zentrale Konsum-Logik:
     *  - Erstkonsum: macht süchtig (Stufe 5)
     *  - Wenn Konsum die Leiste auf das Maximum (10) hebt:
     *      * Sucht-Aufstiegszähler +1
     *      * ggf. Sucht-Stufe erhöhen
     *  - Wenn Spieler bereits voll ist und weiter konsumiert: Nikotin-SCHOCK
     *  - Beendet aktiven Entzug
     */
    private void consume(Player player, double amount, ConsumeKind kind) {
        PlayerData d = playerDataManager.get(player);
        boolean firstTime = !d.isAddicted();
        double before = d.getNicotineLevel();

        // Schock-Check: Wenn Spieler bereits voll ist und weiter konsumiert
        if (!firstTime && before >= PlayerData.NICOTINE_MAX - 0.001) {
            triggerNicotineShock(player);
            updateBossBar(player);
            applyEffects(player);
            return;
        }

        d.setAddicted(true);
        if (firstTime) {
            d.setAddictionLevel(5);
            player.sendMessage(Component.text("Du bist jetzt nikotin-süchtig.", NamedTextColor.RED));
        }

        // Nikotin auffüllen (gecappt bei MAX)
        double newLevel = Math.min(PlayerData.NICOTINE_MAX, before + amount);
        d.setNicotineLevel(newLevel);

        // Sucht-Aufstiegslogik:
        // Bei JEDER Zigarette/Shisha-Sitzung counter +1 (Vape-Zug zählt nicht).
        // Schwellen: 8/16/24/32 Konsume → Stufe 4/3/2/1.
        boolean countsForAddiction = (kind == ConsumeKind.CIGARETTE || kind == ConsumeKind.SHISHA);
        if (countsForAddiction) {
            d.incrementCigarettesSmoked();
            int natural = PlayerData.levelFromCigaretteCount(d.getTotalCigarettesSmoked());
            if (natural < d.getAddictionLevel()) {
                d.setAddictionLevel(natural);
                player.sendMessage(Component.text("Deine Sucht hat sich verschlimmert! Stufe: " + natural,
                        NamedTextColor.RED));
                player.playSound(player.getLocation(),
                        org.bukkit.Sound.ENTITY_WITHER_AMBIENT, 0.4f, 1.4f);
            }
        }

        // Entzug beenden
        if (d.isInWithdrawal()) {
            d.setInWithdrawal(false);
            d.setWithdrawalStartMillis(0L);
            player.sendMessage(Component.text("Die Entzugserscheinungen lassen nach.",
                    NamedTextColor.GREEN));
        }
        d.setLastDecayMillis(System.currentTimeMillis());

        updateBossBar(player);
        applyEffects(player);
    }

    /**
     * Nikotin-Schock: Wird ausgelöst, wenn der Spieler bei voller Leiste weiter konsumiert.
     * 5 Sekunden Blindheit + Nausea (Bildschirm-Wackeln) + Slowness +
     * leichter Schaden + auffälliger Hinweis.
     */
    private void triggerNicotineShock(Player player) {
        // Blindheit (5 s = 100 Ticks)
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS,
                100, 0, true, true, true));
        // Nausea (Bildschirm-Wackel-Effekt)
        player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,
                100, 0, true, true, true));
        // Zusätzliche Slowness, damit man wirklich merkt dass etwas nicht stimmt
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                100, 1, true, true, true));

        // Leichter Schaden (2 Herzen) – Schock ist nicht harmlos
        double newHealth = Math.max(1.0, player.getHealth() - 4.0);
        player.setHealth(newHealth);

        // Akustisch + visuell
        player.playSound(player.getLocation(),
                org.bukkit.Sound.ENTITY_PLAYER_HURT, 1.0f, 0.7f);
        player.playSound(player.getLocation(),
                org.bukkit.Sound.ENTITY_ELDER_GUARDIAN_CURSE, 0.6f, 1.6f);
        player.getWorld().spawnParticle(org.bukkit.Particle.LARGE_SMOKE,
                player.getEyeLocation(),
                40, 0.4, 0.4, 0.4, 0.05);

        player.sendMessage(Component.text("Nikotin-Schock!", NamedTextColor.DARK_RED));
        player.sendMessage(Component.text("Dein Körper kann nicht mehr aufnehmen.",
                NamedTextColor.RED));
    }

    /**
     * Tickt den natürlichen Abbau für einen Online-Spieler.
     * Wird im NicotineDecayTask jede Sekunde aufgerufen.
     */
    public void tick(Player player) {
        PlayerData d = playerDataManager.get(player);
        if (!d.isAddicted()) return;

        long now = System.currentTimeMillis();
        long elapsedMillis = now - d.getLastDecayMillis();
        if (elapsedMillis <= 0) {
            d.setLastDecayMillis(now);
            return;
        }

        // Decay-Rate: NICOTINE_MAX über decayIntervalSeconds
        int intervalSec = PlayerData.decayIntervalSeconds(d.getAddictionLevel());
        double perMs = PlayerData.NICOTINE_MAX / (intervalSec * 1000.0);
        double newLevel = d.getNicotineLevel() - perMs * elapsedMillis;
        d.setLastDecayMillis(now);

        if (newLevel <= 0.0 && d.getNicotineLevel() > 0.0) {
            // Erstmaliges Erreichen von 0 -> Entzug startet
            d.setNicotineLevel(0.0);
            startWithdrawal(player, d);
        } else {
            d.setNicotineLevel(Math.max(0.0, newLevel));
        }

        // Heilung: 20 Minuten Entzug durchgehalten -> Stufe um 1 erhöhen (in Richtung 5/geheilt)
        if (d.isInWithdrawal() && d.getWithdrawalStartMillis() > 0) {
            long held = now - d.getWithdrawalStartMillis();
            if (held >= WITHDRAWAL_HEAL_MILLIS) {
                heal(player, d);
            }
        }

        updateBossBar(player);
        applyEffects(player);
    }

    private void startWithdrawal(Player player, PlayerData d) {
        d.setInWithdrawal(true);
        d.setWithdrawalStartMillis(System.currentTimeMillis());
        player.sendMessage(Component.text("Du brauchst eine Zigarette!", NamedTextColor.RED));
        player.sendMessage(Component.text("Warte 20 Minuten, um deine Suchtstufe zu senken.",
                NamedTextColor.GRAY));
    }

    private void heal(Player player, PlayerData d) {
        int newLevel = d.getAddictionLevel() + 1;
        d.setWithdrawalStartMillis(System.currentTimeMillis()); // Timer für nächste Heilstufe neu starten

        if (newLevel > 5) {
            // Komplett geheilt
            d.setAddicted(false);
            d.setAddictionLevel(0);
            d.setInWithdrawal(false);
            d.setWithdrawalStartMillis(0L);
            d.setNicotineLevel(0.0);
            d.setTotalCigarettesSmoked(0);
            removeBossBar(player);
            removeAllPluginEffects(player);
            player.sendMessage(Component.text("Du hast mit dem Rauchen aufgehört!",
                    NamedTextColor.GREEN));
        } else {
            d.setAddictionLevel(newLevel);
            player.sendMessage(Component.text("Deine Sucht ist schwächer geworden! Stufe: " + newLevel,
                    NamedTextColor.GREEN));
        }
    }

    /** Wird ständig aufgerufen, solange Spieler im Entzug ist (vom WithdrawalTask). */
    public void applyWithdrawalHungerLoss(Player player) {
        PlayerData d = playerDataManager.get(player);
        if (!d.isInWithdrawal()) return;
        // Pro Sekunde 1 Hungerpunkt verlieren bis minimal 6 (= 3 Hungerbalken)
        int current = player.getFoodLevel();
        if (current > 6) {
            player.setFoodLevel(current - 1);
        }
    }

    // === Effekte ===

    /**
     * Setzt den Speed-Effekt proportional zum Nikotin-Stand:
     *   0     = kein Effekt
     *   <2.5  = Speed I  (amplifier 0)
     *   2.5..5= Speed II (amplifier 1)
     *   5..7.5= Speed III(amplifier 2)
     *   >=10  = Speed IV (amplifier 3)
     * (Beachte: PotionEffect-amplifier 3 = "Speed 4" in der UI.)
     *
     * Wendet außerdem ggf. Sauerstoff-Verlust unter Wasser an.
     */
    public void applyEffects(Player player) {
        PlayerData d = playerDataManager.get(player);

        // Speed: Stufe abhängig vom Nikotin-Stand
        if (d.isAddicted() && d.getNicotineLevel() > 0.0) {
            double n = d.getNicotineLevel();
            int amplifier;
            if (n >= 10.0)      amplifier = 3; // Speed 4 (Maximum) bei voller Leiste
            else if (n >= 7.5)  amplifier = 2; // Speed 3
            else if (n >= 5.0)  amplifier = 1; // Speed 2
            else if (n >= 2.5)  amplifier = 0; // Speed 1
            else                amplifier = 0; // sehr niedriges Nikotin -> trotzdem Speed 1
            // Effekt setzen (60 Ticks Dauer, wir refreshen jede Sekunde im Decay-Task)
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                    60, amplifier, true, false, false));
        } else {
            player.removePotionEffect(PotionEffectType.SPEED);
        }

        // Wasser-Atmung: Logik im WaterAirLossTask separat
    }

    /** Tick-basierte Reduktion der Sauerstoffblasen, falls Bedingungen erfüllt sind. */
    public void applyWaterAirLossIfNeeded(Player player) {
        PlayerData d = playerDataManager.get(player);
        if (!d.isAddicted()) return;
        if (d.getAddictionLevel() == 0 || d.getAddictionLevel() > 2) return;
        if (player.getRemainingAir() <= 0) return;
        if (player.getEyeLocation().getBlock().getType().toString().contains("WATER")
                || player.isInWaterOrBubbleColumn()) {
            // 4x schnellerer Luftverlust: -4 Air pro Tick (Standard ist -1 alle 3 Ticks).
            player.setRemainingAir(Math.max(-20, player.getRemainingAir() - 4));
        }
    }

    public void removeAllPluginEffects(Player player) {
        player.removePotionEffect(PotionEffectType.SPEED);
    }
}
