package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Verwaltet aktive Rauch-Sessions: 45 Sekunden Dauer, BossBar-Fortschritt,
 * Rauchpartikel und Auf-Beendigung-Hooks.
 */
public class SmokingManager {

    public static final int SMOKE_TICKS = 45 * 20; // 45 s

    private final SmokeAddictionPlugin plugin;
    private final NicotineManager nicotineManager;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public SmokingManager(SmokeAddictionPlugin plugin, NicotineManager nm) {
        this.plugin = plugin;
        this.nicotineManager = nm;
    }

    public boolean isSmoking(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    public Session getSession(Player p) {
        return sessions.get(p.getUniqueId());
    }

    /** Startet eine neue Rauch-Session. Erwartet, dass alle Vorbedingungen geprüft sind. */
    public void start(Player player) {
        if (isSmoking(player)) return;

        // Munis-Level aus Cig auslesen → kürzere Session
        ItemStack cigItem = player.getInventory().getItemInMainHand();
        int munis = plugin.getEnchantmentManager().getMunis(cigItem);
        final int sessionTicks = switch (munis) {
            case 1  -> 30 * 20;
            case 2  -> 20 * 20;
            case 3  -> 10 * 20;
            default -> SMOKE_TICKS;
        };

        BossBar bar = BossBar.bossBar(
                Component.text("Rauchen ...", NamedTextColor.GRAY),
                0f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
        player.showBossBar(bar);

        Session s = new Session(player.getUniqueId(), bar);
        s.totalTicks = sessionTicks;
        // Brand aus der Haupthand ermitteln für die Burn-Stage-Animation
        s.brand = plugin.getItemManager().isCigarette(cigItem)
                ? plugin.getItemManager().getBrand(cigItem)
                : de.soos.smokeaddiction.model.CigaretteBrand.MARLBORO;
        sessions.put(player.getUniqueId(), s);

        s.task = new BukkitRunnable() {
            int ticks = 0;
            // Animationszyklus: 100 Ticks (5 s) pro Zug.
            //   0..10  : Hand zum Mund führen (Swing) + Inhale-Sound
            //  10..30  : Inhale-Phase (Glut leuchtet stärker, kein Ausatmen)
            //  30..50  : Hand absetzen (zweiter Swing) + Exhale-Sound
            //  50..100 : Exhale-Phase mit dichten Rauchpartikeln vor dem Mund
            // Zwischen den Zügen: leichter Hintergrundrauch
            final int CYCLE_TICKS = 100;

            @Override
            public void run() {
                Player p = plugin.getServer().getPlayer(s.uuid);
                if (p == null || !p.isOnline()) {
                    cleanup(s, false);
                    cancel();
                    return;
                }

                int cyclePhase = ticks % CYCLE_TICKS;
                Location eye = p.getEyeLocation();
                Location mouth = eye.clone().subtract(0, 0.15, 0);
                // Punkt vor dem Mund (in Blickrichtung)
                Location front = mouth.clone().add(eye.getDirection().multiply(0.45));

                // === Phase 1: Hand zum Mund (Tick 0) ===
                if (cyclePhase == 0) {
                    p.swingMainHand();
                    p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.3f, 0.6f);
                    p.sendActionBar(Component.text("Zieht ein ...", NamedTextColor.GRAY));
                }

                // === Phase 2: Inhale (Tick 10..30) – Glut-Glühen vor dem Mund ===
                if (cyclePhase >= 5 && cyclePhase < 30) {
                    // Heller Funken/Glut-Effekt
                    p.getWorld().spawnParticle(Particle.FLAME,
                            front.getX(), front.getY(), front.getZ(),
                            1, 0.02, 0.02, 0.02, 0.0);
                    if (cyclePhase % 4 == 0) {
                        p.getWorld().spawnParticle(Particle.SMOKE,
                                front.getX(), front.getY(), front.getZ(),
                                1, 0.05, 0.05, 0.05, 0.0);
                    }
                }

                // === Phase 3: Hand absetzen (Tick 30) ===
                if (cyclePhase == 30) {
                    p.swingMainHand();
                    p.playSound(p.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.4f, 1.6f);
                    p.sendActionBar(Component.text("Atmet aus ...", NamedTextColor.GRAY));
                }

                // === Phase 4: Exhale (Tick 30..70) – dichte Rauchwolke nach vorne ===
                if (cyclePhase >= 30 && cyclePhase < 70) {
                    // Wolke wandert in Blickrichtung weg
                    double dist = (cyclePhase - 30) * 0.06;
                    Location cloud = mouth.clone().add(eye.getDirection().multiply(0.4 + dist));
                    p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                            cloud.getX(), cloud.getY(), cloud.getZ(),
                            3, 0.15, 0.15, 0.15, 0.02);
                    if (cyclePhase % 3 == 0) {
                        p.getWorld().spawnParticle(Particle.CLOUD,
                                cloud.getX(), cloud.getY(), cloud.getZ(),
                                2, 0.1, 0.1, 0.1, 0.01);
                    }
                    // Aufsteigender Rauch nach oben (das was vorher die Standard-Animation war)
                    if (cyclePhase % 5 == 0) {
                        p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                                cloud.getX(), cloud.getY() + 0.8 + dist,
                                cloud.getZ(),
                                1, 0.2, 0.3, 0.2, 0.03);
                    }
                }

                // === Phase 5: Pause zwischen Zügen (Tick 70..100) ===
                if (cyclePhase >= 70) {
                    if (cyclePhase % 8 == 0) {
                        // Sehr leichter Hintergrundrauch von der Zigarette
                        Location hand = p.getLocation().add(0, 1.0, 0)
                                .add(eye.getDirection().multiply(0.2));
                        p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                                hand.getX(), hand.getY() + 0.3, hand.getZ(),
                                1, 0.1, 0.2, 0.1, 0.01);
                    }
                }

                // BossBar-Fortschritt
                ticks++;
                float prog = Math.min(1f, ticks / (float) s.totalTicks);
                bar.progress(prog);

                // Burn-Stage-Animation: Item in der Hand wechselt CMD-Wert.
                // Beim letzten Tick (prog >= 1) SOFORT auf den Basis-CMD zurücksetzen,
                // damit finish() immer ein sauberes Item vorfindet.
                {
                    ItemStack held = p.getInventory().getItemInMainHand();
                    if (plugin.getItemManager().isCigarette(held)) {
                        ItemMeta meta = held.getItemMeta();
                        if (meta != null) {
                            int baseCMD = de.soos.smokeaddiction.util.CMDValues.forCigarette(s.brand);
                            int stage;
                            if (ticks >= s.totalTicks) {
                                // Letzter Tick: Basis zurücksetzen, nie den End-Stage anzeigen
                                stage = 0;
                            } else {
                                stage = prog < 0.33f ? 0 : prog < 0.66f ? 1 : prog < 0.88f ? 2 : 3;
                            }
                            if (stage != s.lastBurnStage) {
                                s.lastBurnStage = stage;
                                int offset = stage == 0 ? 0
                                        : stage == 1 ? de.soos.smokeaddiction.util.CMDValues.CIG_BURN_HALF_OFFSET
                                        : stage == 2 ? de.soos.smokeaddiction.util.CMDValues.CIG_BURN_LOW_OFFSET
                                        : de.soos.smokeaddiction.util.CMDValues.CIG_BURN_END_OFFSET;
                                de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, baseCMD + offset);
                                held.setItemMeta(meta);
                            }
                        }
                    }
                }

                // Anti-Cheese: wechselt Spieler die Hand-Slot oder dropt das Item, brechen wir ab.
                if (!plugin.getItemManager().isCigarette(p.getInventory().getItemInMainHand())) {
                    cleanup(s, false);
                    p.sendMessage(Component.text("Rauchvorgang abgebrochen.", NamedTextColor.RED));
                    cancel();
                    return;
                }

                if (ticks >= s.totalTicks) {
                    finish(p, s);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void finish(Player p, Session s) {
        // SOFORT alle Zigaretten im Inventar auf ihren Basis-CMD zurücksetzen,
        // bevor irgendwas anderes passiert – sonst bleibt die End-Textur kleben.
        resetAllBurnCMDs(p);

        // Zigarette aus der Haupthand entfernen + Brand bestimmen
        ItemStack mainHand = p.getInventory().getItemInMainHand();
        de.soos.smokeaddiction.model.CigaretteBrand brand =
                de.soos.smokeaddiction.model.CigaretteBrand.MARLBORO;
        if (plugin.getItemManager().isCigarette(mainHand)) {
            brand = plugin.getItemManager().getBrand(mainHand);
            int amt = mainHand.getAmount();
            if (amt <= 1) {
                p.getInventory().setItemInMainHand(null);
            } else {
                mainHand.setAmount(amt - 1);
            }
        }

        // Joint? Substance-Cig? -> entsprechender Effekt; sonst Nikotin
        switch (brand) {
            case HERB_JOINT:
                plugin.getHerbManager().onConsume(p);
                break;
            case RAUCHZUCKER_CIG:
                plugin.getSubstanceManager().applyRauchzucker(p);
                break;
            case LEAF_CIG:
                plugin.getSubstanceManager().applyLeaf(p);
                break;
            default:
                nicotineManager.onCigaretteFinished(p);
                break;
        }
        cleanup(s, true);
    }

    /** Bricht eine laufende Session ab (z. B. wenn Spieler stirbt oder relogt). */
    public void cancel(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s != null) cleanup(s, false);
    }

    private void cleanup(Session s, boolean finished) {
        Player p = plugin.getServer().getPlayer(s.uuid);
        if (p != null) {
            p.hideBossBar(s.bar);
            // Immer alle Zigaretten-CMDs zurücksetzen (egal ob fertig oder abgebrochen).
            resetAllBurnCMDs(p);
        }
        if (s.task != null && !s.task.isCancelled()) s.task.cancel();
        sessions.remove(s.uuid);
    }

    /**
     * Scannt das gesamte Inventar und setzt jede Zigarette auf ihren sauberen
     * Basis-CMD zurück – egal ob sie gerade eine Burn-Stage-Textur trägt oder nicht.
     * Damit wird garantiert, dass nach jeder Session keine verbrannte Textur
     * im Inventar hängen bleibt.
     */
    private void resetAllBurnCMDs(Player p) {
        de.soos.smokeaddiction.manager.ItemManager im = plugin.getItemManager();
        for (ItemStack it : p.getInventory().getContents()) {
            if (it == null || !im.isCigarette(it)) continue;
            de.soos.smokeaddiction.model.CigaretteBrand b = im.getBrand(it);
            int baseCMD = de.soos.smokeaddiction.util.CMDValues.forCigarette(b);
            ItemMeta meta = it.getItemMeta();
            if (meta == null) continue;
            de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, baseCMD);
            it.setItemMeta(meta);
        }
    }

    /** Datenobjekt einer Session. */
    public static class Session {
        public final UUID uuid;
        public final BossBar bar;
        public BukkitTask task;
        public int totalTicks = SMOKE_TICKS;
        public de.soos.smokeaddiction.model.CigaretteBrand brand =
                de.soos.smokeaddiction.model.CigaretteBrand.MARLBORO;
        public int lastBurnStage = 0; // 0=fresh,1=half,2=low,3=end
        public Session(UUID uuid, BossBar bar) {
            this.uuid = uuid;
            this.bar = bar;
        }
    }
}
