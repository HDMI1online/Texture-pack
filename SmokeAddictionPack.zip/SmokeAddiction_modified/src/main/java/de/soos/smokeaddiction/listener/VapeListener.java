package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.model.VapeFlavor;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Verarbeitet Vape-Nutzung: Rechtsklick mit einer Elfbar in der Haupthand zieht
 * einen Zug (-1), erhöht das Nikotin um 0.5 und spielt einen kleinen Effekt.
 */
public class VapeListener implements Listener {

    /** Cooldown in Millisekunden zwischen zwei Zügen. */
    private static final long PUFF_COOLDOWN_MS = 1500L;

    private final SmokeAddictionPlugin plugin;
    private final java.util.Map<java.util.UUID, Long> lastPuff = new java.util.HashMap<>();

    public VapeListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemManager im = plugin.getItemManager();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!im.isVape(hand)) return;

        // Randm 15k: komplett eigene Mechanik (Stärke-Modi, Surge), wird von
        // RandmVapeListener behandelt, hier nichts tun.
        if (im.isRandm(hand)) return;

        // Zaubertisch-Klick? EnchantTableListener übernimmt, hier nichts tun.
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK
                && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == org.bukkit.Material.ENCHANTING_TABLE) {
            return;
        }

        e.setCancelled(true);

        // Cooldown prüfen
        long now = System.currentTimeMillis();
        long last = lastPuff.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < PUFF_COOLDOWN_MS) {
            return;
        }
        lastPuff.put(p.getUniqueId(), now);

        int puffs = im.getVapePuffs(hand);
        if (puffs <= 0) {
            p.sendMessage(Component.text("Diese Vape ist leer.", NamedTextColor.GRAY));
            if (im.isFumot(hand)) im.updateFumotDisplay(hand, ItemManager.FumotState.EMPTY_PUFFS);
            if (im.isVozol(hand)) im.updateVozolDisplay(hand, ItemManager.VozolState.EMPTY_PUFFS);
            return;
        }

        // Fumot 12k: Akku prüfen und entladen
        if (im.isFumot(hand)) {
            int battery = im.getFumotBattery(hand);
            if (battery <= 0) {
                p.sendMessage(Component.text("Akku leer! Drop sie an einer Redstone-Quelle zum Laden.",
                        NamedTextColor.RED));
                im.updateFumotDisplay(hand, ItemManager.FumotState.EMPTY_BATTERY);
                p.playSound(p.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.6f, 0.8f);
                return;
            }
            // -1% Akku, -1 Zug
            im.setFumotBatteryRaw(hand, battery - 1);
            im.setFumotPuffsRaw(hand, puffs - 1);
            im.updateFumotDisplay(hand, ItemManager.FumotState.IN_USE);

            // Auffälliger Zähler
            p.sendActionBar(Component.text("Fumot 12k │ ", NamedTextColor.LIGHT_PURPLE)
                    .append(Component.text("Akku " + (battery - 1) + "%", batteryActionColor(battery - 1)))
                    .append(Component.text(" │ ", NamedTextColor.DARK_GRAY))
                    .append(Component.text("Züge " + (puffs - 1) + "/" + ItemManager.FUMOT_MAX_PUFFS,
                            NamedTextColor.AQUA)));
        } else if (im.isVozol(hand)) {
            double chargeLeft = im.getVozolChargeLeft(hand);
            if (chargeLeft <= 0) {
                p.sendMessage(Component.text("Akku leer! Drop sie an einer Redstone-Quelle zum Laden.",
                        NamedTextColor.RED));
                im.updateVozolDisplay(hand, ItemManager.VozolState.EMPTY_BATTERY);
                p.playSound(p.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.6f, 0.8f);
                return;
            }
            // -1 Zug im Akku-Zyklus, -1 Zug gesamt
            im.setVozolChargeLeftRaw(hand, chargeLeft - 1);
            im.setVozolPuffsRaw(hand, puffs - 1);
            im.updateVozolDisplay(hand, ItemManager.VozolState.IN_USE);

            int batteryPct = (int) Math.round(((chargeLeft - 1) / (double) ItemManager.VOZOL_PUFFS_PER_CHARGE) * 100);
            p.sendActionBar(Component.text("Vozol 40k │ ", NamedTextColor.GOLD)
                    .append(Component.text("Akku " + batteryPct + "%", batteryActionColor(batteryPct)))
                    .append(Component.text(" │ ", NamedTextColor.DARK_GRAY))
                    .append(Component.text("Züge " + (puffs - 1) + "/" + ItemManager.VOZOL_MAX_PUFFS,
                            NamedTextColor.AQUA)));
        } else {
            // Klassische Elfbar
            VapeFlavor flavor = im.getVapeFlavor(hand);
            im.setVapePuffs(hand, puffs - 1);
            p.sendActionBar(Component.text("Zug genommen (" + flavor.getDisplayName() + ") – "
                    + (puffs - 1) + " Züge übrig.", NamedTextColor.AQUA));
        }

        // Zug-Effekte: Hand-Animation + dichte Rauchwolke nach vorne
        p.swingMainHand();
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.6f, 1.6f);

        // Mehr-Rauch-Enchant: Stufe bestimmt Partikel-Menge, Weite und Höhe
        int moreSmoke = plugin.getEnchantmentManager().getMoreSmoke(hand);
        // Skalierung: Stufe 0=normal, 1=doppelt, 2=dreifach, 3=fünffach
        final int particleMult  = moreSmoke == 0 ? 1  : moreSmoke == 1 ? 2  : moreSmoke == 2 ? 3  : 5;
        final double spreadMult = moreSmoke == 0 ? 1.0: moreSmoke == 1 ? 1.8: moreSmoke == 2 ? 2.8: 4.0;
        final double risePerStep = moreSmoke == 0 ? 0.04 : moreSmoke == 1 ? 0.07 : moreSmoke == 2 ? 0.11 : 0.16;
        final double fwdPerStep  = moreSmoke == 0 ? 0.12 : moreSmoke == 1 ? 0.16 : moreSmoke == 2 ? 0.20 : 0.25;
        final int waves          = moreSmoke == 0 ? 20  : moreSmoke == 1 ? 30  : moreSmoke == 2 ? 40  : 55;

        // Sofort beim Zug: Wolke vor dem Mund
        p.getWorld().spawnParticle(Particle.SMOKE,
                p.getEyeLocation().add(p.getLocation().getDirection().multiply(0.3)),
                10 * particleMult, 0.1 * spreadMult, 0.1 * spreadMult, 0.1 * spreadMult, 0.01);

        // Rauchwolke wandert nach vorne und steigt auf – bei hohem Enchant weiter & höher.
        final org.bukkit.util.Vector dir = p.getLocation().getDirection();
        final org.bukkit.Location startLoc = p.getEyeLocation().clone();
        final org.bukkit.entity.Player fp = p;
        final double rs = risePerStep, fs = fwdPerStep;
        for (int i = 0; i < waves; i++) {
            final int step = i;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!fp.isOnline()) return;
                // Aufspaltung bei höherem Enchant: Wolken driften seitlich auseinander
                double sideOffset = moreSmoke >= 2 ? (step % 2 == 0 ? 1 : -1) * step * 0.015 : 0;
                org.bukkit.util.Vector side = dir.clone().crossProduct(new org.bukkit.util.Vector(0,1,0))
                        .normalize().multiply(sideOffset);
                org.bukkit.Location cloud = startLoc.clone()
                        .add(dir.clone().multiply(0.4 + step * fs))
                        .add(0, step * rs, 0)
                        .add(side);
                fp.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                        cloud.getX(), cloud.getY(), cloud.getZ(),
                        8 * particleMult,
                        0.2 * spreadMult, 0.2 * spreadMult, 0.2 * spreadMult, 0.02);
                fp.getWorld().spawnParticle(Particle.CLOUD,
                        cloud.getX(), cloud.getY(), cloud.getZ(),
                        4 * particleMult,
                        0.15 * spreadMult, 0.15 * spreadMult, 0.15 * spreadMult, 0.01);
                // Bei Stufe 3: extra LARGE_SMOKE für dickere Wolke
                if (moreSmoke >= 3 && step % 3 == 0) {
                    fp.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                            cloud.getX(), cloud.getY(), cloud.getZ(),
                            3, 0.3 * spreadMult, 0.2 * spreadMult, 0.3 * spreadMult, 0.01);
                }
            }, i * 1L);
        }

        plugin.getNicotineManager().onVapePuff(p);
    }

    private static net.kyori.adventure.text.format.NamedTextColor batteryActionColor(int v) {
        if (v >= 60) return NamedTextColor.GREEN;
        if (v >= 25) return NamedTextColor.YELLOW;
        if (v > 0)   return NamedTextColor.RED;
        return NamedTextColor.DARK_RED;
    }
}
