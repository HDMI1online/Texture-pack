package de.soos.smokeaddiction.model;

/**
 * Zug-Stärke der Randm 15k. Wird per Linksklick durchgeschaltet.
 *
 *  - LEICHT: +0.5 Nikotin, -1 Liquid pro Zug
 *  - NORMAL: +1   Nikotin, -1.5 Liquid pro Zug
 *  - STARK:  +2   Nikotin, -2 Liquid pro Zug
 *  - SURGE:  Ziehen gedrückt halten – pro Sekunde Halten +3 Nikotin, -2 Liquid
 *            (kontinuierlich, kein fester Zug-Wert; endet bei Loslassen oder
 *            nach maximal 4 Sekunden Dauerzug)
 */
public enum RandmStrength {
    LEICHT(0.5, 1.0),
    NORMAL(1.0, 1.5),
    STARK(2.0, 2.0),
    SURGE(0.0, 0.0); // Surge nutzt eigene Pro-Sekunde-Werte, siehe SURGE_NICOTINE_PER_SECOND etc.

    /** Pro-Sekunde-Werte für den Surge-Modus (Dauerzug). */
    public static final double SURGE_NICOTINE_PER_SECOND = 3.0;
    public static final double SURGE_LIQUID_PER_SECOND   = 2.0;
    /** Maximale Haltedauer eines Surge-Zugs in Ticks (4 Sekunden). */
    public static final int SURGE_MAX_HOLD_TICKS = 80;

    private final double nicotinePerPuff;
    private final double liquidPerPuff;

    RandmStrength(double nicotinePerPuff, double liquidPerPuff) {
        this.nicotinePerPuff = nicotinePerPuff;
        this.liquidPerPuff = liquidPerPuff;
    }

    public double getNicotinePerPuff() { return nicotinePerPuff; }
    public double getLiquidPerPuff()   { return liquidPerPuff; }

    /** Schaltet zur nächsten Stärke (Linksklick-Zyklus). */
    public RandmStrength next() {
        RandmStrength[] order = { LEICHT, NORMAL, STARK, SURGE };
        int idx = 0;
        for (int i = 0; i < order.length; i++) if (order[i] == this) { idx = i; break; }
        return order[(idx + 1) % order.length];
    }

    public String getDisplayName() {
        switch (this) {
            case LEICHT: return "Leicht";
            case NORMAL: return "Normal";
            case STARK:  return "Stark";
            case SURGE:  return "Surge";
            default:     return "Normal";
        }
    }

    public static RandmStrength fromName(String name) {
        if (name == null) return NORMAL;
        for (RandmStrength s : values()) {
            if (s.name().equalsIgnoreCase(name)) return s;
        }
        return NORMAL;
    }
}
