package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Promille-Abbau: läuft jede Sekunde und delegiert pro Spieler
 * an {@link de.soos.smokeaddiction.manager.AlcoholManager#tick(Player)}.
 *
 * Auch wenn die Spec "alle 60 Sekunden -0.1‰" sagt, lassen wir den Task
 * jede Sekunde laufen, damit die Bossbar weich aktualisiert wird –
 * der Manager rechnet die genaue Rate aus den Millisekunden.
 */
public class AlcoholDecayTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public AlcoholDecayTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getAlcoholManager().tick(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Alkohol-Tick-Fehler für " + p.getName()
                        + ": " + ex.getMessage());
            }
        }
    }
}
