package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Chunk;
import org.bukkit.command.CommandSender;

/**
 * Verwaltet den Debug-Modus des Plugins.
 * Aktivierung via /sa debug true|false.
 * Sendet Debug-Nachrichten an alle registrierten Empfänger (Sender, der debug aktiviert hat)
 * und an die Konsole.
 */
public class DebugManager {

    private final SmokeAddictionPlugin plugin;
    private boolean enabled = false;
    /** Der Sender, der Debug zuletzt aktiviert hat – bekommt alle Meldungen direkt. */
    private CommandSender activeSender = null;

    public DebugManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled, CommandSender sender) {
        this.enabled = enabled;
        this.activeSender = enabled ? sender : null;
    }

    /**
     * Schickt eine Debug-Nachricht an Konsole und (falls noch online) den aktivierenden Sender.
     */
    public void log(String message) {
        if (!enabled) return;

        plugin.getLogger().info("[DEBUG] " + message);

        if (activeSender != null) {
            Component msg = Component.text()
                    .append(Component.text("[", NamedTextColor.DARK_GRAY))
                    .append(Component.text("SA-DEBUG", NamedTextColor.AQUA))
                    .append(Component.text("] ", NamedTextColor.DARK_GRAY))
                    .append(Component.text(message, NamedTextColor.YELLOW))
                    .build();
            activeSender.sendMessage(msg);
        }
    }

    /**
     * Bequemlichkeits-Methode: loggt Spawn-Events mit Chunk-Koordinaten.
     */
    public void logSpawn(String type, Chunk chunk, int count) {
        log(String.format("SPAWN %-10s | Chunk [%d, %d] in '%s' | %d Büsche",
                type, chunk.getX(), chunk.getZ(), chunk.getWorld().getName(), count));
    }

    /**
     * Bequemlichkeits-Methode: loggt Spawn-Versuche die scheitern.
     */
    public void logSkip(String reason, Chunk chunk) {
        log(String.format("SKIP  %-10s | Chunk [%d, %d] in '%s'",
                reason, chunk.getX(), chunk.getZ(), chunk.getWorld().getName()));
    }
}
