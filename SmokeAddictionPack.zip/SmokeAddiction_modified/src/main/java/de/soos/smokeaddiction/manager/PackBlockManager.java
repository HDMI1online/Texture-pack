package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.CigaretteBrand;
import de.soos.smokeaddiction.util.Keys;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.EulerAngle;

/**
 * Verwaltet Schachtel-Blöcke als unsichtbare ArmorStands mit Schachtel-Item auf dem Kopf.
 * So lässt sich pro "Block" der Inhalt (Anzahl Zigaretten + Marke) persistent speichern.
 */
public class PackBlockManager {

    private final SmokeAddictionPlugin plugin;
    private final ItemManager itemManager;

    public PackBlockManager(SmokeAddictionPlugin plugin, ItemManager im) {
        this.plugin = plugin;
        this.itemManager = im;
    }

    /** Platziert eine Schachtel an einem Block-Location. blockLoc ist die Position
     *  des LEEREN Blocks oberhalb des Klick-Targets, hier soll die Packung "auf dem Boden stehen". */
    public ArmorStand place(Location blockLoc, ItemStack packItem) {
        // Wieviele Schachteln stehen schon an dieser Position? -> stapeln
        int existing = 0;
        Location bottom = blockLoc.clone().add(0.5, 0.5, 0.5);
        for (Entity ent : blockLoc.getWorld().getNearbyEntities(bottom, 0.4, 1.5, 0.4)) {
            if (ent instanceof ArmorStand as && isPackEntity(as)) existing++;
        }
        // Pro existierendem Stack 0.25 Block höher
        double yOffset = existing * 0.25;

        // Spawn-Position: Mitten im LEEREN Block über dem Klick-Target.
        // Mini-ArmorStand ist ~0.99 Block hoch, also passt er komplett rein.
        // Helm-Slot des Mini-ArmorStands ist bei Base+0.5, also bei target.y+0.5
        // (mittig im leeren Block, schwebt visuell schön über dem Boden).
        Location stand = blockLoc.clone().add(0.5, 0.0 + yOffset, 0.5);
        ArmorStand as = (ArmorStand) blockLoc.getWorld().spawnEntity(stand, EntityType.ARMOR_STAND);
        as.setVisible(false);
        as.setGravity(false);
        as.setSmall(true);
        as.setMarker(false);
        as.setBasePlate(false);
        as.setArms(false);
        as.setInvulnerable(false);
        as.setCanPickupItems(false);
        as.setSilent(true);
        as.setPersistent(true);
        as.setRemoveWhenFarAway(false);
        as.setCollidable(false);
        as.setHeadPose(new EulerAngle(0, 0, 0));
        as.setCustomNameVisible(false);
        // Disabled-Slots: verhindert dass jemand den Helm aus Versehen im Inventar bewegt
        try {
            as.addEquipmentLock(EquipmentSlot.HEAD,
                    org.bukkit.entity.ArmorStand.LockType.REMOVING_OR_CHANGING);
        } catch (Throwable ignored) {}

        // Schachtel-Item auf den Kopf setzen
        ItemStack copy = packItem.clone();
        copy.setAmount(1);
        as.getEquipment().setItem(EquipmentSlot.HEAD, copy);

        PersistentDataContainer pdc = as.getPersistentDataContainer();
        pdc.set(Keys.ENTITY_PACK, PersistentDataType.BYTE, (byte) 1);

        return as;
    }

    public boolean isPackEntity(Entity e) {
        if (!(e instanceof ArmorStand)) return false;
        Byte v = e.getPersistentDataContainer().get(Keys.ENTITY_PACK, PersistentDataType.BYTE);
        return v != null && v == 1;
    }

    /** Liefert das gespeicherte Schachtel-Item (mit aktueller Stückzahl) vom ArmorStand. */
    public ItemStack getPackItem(ArmorStand as) {
        return as.getEquipment().getItem(EquipmentSlot.HEAD);
    }

    public void setPackItem(ArmorStand as, ItemStack item) {
        as.getEquipment().setItem(EquipmentSlot.HEAD, item);
    }

    public CigaretteBrand getBrand(ArmorStand as) {
        return itemManager.getBrand(getPackItem(as));
    }

    public int getContents(ArmorStand as) {
        return itemManager.getPackContents(getPackItem(as));
    }

    public void setContents(ArmorStand as, int cigarettes) {
        ItemStack pack = getPackItem(as);
        itemManager.setPackContents(pack, cigarettes);
        setPackItem(as, pack);
    }

    /**
     * Legt eine Zigarette (inkl. Enchants) persistent im PackItem-PDC ab.
     * Überlebt Drop/Pickup/Serverrestart.
     */
    public void pushCigarette(ArmorStand as, ItemStack cig) {
        ItemStack packItem = getPackItem(as);
        if (packItem == null) return;
        itemManager.pushPackCigarette(packItem, cig);
        setPackItem(as, packItem);
    }

    /**
     * Entnimmt die zuletzt eingelegte Zigarette aus dem PDC des PackItems.
     * Falls keine gespeichert, wird eine neue erstellt.
     */
    public ItemStack popCigarette(ArmorStand as, CigaretteBrand fallbackBrand) {
        ItemStack packItem = getPackItem(as);
        if (packItem == null) return itemManager.createCigarette(fallbackBrand, 1);
        ItemStack cig = itemManager.popPackCigarette(packItem);
        setPackItem(as, packItem);
        return cig != null ? cig : itemManager.createCigarette(fallbackBrand, 1);
    }

    public void remove(ArmorStand as) {
        as.remove();
    }
}
