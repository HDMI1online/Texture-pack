package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.TraderManager;
import io.papermc.paper.event.player.PlayerTradeEvent;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/**
 * Verfolgt erfolgreiche Trades am Vape-Händler in der City, um nach
 * {@link TraderManager#VAPE_TRADER_FUMOT_THRESHOLD} Trades die Fumot 12k
 * freizuschalten.
 *
 * Nutzt das Paper-eigene {@link PlayerTradeEvent}.
 */
public class TradeListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public TradeListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onTrade(PlayerTradeEvent e) {
        if (!(e.getVillager() instanceof Villager v)) return;
        TraderManager tm = plugin.getTraderManager();
        if (!tm.isTrader(v)) return;

        // Nur Vape-Trader interessieren uns hier
        String type = tm.getTraderType(v);
        if (!TraderManager.TYPE_VAPE_TRADER.equals(type)) return;

        tm.incrementVapeTraderUses(v);
    }
}
