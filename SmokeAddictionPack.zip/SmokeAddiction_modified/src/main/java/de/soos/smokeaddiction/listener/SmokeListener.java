package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.manager.SmokingManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Steuert das Anzünden einer Zigarette (Rechtsklick mit Zigarette in Haupthand + Feuerzeug in Offhand)
 * und schützt die Zigarette während des Rauchvorgangs (kein Drop, kein Slot-Wechsel, kein anderes Item).
 */
public class SmokeListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public SmokeListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        // Nur Rechtsklick mit Haupthand auswerten
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack main = p.getInventory().getItemInMainHand();
        ItemManager im = plugin.getItemManager();

        if (!im.isCigarette(main)) return;

        // Bereits am Rauchen? Verhindere Mehrfach-Sessions
        if (plugin.getSmokingManager().isSmoking(p)) {
            e.setCancelled(true);
            return;
        }

        // Zaubertisch-Klick? Dann nicht rauchen – EnchantTableListener übernimmt.
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK
                && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.ENCHANTING_TABLE) {
            return;
        }

        // Feuerzeug in Offhand?
        ItemStack off = p.getInventory().getItemInOffHand();
        if (!im.isLighter(off) && off.getType() != Material.FLINT_AND_STEEL) {
            p.sendMessage(Component.text("Du brauchst ein Feuerzeug in der Offhand!",
                    NamedTextColor.RED));
            e.setCancelled(true);
            return;
        }

        // Feuerzeug-Haltbarkeit reduzieren (außer im Kreativmodus)
        if (p.getGameMode() != GameMode.CREATIVE) {
            im.damageLighter(off);
            if (off.getAmount() <= 0) {
                p.getInventory().setItemInOffHand(null);
            }
        }

        // Vanilla-Aktion (Block anzünden / Item benutzen) verhindern
        e.setCancelled(true);
        e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);

        // Rauch-Session starten
        plugin.getSmokingManager().start(p);
    }

    /** Verhindert das Droppen der Zigarette während einer Session. */
    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (!plugin.getSmokingManager().isSmoking(p)) return;

        if (plugin.getItemManager().isCigarette(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            p.sendMessage(Component.text("Du kannst die Zigarette gerade nicht weglegen.",
                    NamedTextColor.RED));
        }
    }

    /** Verhindert Slot-Wechsel (Hotbar) während einer Rauch-Session. */
    @EventHandler(ignoreCancelled = true)
    public void onHeld(PlayerItemHeldEvent e) {
        if (plugin.getSmokingManager().isSmoking(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(Component.text("Du rauchst gerade.", NamedTextColor.GRAY));
        }
    }

    /** Verhindert Hand-Swap (F-Taste) während einer Rauch-Session. */
    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (plugin.getSmokingManager().isSmoking(e.getPlayer())) {
            e.setCancelled(true);
        }
    }
}
