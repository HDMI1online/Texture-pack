package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

/**
 * Lädt/speichert PlayerData bei Login/Logout, zeigt Bossbar wieder an
 * und stellt sicher, dass beim Logout kein Nikotinverlust mehr passiert.
 */
public class PlayerListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public PlayerListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        PlayerData d = plugin.getPlayerDataManager().get(p);

        // Wichtig: Decay-Timer auf "jetzt" setzen, damit Offline-Zeit nicht mitgerechnet wird
        long now = System.currentTimeMillis();
        d.setLastDecayMillis(now);
        d.setLastAlcDecayMillis(now);
        // Wenn Spieler im Entzug war, Entzug-Timer ebenfalls "neu starten"
        if (d.isInWithdrawal()) {
            d.setWithdrawalStartMillis(now);
        }

        plugin.getNicotineManager().updateBossBar(p);
        plugin.getNicotineManager().applyEffects(p);
        plugin.getAlcoholManager().updateBossBar(p);
        plugin.getAlcoholManager().applyEffects(p);
        // Heilkraut-Buff/Entzug sofort anzeigen statt bis zu 1s auf den HerbTickTask zu warten
        plugin.getHerbManager().tick(p);
        // Substanz-Effekte/Entzüge (Kokain/LSD/Crack/Spritze/Magic Mushroom) sofort
        // wiederherstellen statt bis zu 1s auf den SubstanceTickTask zu warten.
        // getState() legt den State an und liest dabei automatisch die gespeicherten
        // Deadlines aus PlayerData (siehe SubstanceManager.restoreFromPlayerData).
        plugin.getSubstanceManager().getState(p);
        plugin.getSubstanceManager().tick(p);
        // Monster White: BossBar/Speed/Schild/Überdosis-Vergiftung sofort wiederherstellen
        plugin.getMonsterManager().tick(p);

        // Rezepte im Rezeptbuch freischalten
        plugin.getRecipeManager().discoverAll(p);

        // Tutorial automatisch für neue Spieler (5s Verzögerung, damit das Pack
        // erst geladen wird und der Spieler sich orientiert hat)
        if (!d.hasTutorialSeen()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) plugin.getTutorialManager().start(p);
            }, 100L); // 5 Sekunden
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();

        // Eventuelle laufende Rauch-Session abbrechen
        plugin.getSmokingManager().cancel(p);
        plugin.getShishaManager().cancelSession(p);

        // BossBar entfernen
        plugin.getNicotineManager().removeBossBar(p);
        plugin.getAlcoholManager().removeBossBar(p);
        plugin.getHerbManager().removeBossBars(p);
        plugin.getMonsterManager().removeBossBar(p);

        // Substance-State persistieren (Effekte + Entzüge überleben einen Rejoin),
        // dann State entladen (Fly etc. zurücksetzen)
        var subState = plugin.getSubstanceManager().getState(p);
        plugin.getSubstanceManager().persistToPlayerData(p);
        if (subState.active != null) {
            // Sicherheitshalber Fly entziehen, falls Spritze aktiv war
            if (p.getGameMode() != org.bukkit.GameMode.CREATIVE
                    && p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
            // Adventure → Survival zurück
            if (p.getGameMode() == org.bukkit.GameMode.ADVENTURE
                    && subState.previousGameMode != null) {
                p.setGameMode(subState.previousGameMode);
            }
        }
        plugin.getSubstanceManager().unload(p.getUniqueId());

        // Daten speichern und entladen (kein Decay mehr für offline Spieler)
        plugin.getPlayerDataManager().unload(p.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        // WICHTIG: Sucht-Daten bleiben beim Tod erhalten – wir resetten NICHTS.
        // Nur laufende Sessions abbrechen, damit BossBars sauber verschwinden.
        plugin.getSmokingManager().cancel(p);
        plugin.getShishaManager().cancelSession(p);
    }

    /**
     * Beim Respawn werden Vanilla-PotionEffects entfernt und die BossBar
     * geht je nach Client-Version verloren. Wir stellen alles wieder her.
     * Sucht-Stufe, Nikotin-Wert und Entzug-Status bleiben unverändert.
     */
    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        // Nächsten Tick warten, bis der Spieler wirklich respawnt ist
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            plugin.getNicotineManager().updateBossBar(p);
            plugin.getNicotineManager().applyEffects(p);
            plugin.getAlcoholManager().updateBossBar(p);
            plugin.getAlcoholManager().applyEffects(p);
            plugin.getMonsterManager().tick(p);
        });
    }
}
