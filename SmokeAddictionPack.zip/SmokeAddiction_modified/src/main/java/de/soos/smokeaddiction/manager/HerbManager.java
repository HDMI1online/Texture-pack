package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Verwaltet den Heilkraut-Konsum-Effekt:
 *  - Beim Konsum: Regeneration II für zufällig 5–10 Minuten
 *  - Nach Ablauf: 4 Minuten lang KEINE Heilung möglich (HerbWithdrawalListener blockt
 *    EntityRegainHealthEvent)
 *
 * Erneuter Konsum REFRESHT den Buff komplett auf eine frische Zufallsdauer (5-10 Min)
 * ab dem Konsum-Zeitpunkt, unabhängig von der Restlaufzeit des alten Buffs. Der
 * nachfolgende Withdrawal verschiebt sich entsprechend auf das neue Buff-Ende.
 *
 * Anzeige: eine BossBar während des Buffs (GRÜN) und eine während des Withdrawals (GOLD),
 * analog zu Nikotin/Alkohol/Custom-Substanzen.
 */
public class HerbManager {

    public static final long WITHDRAWAL_DURATION_MS = 4L * 60L * 1000L; // 4 Min

    private final SmokeAddictionPlugin plugin;
    private final PlayerDataManager playerDataManager;

    // BossBar: aktiver Cannabis-Buff (GRÜN)
    private final Map<UUID, BossBar> buffBars = new HashMap<>();
    // BossBar: Cannabis-Entzug (GOLD)
    private final Map<UUID, BossBar> withdrawalBars = new HashMap<>();
    // Zeitstempel des Buff-Starts, für korrekten Fortschrittsbalken
    private final Map<UUID, Long> buffStartedAt = new HashMap<>();
    // Zeitstempel des Withdrawal-Starts, für korrekten Fortschrittsbalken
    private final Map<UUID, Long> withdrawalStartedAt = new HashMap<>();

    public HerbManager(SmokeAddictionPlugin plugin, PlayerDataManager pdm) {
        this.plugin = plugin;
        this.playerDataManager = pdm;
    }

    /** Spieler hat eine Joint geraucht oder eine Herb-Shisha konsumiert. */
    public void onConsume(Player player) {
        PlayerData d = playerDataManager.get(player);
        long now = System.currentTimeMillis();

        // Buff-Dauer zufällig 5..10 Minuten (in ticks: 6000..12000)
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int seconds = rnd.nextInt(5 * 60, 10 * 60 + 1);

        // Entzug stoppen falls gerade aktiv (neuer Konsum setzt ihn zurück)
        if (isInWithdrawal(player)) {
            d.setHerbWithdrawalUntilMillis(0L);
            withdrawalStartedAt.remove(player.getUniqueId());
            net.kyori.adventure.bossbar.BossBar wb = withdrawalBars.remove(player.getUniqueId());
            if (wb != null) player.hideBossBar(wb);
            player.sendMessage(Component.text("Die Entzugserscheinungen lassen nach.",
                    NamedTextColor.GREEN));
        }

        // Echtes Refresh: jeder neue Konsum setzt den Buff auf eine frische
        // Zufallsdauer (5-10 Min) ab JETZT, unabhängig davon wie viel vom alten
        // Buff noch übrig war. Gleiches Prinzip wie bei allen anderen Substanzen
        // im Plugin (Kokain/LSD/Crack/Spritze/Magic Mushroom/Monster White).
        long finalDurationMs = (long) seconds * 1000L;
        int ticks = (int) (finalDurationMs / 50L); // 1 Tick = 50ms

        long newBuffEnd = now + finalDurationMs;
        d.setHerbBuffUntilMillis(newBuffEnd);
        buffStartedAt.put(player.getUniqueId(), now);

        // Withdrawal beginnt erst nach Ablauf des (neuen) Buffs
        long withdrawalEnd = newBuffEnd + WITHDRAWAL_DURATION_MS;
        d.setHerbWithdrawalUntilMillis(withdrawalEnd);

        // Regeneration II – Dauer = tatsächliche (ggf. verlängerte) Restlaufzeit,
        // damit Anzeige und echter Effekt immer synchron sind.
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
                ticks, 1, true, true, true));

        player.sendMessage(Component.text("Du fühlst dich entspannt und heilst schneller.",
                NamedTextColor.GREEN));
        long totalSeconds = finalDurationMs / 1000L;
        player.sendMessage(Component.text("Buff hält " + (totalSeconds / 60) + " Min "
                + (totalSeconds % 60) + " s an.", NamedTextColor.GRAY));

        updateBossBar(player);
    }

    /**
     * Wird vom HerbDecayTask jede Sekunde aufgerufen.
     * Prüft ob der Buff gerade abgelaufen ist und benachrichtigt den Spieler.
     */
    public void tick(Player player) {
        PlayerData d = playerDataManager.get(player);
        long now = System.currentTimeMillis();

        // Übergang Buff → Withdrawal melden
        if (d.getHerbBuffUntilMillis() > 0 && now >= d.getHerbBuffUntilMillis()) {
            // Genau in dieser Sekunde abgelaufen
            if (now < d.getHerbBuffUntilMillis() + 1500) {
                player.sendMessage(Component.text("Der Cannabis-Buff verklingt ...",
                        NamedTextColor.GOLD));
                player.sendMessage(Component.text("Du kannst 4 Minuten nicht heilen.",
                        NamedTextColor.RED));
                withdrawalStartedAt.put(player.getUniqueId(), now);
            }
            d.setHerbBuffUntilMillis(0L);
            buffStartedAt.remove(player.getUniqueId());
        }

        // Übergang Withdrawal → vorbei melden
        if (d.getHerbWithdrawalUntilMillis() > 0 && now >= d.getHerbWithdrawalUntilMillis()) {
            if (now < d.getHerbWithdrawalUntilMillis() + 1500) {
                player.sendMessage(Component.text("Der Entzug ist vorbei. Du kannst wieder heilen.",
                        NamedTextColor.GREEN));
            }
            d.setHerbWithdrawalUntilMillis(0L);
            withdrawalStartedAt.remove(player.getUniqueId());
        }

        updateBossBar(player);
    }

    /** Aktualisiert/erstellt/entfernt die Buff- und Withdrawal-BossBar. */
    private void updateBossBar(Player player) {
        PlayerData d = playerDataManager.get(player);
        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();

        boolean inBuff = d.getHerbBuffUntilMillis() > now;
        boolean inWithdrawal = !inBuff && d.getHerbWithdrawalUntilMillis() > now;

        if (inBuff) {
            long rem = d.getHerbBuffUntilMillis() - now;
            long started = buffStartedAt.getOrDefault(id, now);
            long tot = Math.max(1L, d.getHerbBuffUntilMillis() - started);
            float prog = Math.max(0f, Math.min(1f, (float) rem / tot));
            Component title = Component.text("Cannabis-Wirkung: ", NamedTextColor.GREEN)
                    .append(Component.text(formatTime(rem), NamedTextColor.WHITE));
            BossBar bar = buffBars.computeIfAbsent(id, k -> {
                BossBar b = BossBar.bossBar(title, prog, BossBar.Color.GREEN,
                        BossBar.Overlay.NOTCHED_10);
                player.showBossBar(b);
                return b;
            });
            bar.name(title);
            bar.progress(prog);
        } else {
            BossBar bar = buffBars.remove(id);
            if (bar != null) player.hideBossBar(bar);
        }

        if (inWithdrawal) {
            long rem = d.getHerbWithdrawalUntilMillis() - now;
            long started = withdrawalStartedAt.getOrDefault(id, now);
            long tot = Math.max(1L, d.getHerbWithdrawalUntilMillis() - started);
            float prog = Math.max(0f, Math.min(1f, (float) rem / tot));
            Component title = Component.text("Cannabis-Entzug (kein Heilen): ", NamedTextColor.GOLD)
                    .append(Component.text(formatTime(rem), NamedTextColor.YELLOW));
            BossBar bar = withdrawalBars.computeIfAbsent(id, k -> {
                BossBar b = BossBar.bossBar(title, prog, BossBar.Color.YELLOW,
                        BossBar.Overlay.NOTCHED_10);
                player.showBossBar(b);
                return b;
            });
            bar.name(title);
            bar.progress(prog);
        } else {
            BossBar bar = withdrawalBars.remove(id);
            if (bar != null) player.hideBossBar(bar);
        }
    }

    private String formatTime(long ms) {
        long totalSec = Math.max(0, ms / 1000L);
        long min = totalSec / 60;
        long sec = totalSec % 60;
        if (min > 0) return min + "m " + (sec < 10 ? "0" : "") + sec + "s";
        return sec + "s";
    }

    /** Entfernt beide BossBars (z. B. bei Logout oder Leaf-Reinigung). */
    public void removeBossBars(Player player) {
        UUID id = player.getUniqueId();
        BossBar b1 = buffBars.remove(id);
        if (b1 != null) player.hideBossBar(b1);
        BossBar b2 = withdrawalBars.remove(id);
        if (b2 != null) player.hideBossBar(b2);
        buffStartedAt.remove(id);
        withdrawalStartedAt.remove(id);
    }

    /** Ist der Spieler aktuell im Heilungs-Block? */
    public boolean isInWithdrawal(Player player) {
        PlayerData d = playerDataManager.get(player);
        long now = System.currentTimeMillis();
        // Withdrawal ist nur aktiv wenn Buff bereits vorbei ist
        return d.getHerbBuffUntilMillis() < now
                && d.getHerbWithdrawalUntilMillis() > now;
    }

    /** Hat der Spieler aktuell den Buff? */
    public boolean hasBuff(Player player) {
        PlayerData d = playerDataManager.get(player);
        return d.getHerbBuffUntilMillis() > System.currentTimeMillis();
    }
}
