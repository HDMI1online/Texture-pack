package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Speichert bereits gebaute Mineshaft-Dealer-Dörfer (pro Welt eine Liste von Locations).
 *
 * Min-Distanz zwischen zwei Dörfern: 300 Blöcke (war 2000 – zu restriktiv, da
 * Mineshaft-Truhen häufig sind und wir nicht alle zwei Schritte ein Dorf wollen).
 *
 * Speicherung:
 *  - plugins/SmokeAddiction/mineshaft_villages.yml  (intern, wie bisher)
 *  - dealer_villages.json im Server-Root-Verzeichnis (für externe Tools / Admins)
 */
public class MineshaftVillageRegistry {

    public static final double MIN_DISTANCE = 300.0; // war 2000 – viel zu restriktiv, blockierte fast alle weiteren Spawns

    private final SmokeAddictionPlugin plugin;
    private final File file;
    /** JSON-Datei im Server-Root-Verzeichnis (parent des plugins-Ordners). */
    private final File jsonFile;
    private final Map<UUID, List<Location>> villages = new HashMap<>();

    public MineshaftVillageRegistry(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "mineshaft_villages.yml");
        // Server-Root = plugins/../  (bei Standard-Bukkit-Layout)
        File serverRoot = plugin.getDataFolder().getParentFile().getParentFile();
        this.jsonFile = new File(serverRoot, "dealer_villages.json");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("worlds");
        if (root == null) return;
        for (String worldId : root.getKeys(false)) {
            try {
                UUID id = UUID.fromString(worldId);
                List<Location> list = new ArrayList<>();
                for (String entry : root.getStringList(worldId)) {
                    String[] parts = entry.split(",");
                    if (parts.length != 3) continue;
                    World w = Bukkit.getWorld(id);
                    if (w == null) continue;
                    list.add(new Location(w,
                            Double.parseDouble(parts[0]),
                            Double.parseDouble(parts[1]),
                            Double.parseDouble(parts[2])));
                }
                villages.put(id, list);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void save() {
        saveYaml();
        saveJson();
    }

    /** Speichert die interne YAML-Datei (wie bisher). */
    private void saveYaml() {
        YamlConfiguration cfg = new YamlConfiguration();
        Map<String, Object> root = new HashMap<>();
        for (Map.Entry<UUID, List<Location>> e : villages.entrySet()) {
            List<String> entries = new ArrayList<>();
            for (Location l : e.getValue()) {
                entries.add(l.getX() + "," + l.getY() + "," + l.getZ());
            }
            root.put(e.getKey().toString(), entries);
        }
        cfg.set("worlds", root);
        try { cfg.save(file); }
        catch (IOException ex) {
            plugin.getLogger().warning("Konnte mineshaft_villages.yml nicht speichern: " + ex.getMessage());
        }
    }

    /**
     * Speichert alle Dealer-Village-Locations als JSON-Datei im Server-Root.
     * Format:
     * {
     *   "dealer_villages": [
     *     { "world": "world", "worldUid": "...", "x": 100, "y": 64, "z": -200 },
     *     ...
     *   ]
     * }
     */
    private void saveJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"dealer_villages\": [\n");
        boolean firstEntry = true;
        for (Map.Entry<UUID, List<Location>> e : villages.entrySet()) {
            World w = Bukkit.getWorld(e.getKey());
            String worldName = (w != null) ? w.getName() : "unknown";
            String worldUid = e.getKey().toString();
            for (Location l : e.getValue()) {
                if (!firstEntry) sb.append(",\n");
                sb.append("    {")
                  .append(" \"world\": \"").append(worldName).append("\"")
                  .append(", \"worldUid\": \"").append(worldUid).append("\"")
                  .append(", \"x\": ").append((int) l.getX())
                  .append(", \"y\": ").append((int) l.getY())
                  .append(", \"z\": ").append((int) l.getZ())
                  .append(" }");
                firstEntry = false;
            }
        }
        sb.append("\n  ]\n}\n");
        try (FileWriter fw = new FileWriter(jsonFile)) {
            fw.write(sb.toString());
        } catch (IOException ex) {
            plugin.getLogger().warning("Konnte dealer_villages.json nicht speichern: " + ex.getMessage());
        }
    }

    public boolean isVillageNearby(Location loc) {
        if (loc.getWorld() == null) return false;
        List<Location> list = villages.get(loc.getWorld().getUID());
        if (list == null) return false;
        for (Location v : list) {
            if (v.distanceSquared(loc) < MIN_DISTANCE * MIN_DISTANCE) return true;
        }
        return false;
    }

    public void register(Location loc) {
        if (loc.getWorld() == null) return;
        villages.computeIfAbsent(loc.getWorld().getUID(), k -> new ArrayList<>()).add(loc);
        save();
    }

    /** Alle registrierten Dealer-Dörfer, gruppiert nach Welt-UUID. */
    public Map<UUID, List<Location>> getVillages() { return villages; }
}
