package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Trackt PvP-Kills und leitet Join/Quit ans Scoreboard-System weiter. */
public class ScoreboardListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public ScoreboardListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.getSaScoreboardManager().isGloballyEnabled()) return;
        Player dead = e.getEntity();
        // Tode in PlayerData persistieren
        var pd = plugin.getPlayerDataManager().get(dead);
        pd.setTotalDeaths(pd.getTotalDeaths() + 1);
        // PvP-Kill zählen (nur Spieler→Spieler)
        Player killer = dead.getKiller();
        if (killer != null && killer != dead) {
            plugin.getSaScoreboardManager().addKill(killer);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        // Kleinen Delay damit PlayerData vollständig geladen ist
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (e.getPlayer().isOnline())
                plugin.getSaScoreboardManager().onJoin(e.getPlayer());
        }, 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.getSaScoreboardManager().onQuit(e.getPlayer());
    }
}
