package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.CasinoType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Speichert pro Casino-Block-Location den Typ. Persistiert in casinos.yml.
 * Lookup über Block-Coords ist O(1) via String-Key.
 */
public class CasinoRegistry {

    private final SmokeAddictionPlugin plugin;
    private final File file;
    /** Key: "worldUUID:x:y:z" → CasinoType */
    private final Map<String, CasinoType> casinos = new HashMap<>();

    public CasinoRegistry(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "casinos.yml");
        load();
    }

    private static String key(Location l) {
        if (l.getWorld() == null) return "";
        return l.getWorld().getUID() + ":"
                + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("casinos");
        if (root == null) return;
        for (String k : root.getKeys(false)) {
            try {
                CasinoType t = CasinoType.valueOf(root.getString(k));
                casinos.put(k, t);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        Map<String, Object> root = new HashMap<>();
        for (Map.Entry<String, CasinoType> e : casinos.entrySet()) {
            root.put(e.getKey(), e.getValue().name());
        }
        cfg.set("casinos", root);
        try { cfg.save(file); }
        catch (IOException ex) {
            plugin.getLogger().warning("Konnte casinos.yml nicht speichern: " + ex.getMessage());
        }
    }

    public void register(Location loc, CasinoType type) {
        casinos.put(key(loc), type);
        save();
    }

    public CasinoType get(Location loc) {
        return casinos.get(key(loc));
    }

    public boolean isCasino(Location loc) {
        return casinos.containsKey(key(loc));
    }
}
