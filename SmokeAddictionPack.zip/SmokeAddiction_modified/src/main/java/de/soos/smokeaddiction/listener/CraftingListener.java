package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

/**
 * Prüft beim Crafting der "Selbstgedrehten Zigarette",
 * ob das DRIED_KELP wirklich unser Tabak-Item ist (PDC-Check).
 * Andernfalls wird das Result auf null gesetzt – damit Spieler
 * nicht mit normalem Vanilla-Dried-Kelp Zigaretten craften können.
 */
public class CraftingListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public CraftingListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        Recipe recipe = e.getRecipe();
        if (!(recipe instanceof Keyed keyed)) return;

        // Mit ExactChoice in den Recipe-Definitionen matcht Bukkit jetzt selbst nur unsere
        // Plugin-Items. Wir brauchen hier nur noch die Shisha-Spezial-Validation (Mundane Potion).
        NamespacedKey shishaKey = plugin.getRecipeManager().getShishaKey();
        if (shishaKey != null && shishaKey.equals(keyed.getKey())) {
            validateShisha(e);
        }
    }

    /** Shisha-Rezept: Trank muss eine Mundane Potion sein ("Seltsamer Trank"). */
    private void validateShisha(PrepareItemCraftEvent e) {
        ItemStack[] matrix = e.getInventory().getMatrix();
        for (ItemStack s : matrix) {
            if (s == null || s.getType() != Material.POTION) continue;
            if (!(s.getItemMeta() instanceof org.bukkit.inventory.meta.PotionMeta pm)) {
                e.getInventory().setResult(null);
                return;
            }
            // Mundane Potion: PotionType.MUNDANE oder Base-Type ist MUNDANE/WATER ohne Effekte.
            // PotionMeta#getBasePotionType (Paper 1.20.5+) liefert den PotionType.
            try {
                org.bukkit.potion.PotionType pt = pm.getBasePotionType();
                if (pt != org.bukkit.potion.PotionType.MUNDANE) {
                    e.getInventory().setResult(null);
                    return;
                }
            } catch (Throwable ignored) {
                // Fallback (sehr alte API): wir lassen es passieren
            }
        }
    }
}
