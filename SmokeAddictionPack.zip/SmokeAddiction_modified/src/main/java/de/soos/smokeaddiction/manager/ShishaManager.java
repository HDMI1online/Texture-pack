package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import de.soos.smokeaddiction.util.Keys;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.EulerAngle;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Verwaltet alle Aspekte der Shisha:
 *  - Platzieren als unsichtbarer ArmorStand mit End-Rod auf dem Kopf
 *  - State im PDC (Wasser ja/nein, verbleibende Tabak-Nutzungen)
 *  - Aktive 30-Sekunden Sitzung mit BossBar, Sounds, dichten Partikelwolken
 *  - Passiv-Nikotin für Bystander im Rauch
 *  - Locator-Effekt nach erfolgreicher Sitzung (Glowing für nahe Spieler)
 */
public class ShishaManager {

    /** Nutzungen pro Tabak-Füllung. */
    public static final int FILL_USES = 5;

    /** Sitzungsdauer in Ticks (30 s). */
    public static final int SESSION_TICKS = 30 * 20;

    /** Maximale Distanz zur Shisha während einer Sitzung. */
    public static final double MAX_SESSION_DISTANCE = 4.0;

    /** Radius (Blöcke) für Passiv-Rauch. */
    public static final double PASSIVE_RADIUS_XZ = 6.0;
    public static final double PASSIVE_RADIUS_Y  = 4.0;

    /** Locator-Dauer nach einer Sitzung. */
    public static final int LOCATOR_TICKS = 30 * 20;
    public static final double LOCATOR_RADIUS = 64.0;

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, BukkitTask> locatorTasks = new HashMap<>();

    public ShishaManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    // === Identifikation ===

    public boolean isShishaEntity(Entity e) {
        if (!(e instanceof ArmorStand)) return false;
        Byte v = e.getPersistentDataContainer().get(Keys.ENTITY_SHISHA, PersistentDataType.BYTE);
        return v != null && v == 1;
    }

    public boolean hasWater(ArmorStand as) {
        Byte v = as.getPersistentDataContainer().get(Keys.SHISHA_WATER, PersistentDataType.BYTE);
        return v != null && v == 1;
    }

    public int getRemainingUses(ArmorStand as) {
        Integer v = as.getPersistentDataContainer().get(Keys.SHISHA_USES, PersistentDataType.INTEGER);
        return v == null ? 0 : v;
    }

    public void setWater(ArmorStand as, boolean has) {
        as.getPersistentDataContainer().set(Keys.SHISHA_WATER, PersistentDataType.BYTE, (byte) (has ? 1 : 0));
    }

    public void setRemainingUses(ArmorStand as, int n) {
        as.getPersistentDataContainer().set(Keys.SHISHA_USES, PersistentDataType.INTEGER, Math.max(0, n));
    }

    public boolean isReady(ArmorStand as) {
        return hasWater(as) && getRemainingUses(as) > 0;
    }

    // === Platzieren ===

    /** Platziert eine Shisha an der angegebenen Block-Location. */
    public ArmorStand place(Location blockLoc) {
        Location stand = blockLoc.clone().add(0.5, 0.0, 0.5);
        ArmorStand as = (ArmorStand) blockLoc.getWorld().spawnEntity(stand, EntityType.ARMOR_STAND);
        as.setVisible(false);
        as.setGravity(false);
        as.setSmall(false);
        as.setMarker(false);    // muss interagierbar/anklickbar sein
        as.setBasePlate(false);
        as.setArms(false);
        as.setInvulnerable(true);
        as.setCanPickupItems(false);
        as.setSilent(true);
        as.setHeadPose(new EulerAngle(0, 0, 0));
        as.setCustomNameVisible(false);

        // End Rod als "Stiel" der Shisha
        ItemStack head = plugin.getItemManager().createShisha(1);
        as.getEquipment().setItem(EquipmentSlot.HEAD, head);

        PersistentDataContainer pdc = as.getPersistentDataContainer();
        pdc.set(Keys.ENTITY_SHISHA, PersistentDataType.BYTE, (byte) 1);
        setWater(as, false);
        setRemainingUses(as, 0);

        // Kleines Schwebe-Partikel zur Kennzeichnung
        as.getWorld().spawnParticle(Particle.END_ROD,
                stand.clone().add(0, 1.7, 0), 8, 0.1, 0.1, 0.1, 0.02);

        return as;
    }

    public void remove(ArmorStand as) {
        as.remove();
    }

    // === Sessions ===

    public boolean isInSession(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    /**
     * Startet eine Shisha-Sitzung. Erwartet, dass alle Vorbedingungen
     * (Shisha gefüllt, Spieler nicht schon in Session) geprüft sind.
     */
    public void startSession(Player player, ArmorStand shisha) {
        if (isInSession(player)) return;

        BossBar bar = BossBar.bossBar(
                Component.text("Shisha-Zug ...", NamedTextColor.LIGHT_PURPLE),
                0f, BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
        player.showBossBar(bar);

        Session s = new Session(player.getUniqueId(), shisha.getUniqueId(),
                shisha.getLocation().clone(), bar);
        sessions.put(player.getUniqueId(), s);

        // Sound: Blubbern beim Start
        player.getWorld().playSound(shisha.getLocation(),
                Sound.BLOCK_BUBBLE_COLUMN_BUBBLE_POP, 1.4f, 0.7f);

        s.task = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                Player p = plugin.getServer().getPlayer(s.playerUuid);
                Entity ent = plugin.getServer().getEntity(s.shishaUuid);
                if (p == null || !p.isOnline() || !(ent instanceof ArmorStand as) || as.isDead()) {
                    cleanup(s);
                    cancel();
                    return;
                }

                // Sneak bricht ab
                if (p.isSneaking()) {
                    p.sendMessage(Component.text("Shisha-Zug abgebrochen.", NamedTextColor.RED));
                    cleanup(s);
                    cancel();
                    return;
                }

                // Distanz prüfen
                if (p.getWorld() != as.getWorld()
                        || p.getLocation().distanceSquared(as.getLocation())
                                > MAX_SESSION_DISTANCE * MAX_SESSION_DISTANCE) {
                    p.sendMessage(Component.text("Du bist zu weit von der Shisha entfernt.",
                            NamedTextColor.RED));
                    cleanup(s);
                    cancel();
                    return;
                }

                // Dichte Rauchpartikel
                spawnSmoke(as.getLocation().clone().add(0, 1.5, 0));

                // Periodische Sounds (alle ~20 Ticks)
                if (ticks % 20 == 10) {
                    p.getWorld().playSound(as.getLocation(),
                            Sound.BLOCK_BUBBLE_COLUMN_BUBBLE_POP, 1.0f,
                            0.6f + (ticks / (float) SESSION_TICKS) * 0.6f);
                }
                if (ticks % 40 == 0) {
                    p.getWorld().playSound(p.getLocation(),
                            Sound.ENTITY_GENERIC_DRINK, 0.8f, 1.5f);
                }

                // Passiv-Rauch für Bystander
                applyPassiveSmoke(as, p);

                ticks++;
                bar.progress(Math.min(1f, ticks / (float) SESSION_TICKS));

                if (ticks >= SESSION_TICKS) {
                    finishSession(p, as, s);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void finishSession(Player p, ArmorStand as, Session s) {
        // Tabak verbrauchen
        int uses = getRemainingUses(as);
        setRemainingUses(as, Math.max(0, uses - 1));
        if (uses - 1 <= 0) {
            // Wasser verschmutzt – beim Aufbrauchen des Tabaks gilt die Wasser-Füllung als verbraucht
            setWater(as, false);
        }

        // Nikotin auf Maximum
        plugin.getNicotineManager().onShishaSession(p);

        // Achievement-Broadcast für allerersten Zug
        PlayerData data = plugin.getPlayerDataManager().get(p);
        if (!data.hasUsedShisha()) {
            data.setShishaUsed(true);
            Component msg = Component.text(p.getName() + " hat zum ersten Mal an einer Shisha gezogen!",
                    NamedTextColor.LIGHT_PURPLE);
            plugin.getServer().broadcast(msg);
            p.getWorld().playSound(p.getLocation(),
                    Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        }

        // Locator-Effekt für 30 s
        startLocator(p);

        // Abschluss-Sound + dicke Endwolke
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 0.4f, 1.4f);
        spawnBigExhale(p.getEyeLocation());

        cleanup(s);
    }

    /** Bricht eine laufende Sitzung sofort ab (z. B. Logout, Tod, Item-Abbau). */
    public void cancelSession(Player p) {
        Session s = sessions.get(p.getUniqueId());
        if (s != null) cleanup(s);
    }

    private void cleanup(Session s) {
        Player p = plugin.getServer().getPlayer(s.playerUuid);
        if (p != null) p.hideBossBar(s.bar);
        if (s.task != null && !s.task.isCancelled()) s.task.cancel();
        sessions.remove(s.playerUuid);
    }

    // === Partikel ===

    /**
     * Erzeugt sehr dichten, nach oben aufsteigenden Rauch.
     * Mehrere Partikeltypen werden überlagert für maximale Dichte und Optik.
     */
    private void spawnSmoke(Location origin) {
        var w = origin.getWorld();
        if (w == null) return;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Massiver weißer Rauch-Hauptkörper
        w.spawnParticle(Particle.CLOUD,
                origin.getX(), origin.getY(), origin.getZ(),
                28, 0.6, 0.3, 0.6, 0.03);

        // Dichter aufsteigender Lagerfeuerrauch – 8 Layer statt 5, mehr Partikel
        for (int layer = 0; layer < 8; layer++) {
            double y = origin.getY() + 0.7 * layer + rnd.nextDouble(-0.2, 0.2);
            double spread = 0.4 + 0.35 * layer;
            w.spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                    origin.getX() + rnd.nextDouble(-spread, spread),
                    y,
                    origin.getZ() + rnd.nextDouble(-spread, spread),
                    4, spread, 0.12, spread, 0.01);
        }

        // Breite violette Dust-Wolke über größeren Bereich
        Particle.DustOptions dust = new Particle.DustOptions(
                Color.fromRGB(220, 200, 255), 2.0f);
        for (int i = 0; i < 14; i++) {
            double y = origin.getY() + rnd.nextDouble(0.0, 5.0);
            double r = rnd.nextDouble(0.0, 1.2 + y * 0.25);
            double a = rnd.nextDouble(0, Math.PI * 2);
            w.spawnParticle(Particle.DUST,
                    origin.getX() + Math.cos(a) * r,
                    y,
                    origin.getZ() + Math.sin(a) * r,
                    1, 0, 0, 0, 0, dust);
        }

        // LARGE_SMOKE-Puffs – deutlich häufiger und mehr Partikel
        if (rnd.nextInt(2) == 0) {
            w.spawnParticle(Particle.LARGE_SMOKE,
                    origin.getX(), origin.getY() + 1.2, origin.getZ(),
                    8, 0.7, 0.6, 0.7, 0.025);
        }

        // Zusätzliche Rauchsäule weiter oben
        w.spawnParticle(Particle.CAMPFIRE_SIGNAL_SMOKE,
                origin.getX() + rnd.nextDouble(-0.3, 0.3),
                origin.getY() + 1.0,
                origin.getZ() + rnd.nextDouble(-0.3, 0.3),
                2, 0.2, 0.1, 0.2, 0.005);
    }

    /** Großer Atemzug-Effekt am Ende der Sitzung (vor dem Spieler). */
    private void spawnBigExhale(Location eye) {
        var dir = eye.getDirection().multiply(0.6);
        Location front = eye.clone().add(dir);
        eye.getWorld().spawnParticle(Particle.CLOUD,
                front.getX(), front.getY(), front.getZ(),
                80, 0.6, 0.4, 0.6, 0.06);
        eye.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                front.getX(), front.getY(), front.getZ(),
                60, 0.5, 0.4, 0.5, 0.06);
        eye.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                front.getX(), front.getY(), front.getZ(),
                20, 0.5, 0.3, 0.5, 0.03);
    }

    /** Wendet Passiv-Nikotin auf Bystander im Rauchradius an. */
    private void applyPassiveSmoke(ArmorStand as, Player smoker) {
        for (Entity e : as.getWorld().getNearbyEntities(
                as.getLocation(), PASSIVE_RADIUS_XZ, PASSIVE_RADIUS_Y, PASSIVE_RADIUS_XZ)) {
            if (!(e instanceof Player other)) continue;
            if (other.getUniqueId().equals(smoker.getUniqueId())) continue;

            // ~Eine Sekunde-Granularität: nur jeden 20. Tick anwenden
            // (Wir werden einmal pro Tick aufgerufen, also random gating)
            if (ThreadLocalRandom.current().nextInt(20) != 0) continue;
            plugin.getNicotineManager().onPassiveSmoke(other, 0.1);
        }
    }

    // === Locator-Effekt nach Sitzung ===

    /**
     * Wendet 30 s lang Glowing auf nahe Spieler an und zeigt Distanz/Anzahl
     * im Action-Bar des Nutzers (1.21.1-Equivalent zur "Locator Bar").
     */
    private void startLocator(Player user) {
        // Eventuell bestehenden Locator-Task beenden
        BukkitTask prev = locatorTasks.remove(user.getUniqueId());
        if (prev != null && !prev.isCancelled()) prev.cancel();

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                Player p = plugin.getServer().getPlayer(user.getUniqueId());
                if (p == null || !p.isOnline()) {
                    cancel();
                    locatorTasks.remove(user.getUniqueId());
                    return;
                }

                Player nearest = null;
                double nearestSq = Double.MAX_VALUE;
                int count = 0;
                for (Player other : plugin.getServer().getOnlinePlayers()) {
                    if (other.getUniqueId().equals(p.getUniqueId())) continue;
                    if (other.getWorld() != p.getWorld()) continue;
                    double dSq = other.getLocation().distanceSquared(p.getLocation());
                    if (dSq > LOCATOR_RADIUS * LOCATOR_RADIUS) continue;
                    count++;
                    // Glowing alle 4 Sekunden frisch setzen
                    if (ticks % 80 == 0) {
                        other.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                                100, 0, true, false, false));
                    }
                    if (dSq < nearestSq) {
                        nearestSq = dSq;
                        nearest = other;
                    }
                }

                if (nearest != null) {
                    p.sendActionBar(Component.text("Locator: " + count
                            + " Spieler in der Nähe – nächster: "
                            + nearest.getName() + " ("
                            + String.format("%.1f", Math.sqrt(nearestSq)) + " m)",
                            NamedTextColor.LIGHT_PURPLE));
                } else {
                    p.sendActionBar(Component.text("Locator aktiv – keine Spieler in der Nähe.",
                            NamedTextColor.GRAY));
                }

                ticks++;
                if (ticks >= LOCATOR_TICKS) {
                    p.sendActionBar(Component.text("Locator-Effekt abgelaufen.", NamedTextColor.GRAY));
                    cancel();
                    locatorTasks.remove(user.getUniqueId());
                }
            }
        }.runTaskTimer(plugin, 5L, 5L);
        locatorTasks.put(user.getUniqueId(), task);
    }

    /** Datenobjekt einer Shisha-Sitzung. */
    public static class Session {
        public final UUID playerUuid;
        public final UUID shishaUuid;
        public final Location origin;
        public final BossBar bar;
        public BukkitTask task;
        public Session(UUID p, UUID s, Location o, BossBar b) {
            this.playerUuid = p;
            this.shishaUuid = s;
            this.origin = o;
            this.bar = b;
        }
    }
}
