package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Verwaltet das Monster-White-System (Koffein-Energy-Drink):
 *
 *  - Stapelt sich mit allen anderen Effekten im Plugin (Nikotin, Alkohol,
 *    Substanzen, Heilkraut, ...) – greift in keinen davon ein.
 *  - Pro Dose: +0,5 Geschwindigkeit, +0,5 Schild, 2 Minuten Wirkdauer.
 *    Erneuter Konsum innerhalb der Wirkdauer REFRESHT die Bar auf volle 2 Minuten
 *    (kein Maximum-Vergleich, echter Reset – gleiches Prinzip wie bei allen
 *    anderen Substanzen im Plugin) und erhöht den Stack-Zähler (max. 4 wirksame Stacks).
 *  - Ab der 5. Dose IN FOLGE (während die Bar noch läuft): Vergiftung,
 *    bis die Koffein-Monster-Bar komplett verschwindet.
 *
 * Umrechnung der abstrakten "Punkte" auf echte Minecraft-Mechanik (siehe Konstanten):
 *   1,0 Geschwindigkeits-Punkt  = +20% Bewegungstempo (≈ vanilla Speed I)
 *   1,0 Schild-Punkt            = +2,0 Absorption-HP (1 Herz)
 *  → 0,5 Punkte/Dose = +10% Tempo und +1,0 Absorption-HP (halbes Herz) pro Dose.
 */
public class MonsterManager {

    public static final int    MAX_EFFECTIVE_STACKS   = 4;
    public static final long   DURATION_MS            = 120_000L; // 2 Minuten
    public static final double SPEED_PER_STACK         = 0.10;   // +10% Movement Speed pro Stack
    public static final double SHIELD_HP_PER_STACK      = 1.0;    // +1,0 Absorption-HP (0,5 Herz) pro Stack

    private final SmokeAddictionPlugin plugin;
    private final PlayerDataManager playerDataManager;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final NamespacedKey speedModifierKey;

    public MonsterManager(SmokeAddictionPlugin plugin, PlayerDataManager pdm) {
        this.plugin = plugin;
        this.playerDataManager = pdm;
        this.speedModifierKey = new NamespacedKey(plugin, "monster_white_speed");
    }

    // ============================================================
    // Konsum
    // ============================================================

    /** Spieler hat eine Dose Monster White getrunken. */
    public void onConsume(Player p) {
        PlayerData d = playerDataManager.get(p);
        long now = System.currentTimeMillis();

        // Wirkdauer abgelaufen? Dann ist das eine "neue" Konsum-Serie -> Stacks zurücksetzen.
        if (d.getMonsterUntilMillis() <= now) {
            d.setMonsterStacks(0);
        }

        int newStacks = d.getMonsterStacks() + 1;
        d.setMonsterStacks(newStacks);
        d.setMonsterUntilMillis(now + DURATION_MS); // Bar wird mit jeder Dose neu auf volle Dauer gesetzt

        applyState(p, d);

        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.8f, 1.4f);
        p.sendActionBar(Component.text("Du trinkst: Monster White", NamedTextColor.WHITE));
    }

    // ============================================================
    // Tick (1x/Sekunde vom MonsterTickTask aufgerufen, sowie direkt nach Konsum/Join)
    // ============================================================

    public void tick(Player p) {
        PlayerData d = playerDataManager.get(p);
        long now = System.currentTimeMillis();

        if (d.getMonsterUntilMillis() <= now) {
            if (d.getMonsterStacks() != 0 || bars.containsKey(p.getUniqueId())) {
                // Bar ist gerade abgelaufen -> alles sauber zurücksetzen
                d.setMonsterStacks(0);
                clearState(p);
            }
            return;
        }
        applyState(p, d);
    }

    /** Wendet Speed/Schild/Vergiftung passend zum aktuellen Stack-Stand an und aktualisiert die BossBar. */
    private void applyState(Player p, PlayerData d) {
        long now = System.currentTimeMillis();
        int stacks = d.getMonsterStacks();
        int effectiveStacks = Math.min(MAX_EFFECTIVE_STACKS, stacks);
        boolean overdose = stacks > MAX_EFFECTIVE_STACKS;
        int ticksLeft = (int) Math.max(20L, (d.getMonsterUntilMillis() - now) / 50L) + 20;

        // Geschwindigkeit: ein einzelner, immer aktueller Attribute-Modifier (exakte
        // +10%-pro-Stack-Mathematik) UND zusätzlich ein klassischer Speed-Potion-Effekt
        // (Icon + Partikel + garantiert sichtbar, gleiches bewährtes Muster wie überall
        // sonst im Plugin) – falls die Attribute-API auf diesem Server abweicht, sorgt
        // der Potion-Effekt trotzdem für spürbar schnellere Bewegung.
        try {
            AttributeInstance speedAttr = getMovementSpeedAttribute(p);
            if (speedAttr != null) {
                speedAttr.removeModifier(speedModifierKey);
                if (effectiveStacks > 0) {
                    speedAttr.addModifier(new AttributeModifier(speedModifierKey,
                            SPEED_PER_STACK * effectiveStacks, AttributeModifier.Operation.MULTIPLY_SCALAR_1));
                }
            }
        } catch (Throwable ex) {
            plugin.getLogger().warning("Monster White: Speed-Attribute-Modifier fehlgeschlagen: " + ex);
        }

        if (effectiveStacks > 0) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                    ticksLeft, effectiveStacks - 1, true, true, true));
        } else {
            p.removePotionEffect(PotionEffectType.SPEED);
        }

        // Schild: Absorption-HP passend zum aktuellen Stack-Stand setzen (Monster-eigener Anteil)
        float targetAbsorption = (float) (SHIELD_HP_PER_STACK * effectiveStacks);
        p.setAbsorptionAmount(Math.max(targetAbsorption, 0f));

        // Überdosis: Vergiftung, solange die Bar noch läuft
        if (overdose) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, ticksLeft, 0, true, true, true));
        } else {
            p.removePotionEffect(PotionEffectType.POISON);
        }

        updateBossBar(p, d, now, effectiveStacks, stacks, overdose);
    }

    /** Entfernt Speed/Schild/Vergiftung wieder vollständig und versteckt die BossBar. */
    private void clearState(Player p) {
        try {
            AttributeInstance speedAttr = getMovementSpeedAttribute(p);
            if (speedAttr != null) speedAttr.removeModifier(speedModifierKey);
        } catch (Throwable ex) {
            plugin.getLogger().warning("Monster White: Speed-Attribute-Modifier entfernen fehlgeschlagen: " + ex);
        }
        p.removePotionEffect(PotionEffectType.SPEED);
        p.setAbsorptionAmount(0f);
        p.removePotionEffect(PotionEffectType.POISON);
        removeBossBar(p);
        p.sendActionBar(Component.text("Der Koffein-Kick lässt nach.", NamedTextColor.GRAY));
    }

    // ============================================================
    // BossBar
    // ============================================================

    private void updateBossBar(Player p, PlayerData d, long now, int effectiveStacks, int rawStacks, boolean overdose) {
        long remaining = Math.max(0L, d.getMonsterUntilMillis() - now);
        float progress = Math.max(0f, Math.min(1f, remaining / (float) DURATION_MS));

        BossBar.Color color = overdose ? BossBar.Color.RED
                : effectiveStacks >= MAX_EFFECTIVE_STACKS ? BossBar.Color.GREEN
                : BossBar.Color.YELLOW;

        Component title = Component.text("Koffein-Monster: ", NamedTextColor.WHITE)
                .append(Component.text(rawStacks + "/" + MAX_EFFECTIVE_STACKS,
                        overdose ? NamedTextColor.RED : NamedTextColor.AQUA))
                .append(Component.text("  (" + formatTime(remaining) + ")", NamedTextColor.GRAY));
        if (overdose) {
            title = title.append(Component.text("  Überdosis – Vergiftung!", NamedTextColor.DARK_RED));
        }
        final Component finalTitle = title;

        BossBar bar = bars.computeIfAbsent(p.getUniqueId(), k -> {
            BossBar b = BossBar.bossBar(finalTitle, progress, color, BossBar.Overlay.NOTCHED_10);
            p.showBossBar(b);
            return b;
        });
        bar.name(title);
        bar.progress(progress);
        bar.color(color);
    }

    public void removeBossBar(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
    }

    private String formatTime(long ms) {
        long totalSec = Math.max(0, ms / 1000L);
        return totalSec + "s";
    }

    /**
     * Liest das Bewegungstempo-Attribut versionsneutral aus. Probiert mehrere Strategien
     * der Reihe nach, da sich sowohl die Java-Feldnamen als auch die Registry-Schlüssel
     * zwischen Paper-Versionen unterschieden haben (Attribute war früher ein Enum,
     * ist seit der Registry-Umstellung ein Interface mit statischen Feldern):
     *   1. Statisches Feld Attribute.MOVEMENT_SPEED (moderne Namensform)
     *   2. Statisches Feld Attribute.GENERIC_MOVEMENT_SPEED (ältere Namensform)
     *   3. Registry.ATTRIBUTE mit Schlüssel "movement_speed"
     *   4. Registry.ATTRIBUTE mit Schlüssel "generic.movement_speed"
     * Schlägt alles fehl, wird eine Warnung geloggt (statt lautlos null zurückzugeben),
     * damit ein verbleibendes Problem im Server-Log sichtbar wird.
     */
    private AttributeInstance getMovementSpeedAttribute(Player p) {
        Class<?> attrClass;
        try {
            attrClass = Class.forName("org.bukkit.attribute.Attribute");
        } catch (Throwable ex) {
            plugin.getLogger().warning("Monster White: Attribute-Klasse nicht gefunden: " + ex);
            return null;
        }

        Object attr = tryStaticField(attrClass, "MOVEMENT_SPEED");
        if (attr == null) attr = tryStaticField(attrClass, "GENERIC_MOVEMENT_SPEED");
        if (attr == null) attr = tryRegistryKey("movement_speed");
        if (attr == null) attr = tryRegistryKey("generic.movement_speed");

        if (attr == null) {
            plugin.getLogger().warning("Monster White: Bewegungstempo-Attribut konnte über "
                    + "keine der bekannten Strategien aufgelöst werden – Speed-Boost bleibt aus. "
                    + "Bitte melden, welche Paper-Version genutzt wird.");
            return null;
        }

        try {
            return (AttributeInstance) p.getClass().getMethod("getAttribute", attrClass).invoke(p, attr);
        } catch (Throwable ex) {
            plugin.getLogger().warning("Monster White: p.getAttribute() fehlgeschlagen: " + ex);
            return null;
        }
    }

    private Object tryStaticField(Class<?> attrClass, String fieldName) {
        try {
            return attrClass.getField(fieldName).get(null);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Object tryRegistryKey(String key) {
        try {
            org.bukkit.Registry<?> registry = org.bukkit.Registry.ATTRIBUTE;
            return registry.get(org.bukkit.NamespacedKey.minecraft(key));
        } catch (Throwable ignored) {
            return null;
        }
    }
}
