package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;

/**
 * Blockt jegliche Heilung während des Heilkraut-Entzugs (4 Min nach Buff-Ende).
 * Das schließt sowohl die Vanilla-Hunger-Regeneration als auch Heilungstränke,
 * Regeneration-Effekte aus anderen Quellen und Beacon-Heilung ein.
 */
public class HerbWithdrawalListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public HerbWithdrawalListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRegen(EntityRegainHealthEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (plugin.getHerbManager().isInWithdrawal(p)) {
            e.setCancelled(true);
        }
    }
}
