package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Display;
import org.bukkit.entity.Item;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Lädt gedroppte Akku-Vapes (Fumot 12k, Vozol 40k, Randm 15k), die in der Nähe
 * einer aktiven Redstone-Quelle liegen. Alle drei Sorten werden GENAUSO geladen
 * wie die Fumot 12k: einfach in der Welt fallen lassen (Q-Taste), in die Nähe
 * von Redstone-Power legen, fertig.
 *
 * Mechanik:
 *  - Task läuft alle 1 Sekunde (20 Ticks) und scannt alle dropped Items in geladenen Welten.
 *  - Eine Vape lädt, wenn im 3x3x3-Würfel um sie herum ein Block mit Redstone-Power steht
 *    (Power > 0) ODER ein REDSTONE_BLOCK selbst.
 *  - Ladegeschwindigkeit: jeweils 1/100 des Akku-Caps alle 12 Sekunden (100 Schritte =
 *    20 Minuten für eine volle Ladung, identisch bei allen drei Vape-Typen – das ist
 *    exakt Fumots ursprüngliche Rate von 1%/12s).
 *  - Während des Ladens: Funken-Partikel + schwebende Akkustand-Anzeige (TextDisplay)
 *    über der Vape.
 *  - Bei Erreichen von 100 %: deutlicher Sound + grüne Partikel + "VOLL geladen!" im Namen,
 *    die Schwebeanzeige verschwindet wieder.
 */
public class VapeDropChargeTask extends BukkitRunnable {

    /** Sekunden zwischen zwei Lade-Schritten. */
    private static final int CHARGE_INTERVAL_SECONDS = 12;

    private final SmokeAddictionPlugin plugin;
    private int tickCounter = 0;

    /** Schwebende Akkustand-Anzeigen, ein TextDisplay pro aktuell ladendem Item. */
    private final Map<UUID, TextDisplay> indicators = new HashMap<>();

    public VapeDropChargeTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        tickCounter++;
        ItemManager im = plugin.getItemManager();
        Set<UUID> stillCharging = new HashSet<>();

        for (World world : plugin.getServer().getWorlds()) {
            for (Item itemEntity : world.getEntitiesByClass(Item.class)) {
                ItemStack stack = itemEntity.getItemStack();
                if (!im.isChargeableVape(stack)) continue;

                boolean nearPower = isNearRedstonePower(itemEntity.getLocation());

                // Vape liegt auf/neben Redstone → niemals despawnen lassen.
                // Verlässt sie den Redstone-Bereich, läuft die normale Alterung wieder.
                itemEntity.setWillAge(!nearPower);

                int puffsOrLiquid = remainingUnits(im, stack);
                if (puffsOrLiquid <= 0) {
                    markEmptyUnits(im, stack);
                    itemEntity.setItemStack(stack);
                    continue;
                }

                boolean full = im.isFullyCharged(stack);

                if (nearPower && !full) {
                    stillCharging.add(itemEntity.getUniqueId());
                    updateIndicator(itemEntity, im.getBatteryPercent(stack));

                    world.spawnParticle(Particle.ELECTRIC_SPARK,
                            itemEntity.getLocation().add(0, 0.4, 0),
                            3, 0.2, 0.15, 0.2, 0.05);

                    if (tickCounter % CHARGE_INTERVAL_SECONDS == 0) {
                        boolean reachedFull = chargeOneStep(im, stack);
                        if (reachedFull) {
                            markFullyCharged(im, stack);
                            world.spawnParticle(Particle.HAPPY_VILLAGER,
                                    itemEntity.getLocation().add(0, 0.5, 0),
                                    25, 0.4, 0.3, 0.4, 0.1);
                            world.playSound(itemEntity.getLocation(),
                                    Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 2.0f);
                            world.playSound(itemEntity.getLocation(),
                                    Sound.BLOCK_NOTE_BLOCK_CHIME, 1.2f, 1.6f);
                            stillCharging.remove(itemEntity.getUniqueId());
                            removeIndicator(itemEntity.getUniqueId());
                        } else {
                            markCharging(im, stack);
                        }
                        itemEntity.setItemStack(stack);
                    } else if (tickCounter % 5 == 0) {
                        markCharging(im, stack);
                        itemEntity.setItemStack(stack);
                    }
                } else if (full) {
                    if (tickCounter % 5 == 0) {
                        markFullyCharged(im, stack);
                        itemEntity.setItemStack(stack);
                    }
                } else if (im.getBatteryPercent(stack) == 0) {
                    if (tickCounter % 5 == 0) {
                        markEmptyBattery(im, stack);
                        itemEntity.setItemStack(stack);
                    }
                }
            }
        }

        // Schwebeanzeigen aufräumen: alles entfernen, was nicht mehr ladend ist
        // (Item aufgehoben, Akku voll, Stromquelle weg, ...)
        indicators.keySet().removeIf(id -> {
            if (stillCharging.contains(id)) return false;
            TextDisplay td = indicators.get(id);
            if (td != null && td.isValid()) td.remove();
            return true;
        });
    }

    // ================================================================
    // Schwebende Akkustand-Anzeige
    // ================================================================

    private void updateIndicator(Item itemEntity, int batteryPct) {
        UUID id = itemEntity.getUniqueId();
        TextDisplay td = indicators.get(id);
        Location loc = itemEntity.getLocation().add(0, 0.55, 0);

        if (td == null || !td.isValid()) {
            td = itemEntity.getWorld().spawn(loc, TextDisplay.class, d -> {
                d.setBillboard(Display.Billboard.CENTER);
                d.setSeeThrough(false);
                d.setShadowed(false);
                d.setBackgroundColor(org.bukkit.Color.fromARGB(140, 0, 0, 0));
                d.setPersistent(false);
            });
            indicators.put(id, td);
        } else {
            td.teleport(loc);
        }
        td.text(batteryText(batteryPct));
    }

    private void removeIndicator(UUID itemEntityId) {
        TextDisplay td = indicators.remove(itemEntityId);
        if (td != null && td.isValid()) td.remove();
    }

    private Component batteryText(int pct) {
        NamedTextColor color = pct >= 60 ? NamedTextColor.GREEN
                : pct >= 25 ? NamedTextColor.YELLOW
                : NamedTextColor.RED;
        return Component.text("⚡ " + pct + "%", color).decoration(TextDecoration.BOLD, true);
    }

    /** Entfernt alle aktiven Schwebeanzeigen (z. B. bei Plugin-Disable). */
    public void clearAllIndicators() {
        for (TextDisplay td : indicators.values()) {
            if (td != null && td.isValid()) td.remove();
        }
        indicators.clear();
    }

    // ================================================================
    // Typ-Dispatch (Fumot / Vozol / Randm)
    // ================================================================

    private int remainingUnits(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack) || im.isVozol(stack)) return im.getVapePuffs(stack);
        if (im.isRandm(stack)) return (int) Math.round(im.getRandmLiquid(stack));
        return 0;
    }

    /**
     * Lädt um genau einen Schritt. ALLE drei Vape-Typen nutzen exakt Fumots Rate:
     * 100 Schritte à 12 Sekunden = 20 Minuten für eine komplette Vollladung,
     * unabhängig vom jeweiligen Akku-Cap (Fumot 100, Vozol 150, Randm 50).
     * Gibt true zurück wenn der Akku jetzt voll ist.
     */
    private boolean chargeOneStep(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack)) {
            int cap = ItemManager.FUMOT_MAX_BATTERY;
            int battery = Math.min(cap, im.getFumotBattery(stack) + cap / 100);
            im.setFumotBatteryRaw(stack, battery);
            return battery >= cap;
        } else if (im.isVozol(stack)) {
            double cap = ItemManager.VOZOL_PUFFS_PER_CHARGE;
            double charge = Math.min(cap, im.getVozolChargeLeft(stack) + cap / 100.0);
            im.setVozolChargeLeftRaw(stack, charge);
            return charge >= cap;
        } else if (im.isRandm(stack)) {
            double cap = ItemManager.RANDM_LIQUID_PER_CHARGE;
            double charge = Math.min(cap, im.getRandmChargeLeft(stack) + cap / 100.0);
            im.setRandmChargeLeftRaw(stack, charge);
            return charge >= cap;
        }
        return true;
    }

    private void markCharging(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack)) im.updateFumotDisplay(stack, ItemManager.FumotState.CHARGING);
        else if (im.isVozol(stack)) im.updateVozolDisplay(stack, ItemManager.VozolState.CHARGING);
        else if (im.isRandm(stack)) im.updateRandmDisplay(stack, ItemManager.RandmState.CHARGING);
    }

    private void markFullyCharged(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack)) im.updateFumotDisplay(stack, ItemManager.FumotState.FULLY_CHARGED);
        else if (im.isVozol(stack)) im.updateVozolDisplay(stack, ItemManager.VozolState.FULLY_CHARGED);
        else if (im.isRandm(stack)) im.updateRandmDisplay(stack, ItemManager.RandmState.FULLY_CHARGED);
    }

    private void markEmptyBattery(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack)) im.updateFumotDisplay(stack, ItemManager.FumotState.EMPTY_BATTERY);
        else if (im.isVozol(stack)) im.updateVozolDisplay(stack, ItemManager.VozolState.EMPTY_BATTERY);
        else if (im.isRandm(stack)) im.updateRandmDisplay(stack, ItemManager.RandmState.EMPTY_BATTERY);
    }

    private void markEmptyUnits(ItemManager im, ItemStack stack) {
        if (im.isFumot(stack)) im.updateFumotDisplay(stack, ItemManager.FumotState.EMPTY_PUFFS);
        else if (im.isVozol(stack)) im.updateVozolDisplay(stack, ItemManager.VozolState.EMPTY_PUFFS);
        else if (im.isRandm(stack)) im.updateRandmDisplay(stack, ItemManager.RandmState.EMPTY_LIQUID);
    }

    /**
     * Prüft ob im 3x3x3-Würfel um die Location herum eine Redstone-Quelle aktiv ist.
     * Berücksichtigt: REDSTONE_BLOCK (immer aktiv), und alle Blöcke mit getBlockPower() > 0
     * (gepowerte Leitungen, gedrückte Knöpfe/Hebel, aktive Repeater/Comparator etc.).
     */
    private boolean isNearRedstonePower(Location loc) {
        Block at = loc.getBlock();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block b = at.getRelative(dx, dy, dz);
                    if (b.getType() == Material.REDSTONE_BLOCK) return true;
                    try {
                        if (b.getBlockPower() > 0) return true;
                        if (b.isBlockIndirectlyPowered()) return true;
                    } catch (Exception ignored) {
                        // Manche Blöcke könnten in seltenen Fällen werfen; wir ignorieren das.
                    }
                }
            }
        }
        return false;
    }
}
