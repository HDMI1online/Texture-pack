package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.model.RandmStrength;
import de.soos.smokeaddiction.model.VapeFlavor;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Randm-15k-Mechanik:
 *  - Linksklick (Arm-Schwung) mit Randm in der Hand: schaltet die Zugstärke durch
 *    (Leicht -> Normal -> Stark -> Surge -> Leicht ...).
 *  - Rechtsklick: nimmt einen Zug nach der aktuellen Stärke (Leicht/Normal/Stark =
 *    fester Wert, sofort). Surge: Ziehen halten – je länger gehalten wird, desto mehr
 *    Nikotin (und desto mehr Liquid-Verbrauch), bis Loslassen oder max. 4 Sekunden.
 *
 * "Halten" wird erkannt, indem wir bei jedem eingehenden Rechtsklick-Event den
 * Session-Zeitstempel aktualisieren; eine Tick-Task beendet die Surge-Session
 * automatisch, sobald für ein paar Ticks kein neues Klick-Event mehr eintraf
 * (= Spieler hat die Maustaste losgelassen).
 */
public class RandmVapeListener implements Listener {

    /** Cooldown in Millisekunden zwischen zwei normalen Zügen (Leicht/Normal/Stark). */
    private static final long PUFF_COOLDOWN_MS = 1200L;
    /** Wie viele Ticks ohne neues Interact-Event = Maustaste loslassen (Surge). */
    private static final int SURGE_RELEASE_TICKS = 4;

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, Long> lastPuff = new HashMap<>();
    private final Map<UUID, SurgeSession> surgeSessions = new HashMap<>();
    /** Zeitstempel des letzten Rechtsklicks mit Randm in der Hand (zur Trennung von
     *  Rechtsklick-ausgelösten Arm-Schwüngen gegenüber echten Linksklicks, siehe onSwing). */
    private final Map<UUID, Long> lastRightClick = new HashMap<>();

    public RandmVapeListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Linksklick: Stärke durchschalten.
     *
     * WICHTIG: Minecraft schickt bei einem Rechtsklick (besonders Rechtsklick auf Luft)
     * teils ebenfalls ein Arm-Schwung-Paket, wodurch dieses Event auch bei einem reinen
     * Zug-Rechtsklick feuern würde. Um das zu vermeiden, verzögern wir die Auswertung um
     * einen Tick: Ist im selben Augenblick (wenige ms vorher) ein Rechtsklick mit der
     * Randm in der Hand eingegangen, werten wir den Schwung als dessen Folge und NICHT
     * als eigenständigen Linksklick.
     */
    @EventHandler(ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        ItemManager im = plugin.getItemManager();
        if (!im.isRandm(p.getInventory().getItemInMainHand())) return;

        UUID id = p.getUniqueId();
        long swingTime = System.currentTimeMillis();

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (!im.isRandm(hand)) return;

            Long rc = lastRightClick.get(id);
            if (rc != null && Math.abs(swingTime - rc) < 200L) {
                // Dieser Schwung gehört zu einem Rechtsklick-Zug, keine Stärke wechseln.
                return;
            }

            // Während einer laufenden Surge-Session nicht umschalten (würde verwirren)
            if (surgeSessions.containsKey(id)) return;

            RandmStrength current = im.getRandmStrength(hand);
            RandmStrength next = current.next();
            im.setRandmStrengthRaw(hand, next);
            im.updateRandmDisplay(hand, ItemManager.RandmState.IDLE);

            p.sendActionBar(Component.text("Stärke: ", NamedTextColor.GRAY)
                    .append(Component.text(next.getDisplayName(), strengthActionColor(next))));
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, next == RandmStrength.SURGE ? 1.8f : 1.2f);
        });
    }

    /** Rechtsklick: Zug nehmen (oder bei Surge: Hold-Session starten/verlängern). */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemManager im = plugin.getItemManager();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!im.isRandm(hand)) return;

        // Zeitstempel sofort merken, damit onSwing diesen Klick von einem echten
        // Linksklick unterscheiden kann (siehe Kommentar dort).
        lastRightClick.put(p.getUniqueId(), System.currentTimeMillis());

        // Zaubertisch-Klick durchlassen
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK
                && e.getClickedBlock() != null
                && e.getClickedBlock().getType() == Material.ENCHANTING_TABLE) {
            return;
        }

        e.setCancelled(true);

        RandmStrength strength = im.getRandmStrength(hand);
        if (strength == RandmStrength.SURGE) {
            handleSurgeTick(p, im, hand);
            return;
        }

        // Leicht / Normal / Stark: fester Zug mit Cooldown
        long now = System.currentTimeMillis();
        long last = lastPuff.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < PUFF_COOLDOWN_MS) return;
        lastPuff.put(p.getUniqueId(), now);

        double liquid = im.getRandmLiquid(hand);
        double chargeLeft = im.getRandmChargeLeft(hand);

        if (liquid <= 0.0) {
            p.sendMessage(Component.text("Diese Vape ist leer.", NamedTextColor.GRAY));
            im.updateRandmDisplay(hand, ItemManager.RandmState.EMPTY_LIQUID);
            return;
        }
        if (chargeLeft <= 0.0) {
            p.sendMessage(Component.text("Akku leer! Drop sie an einer Redstone-Quelle zum Laden.",
                    NamedTextColor.RED));
            im.updateRandmDisplay(hand, ItemManager.RandmState.EMPTY_BATTERY);
            p.playSound(p.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.6f, 0.8f);
            return;
        }

        double nicotineGain = strength.getNicotinePerPuff();
        double liquidCost   = strength.getLiquidPerPuff();

        im.setRandmLiquidRaw(hand, liquid - liquidCost);
        im.setRandmChargeLeftRaw(hand, chargeLeft - liquidCost);
        im.updateRandmDisplay(hand, ItemManager.RandmState.IN_USE);
        applyRandmPuffVisuals(p, hand);
        plugin.getNicotineManager().onVapePuffAmount(p, nicotineGain);

        int batteryPct = (int) Math.round(((chargeLeft - liquidCost) / ItemManager.RANDM_LIQUID_PER_CHARGE) * 100);
        p.sendActionBar(Component.text("Randm 15k │ ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(strength.getDisplayName() + " │ ", strengthActionColor(strength)))
                .append(Component.text("Akku " + Math.max(0, batteryPct) + "%", batteryActionColor(batteryPct)))
                .append(Component.text(" │ Liquid " + Math.round(liquid - liquidCost) + "/"
                        + (int) ItemManager.RANDM_MAX_LIQUID, NamedTextColor.AQUA)));

        playPuffEffects(p, 1.0);
    }

    /** Eingehender Rechtsklick im Surge-Modus: startet oder verlängert die Hold-Session. */
    private void handleSurgeTick(Player p, ItemManager im, ItemStack hand) {
        UUID id = p.getUniqueId();
        SurgeSession session = surgeSessions.get(id);
        if (session != null) {
            // Session läuft schon -> nur Refresh-Flag setzen (Taste weiter gedrückt)
            session.refreshed = true;
            return;
        }

        double liquid = im.getRandmLiquid(hand);
        double chargeLeft = im.getRandmChargeLeft(hand);
        if (liquid <= 0.0) {
            p.sendMessage(Component.text("Diese Vape ist leer.", NamedTextColor.GRAY));
            im.updateRandmDisplay(hand, ItemManager.RandmState.EMPTY_LIQUID);
            return;
        }
        if (chargeLeft <= 0.0) {
            p.sendMessage(Component.text("Akku leer! Drop sie an einer Redstone-Quelle zum Laden.",
                    NamedTextColor.RED));
            im.updateRandmDisplay(hand, ItemManager.RandmState.EMPTY_BATTERY);
            p.playSound(p.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.6f, 0.8f);
            return;
        }

        SurgeSession s = new SurgeSession();
        surgeSessions.put(id, s);

        s.task = new BukkitRunnable() {
            @Override
            public void run() {
                Player player = plugin.getServer().getPlayer(id);
                if (player == null || !player.isOnline()) {
                    finishSurge(id, null);
                    cancel();
                    return;
                }
                ItemStack mainHand = player.getInventory().getItemInMainHand();
                if (!im.isRandm(mainHand) || im.getRandmStrength(mainHand) != RandmStrength.SURGE) {
                    finishSurge(id, player);
                    cancel();
                    return;
                }

                // Maustaste loslassen erkannt: kein neuer Klick seit SURGE_RELEASE_TICKS
                if (!s.refreshed) {
                    s.ticksSinceLastClick++;
                } else {
                    s.ticksSinceLastClick = 0;
                    s.refreshed = false;
                }

                if (s.ticksSinceLastClick > SURGE_RELEASE_TICKS
                        || s.elapsedTicks >= RandmStrength.SURGE_MAX_HOLD_TICKS) {
                    finishSurge(id, player);
                    cancel();
                    return;
                }

                double liquidNow = im.getRandmLiquid(mainHand);
                double chargeNow = im.getRandmChargeLeft(mainHand);
                if (liquidNow <= 0.0 || chargeNow <= 0.0) {
                    finishSurge(id, player);
                    cancel();
                    return;
                }

                s.elapsedTicks++;

                // Pro Tick anteiliger Verbrauch/Gewinn (Werte sind Pro-Sekunde, /20 Ticks)
                double liquidPerTick = RandmStrength.SURGE_LIQUID_PER_SECOND / 20.0;
                double nicotinePerTick = RandmStrength.SURGE_NICOTINE_PER_SECOND / 20.0;

                double newLiquid = Math.max(0.0, liquidNow - liquidPerTick);
                double newCharge = Math.max(0.0, chargeNow - liquidPerTick);
                im.setRandmLiquidRaw(mainHand, newLiquid);
                im.setRandmChargeLeftRaw(mainHand, newCharge);
                plugin.getNicotineManager().onVapePuffAmount(player, nicotinePerTick);
                im.updateRandmDisplay(mainHand, ItemManager.RandmState.SURGE_CHARGING);

                if (s.elapsedTicks % 5 == 0) {
                    applyRandmPuffVisuals(player, mainHand);
                    player.sendActionBar(Component.text("SURGE ", NamedTextColor.LIGHT_PURPLE)
                            .append(Component.text("│ " + (s.elapsedTicks / 20.0) + "s Zug", NamedTextColor.WHITE)));
                }
                playPuffEffects(player, 0.3);
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void finishSurge(UUID id, Player p) {
        SurgeSession s = surgeSessions.remove(id);
        if (s == null) return;
        if (s.task != null && !s.task.isCancelled()) s.task.cancel();
        if (p != null) {
            ItemManager im = plugin.getItemManager();
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (im.isRandm(hand)) {
                im.updateRandmDisplay(hand, ItemManager.RandmState.IDLE);
            }
            p.sendActionBar(Component.text("Surge-Zug beendet.", NamedTextColor.GRAY));
        }
    }

    /** Fixe Farbpalette für den Farbwechsel-Effekt beim Ziehen. */
    private static final org.bukkit.Color[] PUFF_COLOR_PALETTE = {
            org.bukkit.Color.fromRGB(255, 60, 60),
            org.bukkit.Color.fromRGB(255, 150, 30),
            org.bukkit.Color.fromRGB(255, 230, 40),
            org.bukkit.Color.fromRGB(80, 255, 80),
            org.bukkit.Color.fromRGB(40, 220, 255),
            org.bukkit.Color.fromRGB(90, 90, 255),
            org.bukkit.Color.fromRGB(200, 60, 255),
            org.bukkit.Color.fromRGB(255, 80, 200),
    };

    /**
     * Beim Ziehen wechselt die Randm zufällig die Farbe. Ist es in der Welt des
     * Spielers gerade Nacht, bekommt sie zusätzlich einen magischen Glanz-Effekt
     * (Enchantment-Glint), damit sie im Dunkeln auffällig "leuchtet".
     */
    private void applyRandmPuffVisuals(Player p, ItemStack hand) {
        if (!(hand.getItemMeta() instanceof LeatherArmorMeta lm)) return;

        org.bukkit.Color newColor = PUFF_COLOR_PALETTE[ThreadLocalRandom.current().nextInt(PUFF_COLOR_PALETTE.length)];
        lm.setColor(newColor);
        lm.setEnchantmentGlintOverride(isNightTime(p.getWorld()));

        hand.setItemMeta(lm);
    }

    private boolean isNightTime(World world) {
        long time = world.getTime(); // 0..24000, Nacht ca. 13000-23000
        return time >= 13000 && time < 23000;
    }

    private void playPuffEffects(Player p, double scale) {
        p.swingMainHand();
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.5f, 1.6f);

        org.bukkit.util.Vector dir = p.getLocation().getDirection();
        org.bukkit.Location mouth = p.getEyeLocation().clone().subtract(0, 0.15, 0);
        org.bukkit.Location front = mouth.clone().add(dir.clone().multiply(0.35));

        int burst = Math.max(2, (int) Math.round(8 * scale));
        p.getWorld().spawnParticle(Particle.SMOKE,
                front.getX(), front.getY(), front.getZ(),
                burst, 0.08, 0.08, 0.08, 0.015);
        p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                front.getX(), front.getY(), front.getZ(),
                Math.max(1, (int) Math.round(4 * scale)), 0.1, 0.1, 0.1, 0.02);

        // Bei sehr kleinem Maßstab (Surge: pro Tick aufgerufen) reicht der Sofort-Burst –
        // sonst würden sich pro Sekunde 20x mehrere verzögerte Wellen stapeln.
        if (scale < 0.5) return;

        // Wolke wandert ein Stück nach vorne und steigt leicht auf
        int waves = Math.max(3, (int) Math.round(10 * scale));
        for (int i = 0; i < waves; i++) {
            final int step = i;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!p.isOnline()) return;
                org.bukkit.Location cloud = front.clone()
                        .add(dir.clone().multiply(step * 0.07))
                        .add(0, step * 0.035, 0);
                p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,
                        cloud.getX(), cloud.getY(), cloud.getZ(),
                        Math.max(1, (int) Math.round(2 * scale)), 0.12, 0.12, 0.12, 0.015);
            }, i * 1L);
        }
    }

    private static NamedTextColor strengthActionColor(RandmStrength s) {
        switch (s) {
            case LEICHT: return NamedTextColor.GREEN;
            case NORMAL: return NamedTextColor.YELLOW;
            case STARK:  return NamedTextColor.RED;
            case SURGE:  return NamedTextColor.LIGHT_PURPLE;
            default:     return NamedTextColor.YELLOW;
        }
    }

    private static NamedTextColor batteryActionColor(int v) {
        if (v >= 60) return NamedTextColor.GREEN;
        if (v >= 25) return NamedTextColor.YELLOW;
        if (v > 0)   return NamedTextColor.RED;
        return NamedTextColor.DARK_RED;
    }

    /** Laufzeitdaten einer aktiven Surge-Hold-Session. */
    private static class SurgeSession {
        BukkitTask task;
        int elapsedTicks = 0;
        int ticksSinceLastClick = 0;
        boolean refreshed = true;
    }
}
