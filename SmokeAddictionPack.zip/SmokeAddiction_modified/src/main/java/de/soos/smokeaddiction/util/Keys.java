package de.soos.smokeaddiction.util;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Zentrale Verwaltung aller NamespacedKeys, die in Items, Entities oder Blöcken
 * über den PersistentDataContainer gespeichert werden.
 */
public final class Keys {

    public static NamespacedKey ITEM_TYPE;        // Identifiziert Custom-Item ("cigarette", "pack", "vape", "lighter")
    public static NamespacedKey BRAND;            // Marke der Zigarette / Pack
    public static NamespacedKey PACK_CIGS;        // Verbleibende Zigaretten in einer Schachtel
    public static NamespacedKey VAPE_FLAVOR;      // Sorte/Farbe einer Elfbar
    public static NamespacedKey VAPE_PUFFS;       // Verbleibende Züge einer Vape
    public static NamespacedKey VAPE_BATTERY;     // Akku-Stand (0-100) für Fumot 12k
    public static NamespacedKey ENTITY_PACK;      // Markierung für ArmorStand-Schachtel-Block
    public static NamespacedKey ENTITY_PACK_DATA; // Pack-Inhalt der ArmorStand-Schachtel
    public static NamespacedKey VILLAGE_MARKER;   // Markierung auf einer Glocke: Trader bereits gespawnt
    public static NamespacedKey TRADER_TYPE;      // Markierung auf Villager: "cigarette" oder "vape"
    public static NamespacedKey ENTITY_SHISHA;    // Markierung für ArmorStand-Shisha-Block
    public static NamespacedKey SHISHA_WATER;     // Wasser eingefüllt? (Byte 0/1)
    public static NamespacedKey SHISHA_USES;      // Verbleibende Tabak-Nutzungen (Integer)
    public static NamespacedKey VAPE_TRADER_USES; // Anzahl der erfolgten Trades am Vape-Händler
    public static NamespacedKey ENCH_MUNIS;       // Cig/Joint-Enchant: schnelles Ziehen (Level 1-3)
    public static NamespacedKey ENCH_DURABILITY;  // Vape-Enchant: mehr Züge (Level 1)
    public static NamespacedKey ENCH_MORE_SMOKE;  // Vape-Enchant: extreme Rauchwolken (Level 1)
    public static NamespacedKey PACK_ITEM_LIST;   // Serialisierte Zigaretten-Items (mit Enchants) in einer Schachtel
    public static NamespacedKey VOZOL_CHARGE_LEFT; // Verbleibende Züge im aktuellen Akku-Zyklus (0-150) der Vozol 40k
    public static NamespacedKey ENTITY_VOZOL_CHARGER; // Markierung für ArmorStand: platzierte Vape (Vozol/Randm) auf Redstone-Block
    public static NamespacedKey RANDM_LIQUID;       // Verbleibendes Liquid der Randm 15k (Double, 0-150)
    public static NamespacedKey RANDM_CHARGE_LEFT;  // Verbleibende Akku-Ladung der Randm 15k (Double, 0-50)
    public static NamespacedKey RANDM_STRENGTH;     // Aktuell eingestellte Zugstärke (String: LEICHT/NORMAL/STARK/SURGE)

    private Keys() {}

    public static void init(Plugin plugin) {
        ITEM_TYPE        = new NamespacedKey(plugin, "item_type");
        BRAND            = new NamespacedKey(plugin, "brand");
        PACK_CIGS        = new NamespacedKey(plugin, "pack_cigs");
        VAPE_FLAVOR      = new NamespacedKey(plugin, "vape_flavor");
        VAPE_PUFFS       = new NamespacedKey(plugin, "vape_puffs");
        VAPE_BATTERY     = new NamespacedKey(plugin, "vape_battery");
        ENTITY_PACK      = new NamespacedKey(plugin, "entity_pack");
        ENTITY_PACK_DATA = new NamespacedKey(plugin, "entity_pack_data");
        VILLAGE_MARKER   = new NamespacedKey(plugin, "village_marker");
        TRADER_TYPE      = new NamespacedKey(plugin, "trader_type");
        ENTITY_SHISHA    = new NamespacedKey(plugin, "entity_shisha");
        SHISHA_WATER     = new NamespacedKey(plugin, "shisha_water");
        SHISHA_USES      = new NamespacedKey(plugin, "shisha_uses");
        VAPE_TRADER_USES = new NamespacedKey(plugin, "vape_trader_uses");
        ENCH_MUNIS       = new NamespacedKey(plugin, "ench_munis");
        ENCH_DURABILITY  = new NamespacedKey(plugin, "ench_durability");
        ENCH_MORE_SMOKE  = new NamespacedKey(plugin, "ench_more_smoke");
        PACK_ITEM_LIST   = new NamespacedKey(plugin, "pack_item_list");
        VOZOL_CHARGE_LEFT     = new NamespacedKey(plugin, "vozol_charge_left");
        ENTITY_VOZOL_CHARGER  = new NamespacedKey(plugin, "entity_vozol_charger");
        RANDM_LIQUID          = new NamespacedKey(plugin, "randm_liquid");
        RANDM_CHARGE_LEFT     = new NamespacedKey(plugin, "randm_charge_left");
        RANDM_STRENGTH        = new NamespacedKey(plugin, "randm_strength");
    }
}
