package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.PlayerData;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Verwaltet das Alkohol/Promille-System:
 *  - Eigene BossBar pro Spieler
 *  - Konsum-Logik (Heilung, Hunger, Promille-Erhöhung)
 *  - Negative Effekte ab bestimmten Schwellen (Nausea, Blindness, Slowness, Zombie-Spawns)
 *  - Promille-Decay (-0.1 ‰ alle 60 s, vom AlcoholDecayTask aufgerufen)
 *
 * Schwellen:
 *   1.5 ‰  → Nausea (leichtes Wackeln)
 *   2.5 ‰  → Slowness II + stärkere Nausea + Zombie-Spawn (1-4 alle 10 s, Radius 5)
 *   3.5 ‰  → Blindness zusätzlich
 */
public class AlcoholManager {

    public static final double THRESHOLD_TIPSY  = 1.5;
    public static final double THRESHOLD_DRUNK  = 2.5;
    public static final double THRESHOLD_BLOTTO = 3.5;
    public static final double MAX_PROMILLE     = 6.0;

    public static final double DECAY_PER_MINUTE = 0.1;

    private final SmokeAddictionPlugin plugin;
    private final PlayerDataManager playerDataManager;
    private final Map<UUID, BossBar> bars = new HashMap<>();

    public AlcoholManager(SmokeAddictionPlugin plugin, PlayerDataManager pdm) {
        this.plugin = plugin;
        this.playerDataManager = pdm;
    }

    // ============================================================
    // BossBar
    // ============================================================

    /** Aktualisiert (oder erstellt) die Promille-BossBar für den Spieler. */
    public void updateBossBar(Player player) {
        PlayerData d = playerDataManager.get(player);

        if (d.getBloodAlcohol() <= 0.0) {
            removeBossBar(player);
            return;
        }

        BossBar bar = bars.computeIfAbsent(player.getUniqueId(), k -> {
            BossBar b = BossBar.bossBar(Component.empty(), 0f,
                    BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
            player.showBossBar(b);
            return b;
        });

        float progress = (float) Math.min(1.0, d.getBloodAlcohol() / MAX_PROMILLE);
        bar.progress(progress);

        // Farbe nach Schwelle
        BossBar.Color color;
        if      (d.getBloodAlcohol() >= THRESHOLD_BLOTTO) color = BossBar.Color.RED;
        else if (d.getBloodAlcohol() >= THRESHOLD_DRUNK)  color = BossBar.Color.PINK;
        else if (d.getBloodAlcohol() >= THRESHOLD_TIPSY)  color = BossBar.Color.PURPLE;
        else                                              color = BossBar.Color.YELLOW;
        bar.color(color);

        Component title = Component.text("Promille: ", NamedTextColor.WHITE)
                .append(Component.text(String.format("%.2f \u2030", d.getBloodAlcohol()),
                        promilleColor(d.getBloodAlcohol())));
        if (d.getBloodAlcohol() >= THRESHOLD_BLOTTO) {
            title = title.append(Component.text("  (Lebensgefahr!)", NamedTextColor.DARK_RED));
        } else if (d.getBloodAlcohol() >= THRESHOLD_DRUNK) {
            title = title.append(Component.text("  (Stark betrunken)", NamedTextColor.RED));
        } else if (d.getBloodAlcohol() >= THRESHOLD_TIPSY) {
            title = title.append(Component.text("  (Beschwipst)", NamedTextColor.GOLD));
        }
        bar.name(title);
    }

    private NamedTextColor promilleColor(double p) {
        if (p >= THRESHOLD_BLOTTO) return NamedTextColor.DARK_RED;
        if (p >= THRESHOLD_DRUNK)  return NamedTextColor.RED;
        if (p >= THRESHOLD_TIPSY)  return NamedTextColor.GOLD;
        return NamedTextColor.YELLOW;
    }

    public void removeBossBar(Player player) {
        BossBar bar = bars.remove(player.getUniqueId());
        if (bar != null) player.hideBossBar(bar);
    }

    // ============================================================
    // Konsum
    // ============================================================

    /** Spieler hat Bier konsumiert. */
    public void onBeerConsumed(Player p) {
        consume(p, 0.5, 12.0, 7, "Bier");
    }

    /** Spieler hat Jägermeister konsumiert. */
    public void onJaegerConsumed(Player p) {
        consume(p, 0.2, 8.0, 4, "Kleiner Jägermeister");
    }

    private void consume(Player p, double promilleAdd, double healAmount, int hungerAdd, String drinkName) {
        PlayerData d = playerDataManager.get(p);

        // Heilung (gecappt am MaxHealth)
        try {
            double max = getMaxHealth(p);
            p.setHealth(Math.min(max, p.getHealth() + healAmount));
        } catch (Throwable ex) {
            // Fallback (ältere API)
            double newH = Math.min(20.0, p.getHealth() + healAmount);
            p.setHealth(newH);
        }

        // Hunger
        int newFood = Math.min(20, p.getFoodLevel() + hungerAdd);
        p.setFoodLevel(newFood);
        p.setSaturation(Math.min(20f, p.getSaturation() + hungerAdd / 2f));

        // Promille
        d.setBloodAlcohol(Math.min(MAX_PROMILLE, d.getBloodAlcohol() + promilleAdd));
        d.setLastAlcDecayMillis(System.currentTimeMillis());

        // Sound
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 0.8f, 1.2f);
        p.sendActionBar(Component.text("Du trinkst: " + drinkName, NamedTextColor.GOLD));

        updateBossBar(p);
        applyEffects(p);
    }

    // ============================================================
    // Effekte (Schwellen-basiert)
    // ============================================================

    /**
     * Wendet die Promille-abhängigen Effekte auf den Spieler an.
     * Wird nach jedem Konsum und periodisch vom Decay-Task aufgerufen.
     */
    public void applyEffects(Player p) {
        PlayerData d = playerDataManager.get(p);
        double bac = d.getBloodAlcohol();

        // Ab 1.5 ‰: leichte Nausea (Bildschirm-Wackeln)
        if (bac >= THRESHOLD_TIPSY) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,
                    300, 0, true, false, false));
        }

        // Ab 2.5 ‰: Slowness II + stärkere Nausea (durch häufigeres Refreshen)
        if (bac >= THRESHOLD_DRUNK) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                    300, 1, true, false, false));
            // Nausea bleibt aktiv (oben gesetzt). Ab dieser Schwelle ist sie gefühlt
            // dauerhaft, weil sie kontinuierlich refresht wird.
        }

        // Ab 3.5 ‰: Blindness
        if (bac >= THRESHOLD_BLOTTO) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS,
                    300, 0, true, false, false));
        }
    }

    /** Entfernt alle promille-induzierten Effekte (z.B. wenn nüchtern). */
    public void clearAlcoholEffects(Player p) {
        // Nur entfernen, wenn nicht von anderem System gesetzt – einfach immer entfernen.
        p.removePotionEffect(PotionEffectType.NAUSEA);
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        // SLOWNESS könnte auch von Schock kommen, wir entfernen es nur, wenn der Schock-Effekt
        // nicht mehr aktiv ist (PotionEffect-Duration prüfen wäre zu komplex – sicherer:
        // Slowness löschen, der Schock-Code wird sie 5 s setzen wenn es ihn gerade gibt).
        p.removePotionEffect(PotionEffectType.SLOWNESS);
    }

    // ============================================================
    // Decay (vom AlcoholDecayTask aufgerufen)
    // ============================================================

    /**
     * Tickt den Promille-Abbau für einen Online-Spieler.
     * Rate: -0.1 ‰ pro 60 Sekunden (= -0.001\u2030/600ms in Millisekunden-Auflösung).
     */
    public void tick(Player p) {
        PlayerData d = playerDataManager.get(p);
        if (d.getBloodAlcohol() <= 0.0) return;

        long now = System.currentTimeMillis();
        long elapsed = now - d.getLastAlcDecayMillis();
        if (elapsed <= 0) {
            d.setLastAlcDecayMillis(now);
            return;
        }

        double perMs = DECAY_PER_MINUTE / (60.0 * 1000.0);
        double newBac = d.getBloodAlcohol() - perMs * elapsed;
        d.setLastAlcDecayMillis(now);

        if (newBac <= 0.0) {
            d.setBloodAlcohol(0.0);
            removeBossBar(p);
            clearAlcoholEffects(p);
            p.sendActionBar(Component.text("Du bist wieder nüchtern.", NamedTextColor.GREEN));
        } else {
            d.setBloodAlcohol(newBac);
            updateBossBar(p);
            applyEffects(p);
        }
    }

    // ============================================================
    // Zombie-Spawn (vom DrunkSpawnTask aufgerufen, alle 10s)
    // ============================================================

    /**
     * Liest MaxHealth versionsneutral aus. In neueren Paper-Versionen heißt
     * das Attribut MAX_HEALTH, in älteren GENERIC_MAX_HEALTH. Beide werden
     * via Reflection probiert.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    /**
     * Liest MaxHealth versionsneutral aus. Attribute ist seit der Registry-Umstellung
     * (Paper 1.20.5+) kein Enum mehr, sondern ein Registry-Interface – wir lösen die
     * Konstante deshalb über {@link org.bukkit.Registry#ATTRIBUTE} auf, mit Fallback
     * auf die alte "generic."-Namensform für ältere Server-Versionen.
     */
    private double getMaxHealth(Player p) {
        try {
            org.bukkit.Registry<org.bukkit.attribute.Attribute> registry = org.bukkit.Registry.ATTRIBUTE;
            org.bukkit.attribute.Attribute attr =
                    registry.get(org.bukkit.NamespacedKey.minecraft("max_health"));
            if (attr == null) {
                attr = registry.get(org.bukkit.NamespacedKey.minecraft("generic.max_health"));
            }
            if (attr != null) {
                var instance = p.getAttribute(attr);
                if (instance != null) return instance.getValue();
            }
        } catch (Throwable ignored) {
        }
        return 20.0;
    }

    /**
     * Spawnt 1-4 Zombies im Radius von 5 Blöcken um den Spieler, wenn die Schwelle erreicht ist.
     * Die Zombies greifen den Spieler direkt an und despawnen nach 60 Sekunden automatisch
     * (egal ob noch am Leben).
     */
    public void maybeSpawnZombies(Player p) {
        PlayerData d = playerDataManager.get(p);
        double bac = d.getBloodAlcohol();
        if (bac < THRESHOLD_DRUNK) return; // unter 2.5 ‰: nichts

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int count = 1 + rnd.nextInt(4); // 1..4

        for (int i = 0; i < count; i++) {
            // Zufällige Position im Radius 5 um den Spieler
            double angle = rnd.nextDouble(0, Math.PI * 2);
            double dist  = 3.0 + rnd.nextDouble(0, 2.0); // 3..5 Blöcke
            Location spawn = p.getLocation().clone().add(
                    Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
            // Auf Boden snap'en
            spawn.setY(p.getWorld().getHighestBlockYAt(spawn) + 1);

            Zombie z = (Zombie) p.getWorld().spawnEntity(spawn, EntityType.ZOMBIE);
            z.customName(Component.text("Halluzination", NamedTextColor.DARK_PURPLE));
            z.setCustomNameVisible(false);
            z.setTarget(p);
            z.setRemoveWhenFarAway(true);
            // Nach 60 s automatisch entfernen
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (z.isValid() && !z.isDead()) {
                    z.getWorld().spawnParticle(org.bukkit.Particle.LARGE_SMOKE,
                            z.getLocation().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.02);
                    z.remove();
                }
            }, 20L * 60L);
        }
    }
}
