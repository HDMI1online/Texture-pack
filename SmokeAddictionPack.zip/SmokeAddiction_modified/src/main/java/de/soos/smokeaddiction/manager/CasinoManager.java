package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.CasinoType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Logik der Casino-Slots:
 *   - Spieler öffnet GUI durch Rechtsklick auf Casino-Block
 *   - Im GUI: 3 Reels (Slot 3/4/5), 1 Spin-Button (Slot 7)
 *   - Klick auf Spin: prüft ob Spieler genug Einsatz hat, zieht ab,
 *     animiert Reels für 2 Sekunden mit zufälligen Symbolen
 *   - Endergebnis: 3 gleich = 10x Wert, 2 gleich = 3x Wert, sonst nichts
 *   - Bei DRUGS-Slots ist eine zufällige Vape der Jackpot (3x gleich), Crack
 *     ist dort nicht mehr ergambelbar (Elfbar 70% / Fumot 20% / Randm 5% / Vozol 5%)
 */
public class CasinoManager {

    /** Pro offenem Casino-GUI: welcher Typ und welche Block-Location. */
    private final Map<UUID, ActiveSession> sessions = new HashMap<>();

    /** Verhindert Doppel-Spin durch Spamklicken. */
    private final Map<UUID, Long> lastSpin = new HashMap<>();

    private final SmokeAddictionPlugin plugin;

    public CasinoManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public static class ActiveSession {
        public final CasinoType type;
        public final org.bukkit.Location block;
        public final Inventory inv;
        public boolean spinning = false;
        public ActiveSession(CasinoType t, org.bukkit.Location b, Inventory i) {
            this.type = t; this.block = b; this.inv = i;
        }
    }

    public ActiveSession getSession(Player p) {
        return sessions.get(p.getUniqueId());
    }

    public void openGui(Player p, CasinoType type, org.bukkit.Location block) {
        Inventory inv = plugin.getServer().createInventory(null, 9,
                Component.text(type.displayName, NamedTextColor.GOLD));

        // Filler links und rechts mit farbigem Glas (passend zum Casino-Typ)
        ItemStack filler = new ItemStack(fillerMaterial(type));
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);
        for (int i = 0; i < 9; i++) inv.setItem(i, filler);

        // Reels initial: Fragezeichen
        for (int slot = 3; slot <= 5; slot++) {
            inv.setItem(slot, makeQuestionMark());
        }

        // Spin-Button
        inv.setItem(7, makeSpinButton(type));

        // Info-Item
        inv.setItem(0, makeInfoBook(type));

        ActiveSession session = new ActiveSession(type, block, inv);
        sessions.put(p.getUniqueId(), session);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.4f);
    }

    public void closeSession(Player p) {
        sessions.remove(p.getUniqueId());
    }

    /** Wird vom Listener aufgerufen wenn der Spieler den Spin-Button klickt. */
    public void handleSpin(Player p) {
        ActiveSession s = sessions.get(p.getUniqueId());
        if (s == null) return;
        if (s.spinning) return;

        // Anti-Spam
        long now = System.currentTimeMillis();
        Long last = lastSpin.get(p.getUniqueId());
        if (last != null && now - last < 500) return;
        lastSpin.put(p.getUniqueId(), now);

        // Einsatz prüfen + ziehen
        ItemStack stake = stakeItem(s.type);
        if (!hasItem(p, stake)) {
            p.sendMessage(Component.text("Du brauchst " + stake.getAmount() + "× "
                    + stakeName(s.type) + " als Einsatz.", NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1.0f);
            return;
        }
        removeItem(p, stake);

        s.spinning = true;
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1.0f, 1.6f);

        // 40 Ticks (=2 sek) Animation, danach Auswertung
        ItemStack[] symbols = symbolPool(s.type);
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Final-Reels werden VOR der Animation festgelegt → konsistente Auswertung
        int[] finalIdx = new int[]{
                rnd.nextInt(symbols.length),
                rnd.nextInt(symbols.length),
                rnd.nextInt(symbols.length)
        };

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!sessions.containsKey(p.getUniqueId())) {
                    cancel();
                    return;
                }
                ticks++;
                // Erste 29 Ticks: alle drei Reels rotieren schnell
                // Tick 30: Reel 1 stoppt
                // Tick 35: Reel 2 stoppt
                // Tick 40: Reel 3 stoppt → Auswertung
                if (ticks < 30) {
                    s.inv.setItem(3, symbols[rnd.nextInt(symbols.length)]);
                    s.inv.setItem(4, symbols[rnd.nextInt(symbols.length)]);
                    s.inv.setItem(5, symbols[rnd.nextInt(symbols.length)]);
                    if (ticks % 4 == 0) {
                        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 2.0f);
                    }
                } else if (ticks == 30) {
                    s.inv.setItem(3, symbols[finalIdx[0]]);
                    p.playSound(p.getLocation(), Sound.BLOCK_LEVER_CLICK, 0.8f, 1.0f);
                } else if (ticks < 35) {
                    s.inv.setItem(4, symbols[rnd.nextInt(symbols.length)]);
                    s.inv.setItem(5, symbols[rnd.nextInt(symbols.length)]);
                } else if (ticks == 35) {
                    s.inv.setItem(4, symbols[finalIdx[1]]);
                    p.playSound(p.getLocation(), Sound.BLOCK_LEVER_CLICK, 0.8f, 1.0f);
                } else if (ticks < 40) {
                    s.inv.setItem(5, symbols[rnd.nextInt(symbols.length)]);
                } else {
                    s.inv.setItem(5, symbols[finalIdx[2]]);
                    p.playSound(p.getLocation(), Sound.BLOCK_LEVER_CLICK, 0.8f, 1.0f);
                    cancel();
                    // Auswertung im nächsten Tick
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        evaluate(p, s, finalIdx, symbols);
                        s.spinning = false;
                    }, 10L);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void evaluate(Player p, ActiveSession s, int[] idx, ItemStack[] symbols) {
        boolean allSame = idx[0] == idx[1] && idx[1] == idx[2];
        boolean twoSame = !allSame && (idx[0] == idx[1] || idx[1] == idx[2] || idx[0] == idx[2]);

        // Welches Symbol wurde getroffen?
        int matchIdx = -1;
        if (allSame) matchIdx = idx[0];
        else if (twoSame) {
            if (idx[0] == idx[1]) matchIdx = idx[0];
            else if (idx[1] == idx[2]) matchIdx = idx[1];
            else matchIdx = idx[0]; // idx[0]==idx[2]
        }

        if (matchIdx == -1) {
            // Verloren
            p.sendMessage(Component.text("Verloren! Probier's nochmal.", NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.7f);
            return;
        }

        ItemStack matchSymbol = symbols[matchIdx];
        int multiplier = allSame ? 10 : 3;
        de.soos.smokeaddiction.manager.ItemManager im = plugin.getItemManager();

        if (im.isVape(matchSymbol)) {
            // Vapes haben maxStackSize=1 (eigener Akku/Züge-Zustand pro Item) – darum
            // bei Multiplikator mehrere EINZELNE Vapes statt eines aufgeblähten Stacks.
            for (int i = 0; i < multiplier; i++) {
                ItemStack single = matchSymbol.clone();
                single.setAmount(1);
                Map<Integer, ItemStack> overflow = p.getInventory().addItem(single);
                for (ItemStack o : overflow.values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), o);
                }
            }
            if (allSame) {
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                p.sendMessage(Component.text("✦ JACKPOT! ✦  ", NamedTextColor.GOLD)
                        .append(Component.text(multiplier + "× " + symbolName(matchSymbol) + "!",
                                NamedTextColor.YELLOW)));
                p.getWorld().spawnParticle(org.bukkit.Particle.FIREWORK,
                        p.getLocation().add(0, 1, 0), 60, 0.5, 0.5, 0.5, 0.1);
            } else {
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
                p.sendMessage(Component.text("Gewonnen! 2× " + symbolName(matchSymbol)
                        + " → " + multiplier + "× ausgezahlt.", NamedTextColor.GREEN));
            }
            return;
        }

        // Gewinn: gleiches Symbol-Material in entsprechender Menge
        ItemStack prize = matchSymbol.clone();
        prize.setAmount(Math.max(1, prize.getAmount() * multiplier));

        // Sub-Cap: Verhindert dass z.B. 10x ein gestapelter Stack > 64 wird
        if (prize.getAmount() > 64) prize.setAmount(64);

        // Auf Spieler übergeben (Inventar oder droppen)
        Map<Integer, ItemStack> overflow = p.getInventory().addItem(prize);
        for (ItemStack o : overflow.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), o);
        }

        if (allSame) {
            // Jackpot-Sound
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            p.sendMessage(Component.text("✦ JACKPOT! ✦  ", NamedTextColor.GOLD)
                    .append(Component.text("3× " + symbolName(matchSymbol) + "!",
                            NamedTextColor.YELLOW)));
            p.getWorld().spawnParticle(org.bukkit.Particle.FIREWORK,
                    p.getLocation().add(0, 1, 0), 60, 0.5, 0.5, 0.5, 0.1);
        } else {
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
            p.sendMessage(Component.text("Gewonnen! 2× " + symbolName(matchSymbol)
                    + " → " + prize.getAmount() + "× ausgezahlt.",
                    NamedTextColor.GREEN));
        }
    }

    // ============================================================
    // Symbol-Pools pro Casino-Typ
    // ============================================================
    private ItemStack[] symbolPool(CasinoType type) {
        switch (type) {
            case BRONZE:
                return new ItemStack[]{
                        new ItemStack(Material.IRON_INGOT, 1),
                        new ItemStack(Material.GOLD_INGOT, 1),
                        new ItemStack(Material.DIAMOND, 1),
                        new ItemStack(Material.COAL, 2),
                        new ItemStack(Material.RAW_COPPER, 2),
                };
            case SILVER:
                return new ItemStack[]{
                        new ItemStack(Material.GOLD_INGOT, 1),
                        new ItemStack(Material.DIAMOND, 1),
                        new ItemStack(Material.EMERALD, 1),
                        new ItemStack(Material.LAPIS_LAZULI, 3),
                        new ItemStack(Material.IRON_INGOT, 2),
                };
            case GOLD:
                return new ItemStack[]{
                        new ItemStack(Material.DIAMOND, 1),
                        new ItemStack(Material.EMERALD, 2),
                        new ItemStack(Material.NETHERITE_SCRAP, 1),
                        new ItemStack(Material.GOLD_INGOT, 3),
                        new ItemStack(Material.AMETHYST_SHARD, 2),
                };
            case DRUGS:
                // Vorheriger Jackpot war Crack — jetzt eine zufällige Vape:
                //   Elfbar 70% / Fumot 12k 20% / Randm 15k 5% / Vozol 40k 5%
                // (Nutzer wollte 60/20/5/5 = 90%; die fehlenden 10% wandern der
                // Einfachheit halber zur Elfbar, damit die Summe exakt 100% ergibt.)
                de.soos.smokeaddiction.manager.ItemManager im = plugin.getItemManager();
                return new ItemStack[]{
                        im.createMagikzucker(1),       // Kokain
                        im.createTablette(1),          // LSD
                        im.createLeaf(1),               // Leaf
                        new ItemStack(Material.PAPER, 2),
                        randomDrugVape(im),             // Vape – Jackpot wenn 3x getroffen
                };
            case DRINK:
                return new ItemStack[]{
                        plugin.getItemManager().createBeer(1),
                        plugin.getItemManager().createJaeger(1),
                        plugin.getItemManager().createMonsterWhite(1),
                        new ItemStack(Material.WHEAT, 4),
                        new ItemStack(Material.SUGAR_CANE, 4),
                };
        }
        return new ItemStack[0];
    }

    /** Was kostet ein Spin? */
    public ItemStack stakeItem(CasinoType type) {
        switch (type) {
            case BRONZE: return new ItemStack(Material.IRON_INGOT, 1);
            case SILVER: return new ItemStack(Material.GOLD_INGOT, 1);
            case GOLD:   return new ItemStack(Material.DIAMOND, 1);
            case DRUGS:  return plugin.getItemManager().createMagikzucker(1);
            case DRINK:  return plugin.getItemManager().createBeer(1);
        }
        return new ItemStack(Material.AIR);
    }

    /**
     * Zufällige Vape für den Drogenautomat-Jackpot:
     * Elfbar 70% / Fumot 12k 20% / Randm 15k 5% / Vozol 40k 5%.
     */
    private ItemStack randomDrugVape(de.soos.smokeaddiction.manager.ItemManager im) {
        double roll = ThreadLocalRandom.current().nextDouble() * 100.0;
        if (roll < 70.0) {
            de.soos.smokeaddiction.model.VapeFlavor[] basic = {
                    de.soos.smokeaddiction.model.VapeFlavor.BLUE_RAZZ,
                    de.soos.smokeaddiction.model.VapeFlavor.WATERMELON,
                    de.soos.smokeaddiction.model.VapeFlavor.MANGO_ICE,
                    de.soos.smokeaddiction.model.VapeFlavor.GRAPE,
                    de.soos.smokeaddiction.model.VapeFlavor.APPLE_PEACH,
                    de.soos.smokeaddiction.model.VapeFlavor.COTTON_CANDY,
                    de.soos.smokeaddiction.model.VapeFlavor.MENTHOL,
            };
            return im.createVape(basic[ThreadLocalRandom.current().nextInt(basic.length)], 60);
        } else if (roll < 90.0) {
            return im.createFumot();
        } else if (roll < 95.0) {
            de.soos.smokeaddiction.model.VapeFlavor[] randmFlavors =
                    de.soos.smokeaddiction.model.VapeFlavor.randmFlavors();
            return im.createRandm(randmFlavors[ThreadLocalRandom.current().nextInt(randmFlavors.length)]);
        } else {
            return im.createVozol();
        }
    }

    private String stakeName(CasinoType type) {
        switch (type) {
            case BRONZE: return "Iron Ingot";
            case SILVER: return "Gold Ingot";
            case GOLD:   return "Diamant";
            case DRUGS:  return "Kokain";
            case DRINK:  return "Bier";
        }
        return "?";
    }

    private boolean hasItem(Player p, ItemStack required) {
        int needed = required.getAmount();
        for (ItemStack item : p.getInventory().getContents()) {
            if (item == null) continue;
            if (item.isSimilar(required)) needed -= item.getAmount();
            if (needed <= 0) return true;
        }
        return false;
    }

    private void removeItem(Player p, ItemStack required) {
        int toRemove = required.getAmount();
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length && toRemove > 0; i++) {
            ItemStack item = contents[i];
            if (item == null) continue;
            if (!item.isSimilar(required)) continue;
            int take = Math.min(toRemove, item.getAmount());
            item.setAmount(item.getAmount() - take);
            if (item.getAmount() <= 0) contents[i] = null;
            else contents[i] = item;
            toRemove -= take;
        }
        p.getInventory().setContents(contents);
    }

    // ============================================================
    // Display-Helpers
    // ============================================================
    private Material fillerMaterial(CasinoType t) {
        switch (t) {
            case BRONZE: return Material.ORANGE_STAINED_GLASS_PANE;
            case SILVER: return Material.LIGHT_GRAY_STAINED_GLASS_PANE;
            case GOLD:   return Material.YELLOW_STAINED_GLASS_PANE;
            case DRUGS:  return Material.PURPLE_STAINED_GLASS_PANE;
            case DRINK:  return Material.BROWN_STAINED_GLASS_PANE;
        }
        return Material.GRAY_STAINED_GLASS_PANE;
    }

    private ItemStack makeQuestionMark() {
        ItemStack q = new ItemStack(Material.PAPER);
        ItemMeta m = q.getItemMeta();
        m.displayName(Component.text("?", NamedTextColor.WHITE)
                .decoration(TextDecoration.BOLD, true));
        q.setItemMeta(m);
        return q;
    }

    private ItemStack makeSpinButton(CasinoType type) {
        ItemStack btn = new ItemStack(Material.LIME_CONCRETE);
        ItemMeta m = btn.getItemMeta();
        m.displayName(Component.text("► SPIN ◄", NamedTextColor.GREEN)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Einsatz: " + stakeItem(type).getAmount() + "× " + stakeName(type),
                NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("3 gleich  →  10× Gewinn", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("2 gleich  →  3× Gewinn", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sonst    →  nichts", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(lore);
        m.getPersistentDataContainer().set(
                new org.bukkit.NamespacedKey(plugin, "casino_spin"),
                org.bukkit.persistence.PersistentDataType.BYTE, (byte) 1);
        btn.setItemMeta(m);
        return btn;
    }

    private ItemStack makeInfoBook(CasinoType type) {
        ItemStack book = new ItemStack(Material.BOOK);
        ItemMeta m = book.getItemMeta();
        m.displayName(Component.text(type.displayName, NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        ItemStack[] pool = symbolPool(type);
        lore.add(Component.text("Symbole im Reel:", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        for (ItemStack s : pool) {
            lore.add(Component.text("• " + symbolName(s), NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
        }
        m.lore(lore);
        book.setItemMeta(m);
        return book;
    }

    private String symbolName(ItemStack s) {
        if (s.hasItemMeta() && s.getItemMeta().hasDisplayName()) {
            return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                    .plainText().serialize(s.getItemMeta().displayName());
        }
        return s.getType().toString().toLowerCase().replace('_', ' ');
    }
}
