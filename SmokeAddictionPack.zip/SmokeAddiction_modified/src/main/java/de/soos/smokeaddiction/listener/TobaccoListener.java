package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Biome;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.entity.Fox;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Tabak-System:
 *  - Naturspawn von Sweet-Berry-Bushes als "Tabakpflanzen" in warmen, feuchten Biomen
 *    bei Chunk-Generierung.
 *  - Pflanzen mit Tabaksamen auf Gras/Erde/Mud (nur in Tabak-Biomen).
 *  - Ernten reifer Pflanzen (Stage 3) -> Tabakblätter + ggf. Samen.
 *  - Brechen -> Samen + bei reifer Pflanze auch Blätter.
 *
 * Die Vanilla-Random-Tick-Mechanik des Sweet-Berry-Bushes übernimmt das
 * eigentliche Wachstum (Stage 0 -> 3) automatisch.
 */
public class TobaccoListener implements Listener {

    /** Biome, in denen Tabak natürlich vorkommt (Naturspawn). */
    public static final Set<Biome> TOBACCO_BIOMES = new java.util.HashSet<>(java.util.Arrays.asList(
            Biome.JUNGLE, Biome.SPARSE_JUNGLE, Biome.BAMBOO_JUNGLE,
            Biome.SWAMP, Biome.MANGROVE_SWAMP
    ));

    /** Sonnige Biome – hier kann Heilkraut natürlich entstehen. */
    public static final Set<Biome> HERB_BIOMES = new java.util.HashSet<>(java.util.Arrays.asList(
            Biome.PLAINS, Biome.SUNFLOWER_PLAINS,
            Biome.SAVANNA, Biome.SAVANNA_PLATEAU, Biome.WINDSWEPT_SAVANNA,
            Biome.MEADOW, Biome.BEACH, Biome.DESERT
    ));

    /** Biome, in denen Sweet-Berry-Bushes vanilla wachsen – dort verhält sich der Block normal. */
    public static final Set<Biome> VANILLA_BERRY_BIOMES = new java.util.HashSet<>(java.util.Arrays.asList(
            Biome.TAIGA, Biome.OLD_GROWTH_PINE_TAIGA, Biome.OLD_GROWTH_SPRUCE_TAIGA,
            Biome.SNOWY_TAIGA, Biome.GROVE
    ));

    private static final double CHUNK_SPAWN_CHANCE_TOBACCO  = 0.03125; // 1/8 von 0.25
    private static final double CHUNK_SPAWN_CHANCE_CANNABIS = 0.015625; // 1/16 von 0.25 (halb so häufig wie Tabak)

    private final SmokeAddictionPlugin plugin;

    public TobaccoListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    public static boolean isTobaccoBiome(Biome b) {
        return TOBACCO_BIOMES.contains(b);
    }

    public static boolean isHerbBiome(Biome b) {
        return HERB_BIOMES.contains(b);
    }

    public static boolean isVanillaBerryBiome(Biome b) {
        return VANILLA_BERRY_BIOMES.contains(b);
    }

    // === Anpflanzen ===

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlant(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean isTobaccoSeed = plugin.getItemManager().isTobaccoSeeds(hand);
        boolean isHerbSeed    = plugin.getItemManager().isHerbSeeds(hand);
        if (!isTobaccoSeed && !isHerbSeed) return;

        Block clicked = e.getClickedBlock();
        if (clicked == null) return;

        // Pflanzbarer Untergrund?
        Material m = clicked.getType();
        if (m != Material.GRASS_BLOCK && m != Material.DIRT
                && m != Material.PODZOL && m != Material.COARSE_DIRT
                && m != Material.MUD && m != Material.ROOTED_DIRT) {
            return;
        }

        Block above = clicked.getRelative(BlockFace.UP);
        if (above.getType() != Material.AIR) return;

        // Anbau ist überall erlaubt - keine Biom-Beschränkung
        e.setCancelled(true);

        // Sweet Berry Bush als Stage 0 platzieren
        above.setType(Material.SWEET_BERRY_BUSH);
        BlockData bd = above.getBlockData();
        if (bd instanceof Ageable a) {
            a.setAge(0);
            above.setBlockData(a);
        }

        // Bei Herb-Samen: Location registrieren
        if (isHerbSeed) {
            plugin.getHerbBushRegistry().register(above);
        }

        // Item abziehen
        if (p.getGameMode() != GameMode.CREATIVE) {
            int amt = hand.getAmount();
            if (amt <= 1) p.getInventory().setItemInMainHand(null);
            else hand.setAmount(amt - 1);
        }
        p.playSound(above.getLocation(), Sound.BLOCK_GRASS_PLACE, 1f, 1f);
    }

    // === Ernten (Rechtsklick auf reife Pflanze) ===

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHarvest(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.SWEET_BERRY_BUSH) return;
        // Vanilla-Sweet-Berries in Taiga sollen vanilla-mäßig funktionieren – wir
        // behandeln den Bush nur dann als Tabak, wenn er entweder im Tabak-Biom steht
        // ODER im Stage-Marker auffällt. Da wir aber keinen Marker pro Bush haben,
        // gilt die Regel: außerhalb von Taiga (= dort wo Vanilla-Beeren wachsen)
        // ist jeder Sweet-Berry-Bush ein Tabak-Bush.
        if (isVanillaBerryBiome(b.getBiome())) return;

        BlockData bd = b.getBlockData();
        if (!(bd instanceof Ageable a)) return;
        if (a.getAge() < 3) return; // noch nicht reif

        e.setCancelled(true);
        // Vanilla-Beeren-Pick gehört zum useInteractedBlock-Subevent.
        // Wir setzen es explizit auf DENY, damit auf keinen Fall Sweet Berries droppen.
        e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
        e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);

        Player p = e.getPlayer();
        Random rnd = ThreadLocalRandom.current();
        boolean isHerb = plugin.getHerbBushRegistry().isHerb(b);
        int leaves = 1 + rnd.nextInt(3); // 1..3
        if (isHerb) {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                    plugin.getItemManager().createHerbRaw(leaves));
            if (rnd.nextDouble() < 0.5) {
                b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                        plugin.getItemManager().createHerbSeeds(1));
            }
        } else {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                    plugin.getItemManager().createTobaccoRaw(leaves));
            if (rnd.nextDouble() < 0.5) {
                b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                        plugin.getItemManager().createTobaccoSeeds(1));
            }
        }

        // Pflanze geht zurück auf Stage 1 (wie bei Sweet Berries)
        a.setAge(1);
        b.setBlockData(a);
        try {
            p.playSound(b.getLocation(), Sound.BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, 1f, 1f);
        } catch (Throwable ignored) { /* sound name könnte zwischen versionen leicht abweichen */ }
    }

    // === Brechen ===

    /** Verhindert Vanilla-Berry-Drop wenn unser Bush "geerntet" wird (z.B. mit Knochenmehl). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHarvest(org.bukkit.event.player.PlayerHarvestBlockEvent e) {
        Block b = e.getHarvestedBlock();
        if (b.getType() != Material.SWEET_BERRY_BUSH) return;
        if (isVanillaBerryBiome(b.getBiome())) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SWEET_BERRY_BUSH) return;
        // Vanilla-Beeren-Biome (Taiga etc.) bleiben vanilla
        if (isVanillaBerryBiome(b.getBiome())) return;

        e.setDropItems(false);

        BlockData bd = b.getBlockData();
        int age = (bd instanceof Ageable a) ? a.getAge() : 0;
        Random rnd = ThreadLocalRandom.current();
        boolean isHerb = plugin.getHerbBushRegistry().isHerb(b);

        if (isHerb) {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                    plugin.getItemManager().createHerbSeeds(1 + rnd.nextInt(2)));
            if (age >= 2) {
                int leaves = (age == 3) ? (1 + rnd.nextInt(2)) : 1;
                b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                        plugin.getItemManager().createHerbRaw(leaves));
            }
            plugin.getHerbBushRegistry().unregister(b);
        } else {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                    plugin.getItemManager().createTobaccoSeeds(1 + rnd.nextInt(2)));
            if (age >= 2) {
                int leaves = (age == 3) ? (1 + rnd.nextInt(2)) : 1;
                b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                        plugin.getItemManager().createTobaccoRaw(leaves));
            }
        }
    }

    // === Naturspawn bei neuen Chunks ===

    // ============================================================
    // Natürlicher Spawn via Timer (nicht nur neue Chunks)
    // ============================================================

    /**
     * Wird vom SmokeAddictionPlugin jede Minute aufgerufen.
     * Prüft geladene Chunks und spawnt zufällig Tabak/Cannabis-Patches.
     */
    public void tickNaturalSpawn() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (World w : plugin.getServer().getWorlds()) {
            if (w.getEnvironment() != World.Environment.NORMAL) continue;
            Chunk[] loaded = w.getLoadedChunks();
            if (loaded.length == 0) continue;
            int checks = Math.min(8, loaded.length);
            plugin.getDebugManager().log(String.format("[TIMER] Tick: prüfe %d/%d Chunks in '%s'",
                    checks, loaded.length, w.getName()));
            for (int i = 0; i < checks; i++) {
                Chunk c = loaded[rnd.nextInt(loaded.length)];
                if (rnd.nextDouble() > 0.04) {
                    plugin.getDebugManager().log(String.format("[TIMER] SKIP Chunk [%d,%d] (globale Chance verpasst)",
                            c.getX(), c.getZ()));
                    continue;
                }
                trySpawnInChunk(c, w, rnd, "TIMER");
            }
        }
    }

    private void trySpawnInChunk(Chunk c, World w, ThreadLocalRandom rnd) {
        trySpawnInChunk(c, w, rnd, "TIMER");
    }

    private void trySpawnInChunk(Chunk c, World w, ThreadLocalRandom rnd, String source) {
        int cx = c.getX() * 16 + rnd.nextInt(16);
        int cz = c.getZ() * 16 + rnd.nextInt(16);
        org.bukkit.block.Biome biome = w.getBiome(cx, 64, cz);

        de.soos.smokeaddiction.manager.DebugManager dbg = plugin.getDebugManager();

        if (isTobaccoBiome(biome)) {
            if (rnd.nextDouble() < CHUNK_SPAWN_CHANCE_TOBACCO) {
                spawnTobaccoPatch(c, w, rnd);
                dbg.log(String.format("[%s] SPAWN Tabak | Chunk [%d,%d] | Biom: %s",
                        source, c.getX(), c.getZ(), biome.name()));
            } else {
                dbg.log(String.format("[%s] SKIP  Tabak (Chance) | Chunk [%d,%d] | Biom: %s",
                        source, c.getX(), c.getZ(), biome.name()));
            }
        } else if (isHerbBiome(biome)) {
            if (rnd.nextDouble() < CHUNK_SPAWN_CHANCE_CANNABIS) {
                spawnHerbPatch(c, w, rnd);
                dbg.log(String.format("[%s] SPAWN Cannabis | Chunk [%d,%d] | Biom: %s",
                        source, c.getX(), c.getZ(), biome.name()));
            } else {
                dbg.log(String.format("[%s] SKIP  Cannabis (Chance) | Chunk [%d,%d] | Biom: %s",
                        source, c.getX(), c.getZ(), biome.name()));
            }
        } else {
            dbg.log(String.format("[%s] SKIP  kein passendes Biom | Chunk [%d,%d] | Biom: %s",
                    source, c.getX(), c.getZ(), biome.name()));
        }
    }

    // Alte ChunkLoad-Methode für Kompatibilität behalten (neu generierte Chunks)
    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        if (!e.isNewChunk()) return;
        Chunk c = e.getChunk();
        World w = c.getWorld();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        plugin.getDebugManager().log(String.format("[CHUNK-LOAD] Neuer Chunk [%d,%d] in '%s' → prüfe Spawn",
                c.getX(), c.getZ(), w.getName()));
        trySpawnInChunk(c, w, rnd, "CHUNK-LOAD");
    }


    // ============================================================
    // Fuchs-Schutz: Füchse dürfen Tabak- und Herb-Bushes NICHT abernten
    // ============================================================

    /**
     * Verhindert, dass Füchse Sweet-Berry-Bushes verändern, die Tabak oder Herb sind.
     * In Vanilla-Berry-Biomen (Taiga etc.) wird das Event NICHT gecancelt.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFoxChangeBlock(EntityChangeBlockEvent e) {
        if (!(e.getEntity() instanceof Fox)) return;
        Block b = e.getBlock();
        if (b.getType() != Material.SWEET_BERRY_BUSH) return;

        // Vanilla-Berry-Biom -> normal lassen
        if (isVanillaBerryBiome(b.getBiome())) return;

        // Nur registrierte Bushes schützen (vom Spieler gepflanzte bleiben vanilla)
        if (!plugin.getHerbBushRegistry().isHerb(b)
                && !plugin.getTobaccoBushRegistry().isTobacco(b)) return;

        e.setCancelled(true);
    }

    /**
     * Verhindert, dass Füchse registrierte Tabak- oder Herb-Bushes betreten.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFoxInteract(EntityInteractEvent e) {
        if (!(e.getEntity() instanceof Fox)) return;
        Block b = e.getBlock();
        if (b.getType() != Material.SWEET_BERRY_BUSH) return;

        if (isVanillaBerryBiome(b.getBiome())) return;
        if (!plugin.getHerbBushRegistry().isHerb(b)
                && !plugin.getTobaccoBushRegistry().isTobacco(b)) return;

        e.setCancelled(true);
    }

    // ============================================================
    // Sweet Berry in Herb-Biom → Cannabis beim Abbauen
    // ============================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreakSweetBerry(org.bukkit.event.block.BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SWEET_BERRY_BUSH) return;

        // Nur registrierte Herb/Tobacco-Bushes umwandeln — vom Spieler gepflanzte bleiben vanilla
        boolean isHerbBush    = plugin.getHerbBushRegistry().isHerb(b);
        boolean isTobaccoBush = plugin.getTobaccoBushRegistry().isTobacco(b);
        if (!isHerbBush && !isTobaccoBush) return;

        org.bukkit.block.data.Ageable ageable = (org.bukkit.block.data.Ageable) b.getBlockData();
        e.setDropItems(false);

        ItemStack drop;
        if (isHerbBush) {
            // Cannabis: voll → getrocknet, sonst roh
            drop = ageable.getAge() >= 3
                    ? plugin.getItemManager().createHerbDried(1)
                    : plugin.getItemManager().createHerbRaw(1);
        } else {
            // Tabak: voll → getrockneter Tabak, sonst roher Tabak
            drop = ageable.getAge() >= 3
                    ? plugin.getItemManager().createTobaccoDried(1)
                    : plugin.getItemManager().createTobaccoRaw(1);
        }
        plugin.getHerbBushRegistry().unregister(b);
        plugin.getTobaccoBushRegistry().unregister(b);
        b.setType(Material.AIR, false);
        b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), drop);
    }

    // ============================================================
    // Spawn-Methoden für Tabak und Cannabis
    // ============================================================

    private static final int PATCH_SIZE_MIN = 3;
    private static final int PATCH_SIZE_MAX = 7;

    private void spawnTobaccoPatch(Chunk c, World w, ThreadLocalRandom rnd) {
        int count = rnd.nextInt(PATCH_SIZE_MAX - PATCH_SIZE_MIN + 1) + PATCH_SIZE_MIN;
        for (int i = 0; i < count; i++) {
            int x = c.getX() * 16 + rnd.nextInt(16);
            int z = c.getZ() * 16 + rnd.nextInt(16);
            int y = w.getHighestBlockYAt(x, z);
            Block ground = w.getBlockAt(x, y, z);
            Block above  = w.getBlockAt(x, y + 1, z);
            if (!isPlantableGround(ground.getType())) continue;
            if (above.getType() != Material.AIR) continue;
            above.setType(Material.SWEET_BERRY_BUSH, false);
            // Zufälliges Wachstumsstadium
            org.bukkit.block.data.Ageable age =
                    (org.bukkit.block.data.Ageable) above.getBlockData();
            age.setAge(rnd.nextInt(age.getMaximumAge() + 1));
            above.setBlockData(age, false);
            plugin.getTobaccoBushRegistry().register(above);
        }
    }

    private void spawnHerbPatch(Chunk c, World w, ThreadLocalRandom rnd) {
        int count = rnd.nextInt(PATCH_SIZE_MAX - PATCH_SIZE_MIN + 1) + PATCH_SIZE_MIN;
        for (int i = 0; i < count; i++) {
            int x = c.getX() * 16 + rnd.nextInt(16);
            int z = c.getZ() * 16 + rnd.nextInt(16);
            int y = w.getHighestBlockYAt(x, z);
            Block ground = w.getBlockAt(x, y, z);
            Block above  = w.getBlockAt(x, y + 1, z);
            if (!isPlantableGround(ground.getType())) continue;
            if (above.getType() != Material.AIR) continue;
            above.setType(Material.SWEET_BERRY_BUSH, false);
            org.bukkit.block.data.Ageable age =
                    (org.bukkit.block.data.Ageable) above.getBlockData();
            age.setAge(rnd.nextInt(age.getMaximumAge() + 1));
            above.setBlockData(age, false);
            plugin.getHerbBushRegistry().register(above);
        }
    }

    /**
     * Gibt zurück, ob ein Material als Pflanzboden für Tabak/Cannabis gilt.
     */
    private boolean isPlantableGround(Material m) {
        return m == Material.GRASS_BLOCK || m == Material.DIRT
                || m == Material.PODZOL || m == Material.COARSE_DIRT
                || m == Material.MUD || m == Material.ROOTED_DIRT;
    }
}
