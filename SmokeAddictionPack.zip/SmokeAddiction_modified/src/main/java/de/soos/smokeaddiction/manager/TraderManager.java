package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.model.CigaretteBrand;
import de.soos.smokeaddiction.model.VapeFlavor;
import de.soos.smokeaddiction.util.Keys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Erstellt und verwaltet die zwei Dorf-Händler:
 *  - Zigaretten-Verkäufer (verkauft Tabak und Schachteln)
 *  - Vape-Verkäufer (verkauft Elfbars in beliebigen Sorten)
 *
 * Trader sind normale Villager mit angepassten MerchantRecipes und
 * werden über den PersistentDataContainer markiert (Keys.TRADER_TYPE).
 *
 * Preisspannen:
 *   - 5 Tabakblätter      = 10 Smaragde
 *   - 1 Schachtel (vol.)  = zufällig 16..29 Smaragde, jede Marke
 *   - 1 Elfbar            = zufällig 16..24 Smaragde, jede Sorte
 */
public class TraderManager {

    public static final String TYPE_CIG_SELLER      = "cigarette_seller";
    public static final String TYPE_VAPE_SELLER     = "vape_seller";
    public static final String TYPE_BEVERAGE_SELLER = "beverage_seller";
    public static final String TYPE_ARMORER         = "armorer";
    public static final String TYPE_WEAPONSMITH     = "weaponsmith";
    public static final String TYPE_TRIM_SELLER     = "trim_seller";
    public static final String TYPE_FIREWORK_SELLER = "firework_seller";
    public static final String TYPE_UNEMPLOYED      = "unemployed";
    /** Vape-Händler (City) – levelbar; nach genug Trades wird Fumot freigeschaltet. */
    public static final String TYPE_VAPE_TRADER     = "vape_trader";

    public static final int PACK_PRICE_MIN  = 16;
    public static final int PACK_PRICE_MAX  = 29;
    public static final int VAPE_PRICE_MIN  = 16;
    public static final int VAPE_PRICE_MAX  = 24;

    public static final int BEER_PRICE_MIN   = 3;
    public static final int BEER_PRICE_MAX   = 6;
    public static final int JAEGER_PRICE_MIN = 2;
    public static final int JAEGER_PRICE_MAX = 4;

    private final SmokeAddictionPlugin plugin;

    public TraderManager(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    /** Prüft ob eine VapeFlavor zur Randm-15k-Reihe gehört (eigene Akku-Logik, kein generisches Elfbar). */
    private static boolean isRandmFlavor(VapeFlavor flavor) {
        return flavor == VapeFlavor.RANDM_PEACH_ICE
                || flavor == VapeFlavor.RANDM_PINK_LEMONADE
                || flavor == VapeFlavor.RANDM_STRAWBERRY_KIWI
                || flavor == VapeFlavor.RANDM_WILD_BERRY_CHERRY;
    }

    public boolean isTrader(Entity e) {
        if (!(e instanceof Villager)) return false;
        return e.getPersistentDataContainer().has(Keys.TRADER_TYPE, PersistentDataType.STRING);
    }

    public String getTraderType(Entity e) {
        return e.getPersistentDataContainer().get(Keys.TRADER_TYPE, PersistentDataType.STRING);
    }

    /** Spawnt einen Zigaretten-Verkäufer an der angegebenen Location. */
    public Villager spawnCigaretteSeller(Location loc) {
        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        v.setProfession(Villager.Profession.FARMER);
        v.setVillagerType(Villager.Type.PLAINS);
        v.setVillagerLevel(5);
        v.setVillagerExperience(250);
        v.customName(Component.text("Zigaretten-Verkäufer", NamedTextColor.GOLD));
        v.setCustomNameVisible(true);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(true);
        v.setAI(true);
        v.setInvulnerable(true);
        v.getPersistentDataContainer().set(Keys.TRADER_TYPE, PersistentDataType.STRING, TYPE_CIG_SELLER);

        v.setRecipes(buildCigaretteRecipes());
        return v;
    }

    /** Spawnt einen Vape-Verkäufer an der angegebenen Location. */
    public Villager spawnVapeSeller(Location loc) {
        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        v.setProfession(Villager.Profession.CLERIC);
        v.setVillagerType(Villager.Type.PLAINS);
        v.setVillagerLevel(5);
        v.setVillagerExperience(250);
        v.customName(Component.text("Vape-Verkäufer", NamedTextColor.LIGHT_PURPLE));
        v.setCustomNameVisible(true);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(true);
        v.setAI(true);
        v.setInvulnerable(true);
        v.getPersistentDataContainer().set(Keys.TRADER_TYPE, PersistentDataType.STRING, TYPE_VAPE_SELLER);

        v.setRecipes(buildVapeRecipes());
        return v;
    }

    /** Spawnt einen Getränke-Verkäufer (Bier + Jägermeister) an der angegebenen Location. */
    public Villager spawnBeverageSeller(Location loc) {
        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        // Butcher passt thematisch (Wirt/Schenke); Type SAVANNA/PLAINS reicht
        v.setProfession(Villager.Profession.BUTCHER);
        v.setVillagerType(Villager.Type.PLAINS);
        v.setVillagerLevel(5);
        v.setVillagerExperience(250);
        v.customName(Component.text("Getränke-Verkäufer", NamedTextColor.YELLOW));
        v.setCustomNameVisible(true);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(true);
        v.setAI(true);
        v.setInvulnerable(true);
        v.getPersistentDataContainer().set(Keys.TRADER_TYPE, PersistentDataType.STRING, TYPE_BEVERAGE_SELLER);

        v.setRecipes(buildBeverageRecipes());
        return v;
    }

    /** Trades des Zigaretten-Verkäufers. */
    public List<MerchantRecipe> buildCigaretteRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ItemManager im = plugin.getItemManager();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Tabak: 5 Tabak gegen 10 Smaragde
        // (Verkauft wird der getrocknete Tabak – direkt verarbeitbar)
        MerchantRecipe tobacco = new MerchantRecipe(im.createTobacco(5), 0, Integer.MAX_VALUE, false);
        tobacco.addIngredient(new ItemStack(Material.EMERALD, 10));
        recipes.add(tobacco);

        // Samen werden bewusst NICHT gehandelt – Spieler müssen Pflanzen ernten,
        // um an Samen zu kommen.

        // Eine Schachtel jeder normalen Marke, Preis pro Trade zufällig 16..29
        // Ausgeschlossen: SELFMADE (muss selbst gedreht werden),
        //                 HERB_JOINT, RAUCHZUCKER_CIG, LEAF_CIG (Drogenware)
        for (CigaretteBrand brand : CigaretteBrand.values()) {
            if (brand == CigaretteBrand.SELFMADE
                    || brand == CigaretteBrand.HERB_JOINT
                    || brand == CigaretteBrand.RAUCHZUCKER_CIG
                    || brand == CigaretteBrand.LEAF_CIG) continue;
            int price = rnd.nextInt(PACK_PRICE_MIN, PACK_PRICE_MAX + 1);
            MerchantRecipe pack = new MerchantRecipe(im.createPack(brand, 8), 0, Integer.MAX_VALUE, false);
            // Vanilla-Limit: ein Trade-Slot kann max. 2 Zutaten haben, jeder Slot max. 64.
            // 16..29 Smaragde passen in einen Slot.
            pack.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(pack);
        }

        // Optional: Feuerzeug
        MerchantRecipe lighter = new MerchantRecipe(im.createLighter(), 0, Integer.MAX_VALUE, false);
        lighter.addIngredient(new ItemStack(Material.EMERALD, 6));
        recipes.add(lighter);

        return recipes;
    }

    /** Trades des Vape-Verkäufers. */
    public List<MerchantRecipe> buildVapeRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ItemManager im = plugin.getItemManager();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        for (VapeFlavor flavor : VapeFlavor.values()) {
            if (flavor == VapeFlavor.VOZOL_40K) continue; // exklusiv beim Wandering Trader
            if (isRandmFlavor(flavor)) continue; // Randm 15k hat eigene Akku-Logik, nicht generisch verkaufbar
            int price = rnd.nextInt(VAPE_PRICE_MIN, VAPE_PRICE_MAX + 1);
            MerchantRecipe vape = new MerchantRecipe(im.createVape(flavor, 60), 0, Integer.MAX_VALUE, false);
            vape.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(vape);
        }

        return recipes;
    }

    /** Trades des Getränke-Verkäufers. */
    public List<MerchantRecipe> buildBeverageRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ItemManager im = plugin.getItemManager();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Bier-Pakete: 3, 6 (1 Stack) und 1er-Einzelverkauf, jeweils mit zufälligem Preis
        // Einzeln
        int beerSinglePrice = rnd.nextInt(BEER_PRICE_MIN, BEER_PRICE_MAX + 1);
        MerchantRecipe beer1 = new MerchantRecipe(im.createBeer(1), 0, Integer.MAX_VALUE, false);
        beer1.addIngredient(new ItemStack(Material.EMERALD, beerSinglePrice));
        recipes.add(beer1);

        // 3er-Pack mit kleinem Bulk-Rabatt
        int beerTripPrice = Math.max(1, beerSinglePrice * 3 - 1);
        MerchantRecipe beer3 = new MerchantRecipe(im.createBeer(3), 0, Integer.MAX_VALUE, false);
        beer3.addIngredient(new ItemStack(Material.EMERALD, Math.min(64, beerTripPrice)));
        recipes.add(beer3);

        // 6er-Kasten mit größerem Rabatt
        int beerSixPrice = Math.max(1, beerSinglePrice * 6 - 4);
        MerchantRecipe beer6 = new MerchantRecipe(im.createBeer(6), 0, Integer.MAX_VALUE, false);
        beer6.addIngredient(new ItemStack(Material.EMERALD, Math.min(64, beerSixPrice)));
        recipes.add(beer6);

        // Jäger einzeln
        int jaegerSinglePrice = rnd.nextInt(JAEGER_PRICE_MIN, JAEGER_PRICE_MAX + 1);
        MerchantRecipe j1 = new MerchantRecipe(im.createJaeger(1), 0, Integer.MAX_VALUE, false);
        j1.addIngredient(new ItemStack(Material.EMERALD, jaegerSinglePrice));
        recipes.add(j1);

        // Jäger 6er-Pack mit Rabatt
        int jaegerSixPrice = Math.max(1, jaegerSinglePrice * 6 - 3);
        MerchantRecipe j6 = new MerchantRecipe(im.createJaeger(6), 0, Integer.MAX_VALUE, false);
        j6.addIngredient(new ItemStack(Material.EMERALD, Math.min(64, jaegerSixPrice)));
        recipes.add(j6);

        // Monster White: einzeln und im 4er-Pack (passend zur max. 4-fach stapelbaren Wirkung).
        // Einzelpreis 35..60 Smaragde. Im 4er-Pack ist eine Dose gratis (zahlt nur 3x den
        // Einzelpreis) – das übersteigt den Vanilla-Stack-Cap von 64 Smaragden pro Zutat,
        // daher wird auf 2 Zutaten-Slots aufgeteilt (Vanilla-Limit: max. 2 Zutaten pro
        // Trade, je max. 64 = 128 insgesamt). Bei sehr hohem Einzelpreis wird der
        // Gesamtpreis auf 128 gedeckelt (seltener Grenzfall, bleibt aber immer günstiger
        // als der reguläre 4x-Preis).
        int monsterSinglePrice = rnd.nextInt(35, 61); // 35..60
        MerchantRecipe monster1 = new MerchantRecipe(im.createMonsterWhite(1), 0, Integer.MAX_VALUE, false);
        monster1.addIngredient(new ItemStack(Material.EMERALD, monsterSinglePrice));
        recipes.add(monster1);

        int monsterFourTotal = Math.min(128, monsterSinglePrice * 3); // 3 statt 4 bezahlen
        int slot1 = Math.min(64, monsterFourTotal);
        int slot2 = monsterFourTotal - slot1;
        MerchantRecipe monster4 = new MerchantRecipe(im.createMonsterWhite(4), 0, Integer.MAX_VALUE, false);
        monster4.addIngredient(new ItemStack(Material.EMERALD, slot1));
        if (slot2 > 0) monster4.addIngredient(new ItemStack(Material.EMERALD, slot2));
        recipes.add(monster4);

        return recipes;
    }

    /**
     * Erzeugt frische, neu-gewürfelte Trades und setzt sie auf einen bestehenden Trader.
     * Praktisch für /sa refresh oder bei Server-Neustart, wenn man neue Preise will.
     */
    public void refreshTrades(Villager v) {
        String type = getTraderType(v);
        if      (TYPE_CIG_SELLER.equals(type))      v.setRecipes(buildCigaretteRecipes());
        else if (TYPE_VAPE_SELLER.equals(type))     v.setRecipes(buildVapeRecipes());
        else if (TYPE_BEVERAGE_SELLER.equals(type)) v.setRecipes(buildBeverageRecipes());
        else if (TYPE_ARMORER.equals(type))         v.setRecipes(buildArmorerRecipes());
        else if (TYPE_WEAPONSMITH.equals(type))     v.setRecipes(buildWeaponsmithRecipes());
        else if (TYPE_TRIM_SELLER.equals(type))     v.setRecipes(buildTrimRecipes());
        else if (TYPE_FIREWORK_SELLER.equals(type)) v.setRecipes(buildFireworkRecipes());
        else if (TYPE_VAPE_TRADER.equals(type))     v.setRecipes(buildVapeTraderRecipes(getVapeTraderUses(v)));
    }

    // ================================================================
    // City-Trader: Spawn-Methoden
    // ================================================================

    /** Hilfsfunktion, um einen markierten Villager mit Standard-Setup zu spawnen. */
    private Villager spawnTrader(Location loc, String type, Component name,
                                 Villager.Profession prof) {
        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        v.setProfession(prof);
        v.setVillagerType(Villager.Type.PLAINS);
        v.setVillagerLevel(5);
        v.setVillagerExperience(250);
        v.customName(name);
        v.setCustomNameVisible(true);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(true);
        v.setAI(true);
        v.setInvulnerable(true);
        v.getPersistentDataContainer().set(Keys.TRADER_TYPE, PersistentDataType.STRING, type);
        return v;
    }

    public Villager spawnArmorer(Location loc) {
        Villager v = spawnTrader(loc, TYPE_ARMORER,
                Component.text("Rüstungsschmied", NamedTextColor.GRAY),
                Villager.Profession.ARMORER);
        v.setRecipes(buildArmorerRecipes());
        return v;
    }

    public Villager spawnWeaponsmith(Location loc) {
        Villager v = spawnTrader(loc, TYPE_WEAPONSMITH,
                Component.text("Waffenschmied", NamedTextColor.RED),
                Villager.Profession.WEAPONSMITH);
        v.setRecipes(buildWeaponsmithRecipes());
        return v;
    }

    public Villager spawnTrimSeller(Location loc) {
        Villager v = spawnTrader(loc, TYPE_TRIM_SELLER,
                Component.text("Trim-Händler", NamedTextColor.AQUA),
                Villager.Profession.LIBRARIAN);
        v.setRecipes(buildTrimRecipes());
        return v;
    }

    public Villager spawnFireworkSeller(Location loc) {
        Villager v = spawnTrader(loc, TYPE_FIREWORK_SELLER,
                Component.text("Raketen-Händler", NamedTextColor.GOLD),
                Villager.Profession.CARTOGRAPHER);
        v.setRecipes(buildFireworkRecipes());
        return v;
    }

    public Villager spawnVapeTrader(Location loc) {
        Villager v = spawnTrader(loc, TYPE_VAPE_TRADER,
                Component.text("Vape-Händler", NamedTextColor.LIGHT_PURPLE),
                Villager.Profession.CLERIC);
        v.getPersistentDataContainer().set(Keys.VAPE_TRADER_USES, PersistentDataType.INTEGER, 0);
        v.setRecipes(buildVapeTraderRecipes(0));
        return v;
    }

    public Villager spawnUnemployed(Location loc) {
        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        v.setProfession(Villager.Profession.NONE);
        v.setVillagerType(Villager.Type.PLAINS);
        v.customName(Component.text("Arbeitsloser", NamedTextColor.DARK_GRAY));
        v.setCustomNameVisible(true);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(true);
        v.setInvulnerable(true);
        v.getPersistentDataContainer().set(Keys.TRADER_TYPE, PersistentDataType.STRING, TYPE_UNEMPLOYED);
        return v;
    }

    // ================================================================
    // Trades: Rüstungsschmied
    // ================================================================
    public List<MerchantRecipe> buildArmorerRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Material[] iron = {
                Material.IRON_HELMET, Material.IRON_CHESTPLATE,
                Material.IRON_LEGGINGS, Material.IRON_BOOTS
        };
        Material[] diamond = {
                Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE,
                Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS
        };
        for (Material m : iron) {
            int price = rnd.nextInt(8, 14);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(m), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        for (Material m : diamond) {
            int price = rnd.nextInt(20, 28);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(m), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        // Schild
        MerchantRecipe shield = new MerchantRecipe(new ItemStack(Material.SHIELD), 0, Integer.MAX_VALUE, true);
        shield.addIngredient(new ItemStack(Material.EMERALD, rnd.nextInt(5, 9)));
        recipes.add(shield);
        return recipes;
    }

    // ================================================================
    // Trades: Waffenschmied
    // ================================================================
    public List<MerchantRecipe> buildWeaponsmithRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        // Eisen
        for (Material m : new Material[]{Material.IRON_SWORD, Material.IRON_AXE}) {
            int price = rnd.nextInt(7, 12);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(m), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        // Diamant
        for (Material m : new Material[]{Material.DIAMOND_SWORD, Material.DIAMOND_AXE}) {
            int price = rnd.nextInt(20, 28);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(m), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        // Bogen + Pfeile
        MerchantRecipe bow = new MerchantRecipe(new ItemStack(Material.BOW), 0, Integer.MAX_VALUE, true);
        bow.addIngredient(new ItemStack(Material.EMERALD, rnd.nextInt(6, 10)));
        recipes.add(bow);
        MerchantRecipe arrows = new MerchantRecipe(new ItemStack(Material.ARROW, 16), 0, Integer.MAX_VALUE, true);
        arrows.addIngredient(new ItemStack(Material.EMERALD, 2));
        recipes.add(arrows);
        // Armbrust
        MerchantRecipe cb = new MerchantRecipe(new ItemStack(Material.CROSSBOW), 0, Integer.MAX_VALUE, true);
        cb.addIngredient(new ItemStack(Material.EMERALD, rnd.nextInt(8, 13)));
        recipes.add(cb);
        return recipes;
    }

    // ================================================================
    // Trades: Trim-Händler (Smithing Templates)
    // ================================================================
    public List<MerchantRecipe> buildTrimRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Material[] templates = {
                Material.SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.COAST_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.WARD_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.EYE_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.VEX_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE,
                Material.SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE
        };
        // 5 zufällige Trims aus dem Pool
        java.util.Set<Integer> picked = new java.util.HashSet<>();
        while (picked.size() < 5 && picked.size() < templates.length) {
            picked.add(rnd.nextInt(templates.length));
        }
        for (int idx : picked) {
            int price = rnd.nextInt(18, 32);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(templates[idx]), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        // Smithing-Template-Kopien-Material (Diamant) im Tausch
        MerchantRecipe diamond = new MerchantRecipe(new ItemStack(Material.DIAMOND), 0, Integer.MAX_VALUE, true);
        diamond.addIngredient(new ItemStack(Material.EMERALD, 4));
        recipes.add(diamond);
        return recipes;
    }

    // ================================================================
    // Trades: Raketen-Händler
    // ================================================================
    public List<MerchantRecipe> buildFireworkRecipes() {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int power = 1; power <= 3; power++) {
            ItemStack rocket = new ItemStack(Material.FIREWORK_ROCKET, 8);
            org.bukkit.inventory.meta.FireworkMeta meta =
                    (org.bukkit.inventory.meta.FireworkMeta) rocket.getItemMeta();
            if (meta != null) {
                meta.setPower(power);
                rocket.setItemMeta(meta);
            }
            int price = power * 2;
            MerchantRecipe r = new MerchantRecipe(rocket, 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }
        // Bunte Rakete mit Effekt
        ItemStack fancy = new ItemStack(Material.FIREWORK_ROCKET, 4);
        org.bukkit.inventory.meta.FireworkMeta fm =
                (org.bukkit.inventory.meta.FireworkMeta) fancy.getItemMeta();
        if (fm != null) {
            fm.setPower(2);
            fm.addEffect(org.bukkit.FireworkEffect.builder()
                    .with(org.bukkit.FireworkEffect.Type.BALL_LARGE)
                    .withColor(org.bukkit.Color.fromRGB(rnd.nextInt(0xFFFFFF + 1)),
                               org.bukkit.Color.fromRGB(rnd.nextInt(0xFFFFFF + 1)))
                    .withFlicker().withTrail().build());
            fancy.setItemMeta(fm);
        }
        MerchantRecipe fancyR = new MerchantRecipe(fancy, 0, Integer.MAX_VALUE, true);
        fancyR.addIngredient(new ItemStack(Material.EMERALD, 8));
        recipes.add(fancyR);
        // Firework Star
        MerchantRecipe star = new MerchantRecipe(new ItemStack(Material.FIREWORK_STAR, 1), 0, Integer.MAX_VALUE, true);
        star.addIngredient(new ItemStack(Material.EMERALD, 3));
        recipes.add(star);
        return recipes;
    }

    // ================================================================
    // Trades: Vape-Händler (City) – levelbar zur Fumot
    // ================================================================
    /** Wie viele Trades sind nötig, bevor die Fumot freigeschaltet wird. */
    public static final int VAPE_TRADER_FUMOT_THRESHOLD = 10;

    public int getVapeTraderUses(Villager v) {
        Integer i = v.getPersistentDataContainer().get(Keys.VAPE_TRADER_USES, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    public void incrementVapeTraderUses(Villager v) {
        int n = getVapeTraderUses(v) + 1;
        v.getPersistentDataContainer().set(Keys.VAPE_TRADER_USES, PersistentDataType.INTEGER, n);
        // Bei Schwelle: neu setzen, damit Fumot erscheint
        if (n == VAPE_TRADER_FUMOT_THRESHOLD) {
            v.setRecipes(buildVapeTraderRecipes(n));
            // Visuelles Feedback
            v.getWorld().spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER,
                    v.getLocation().add(0, 1.5, 0), 20, 0.4, 0.4, 0.4, 0.05);
            v.getWorld().playSound(v.getLocation(),
                    org.bukkit.Sound.ENTITY_VILLAGER_CELEBRATE, 1.2f, 1.6f);
        }
    }

    public List<MerchantRecipe> buildVapeTraderRecipes(int currentUses) {
        List<MerchantRecipe> recipes = new ArrayList<>();
        ItemManager im = plugin.getItemManager();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        // Reguläre Vapes (alle Sorten): 18..24 Smaragde pro Trade-Slot
        for (VapeFlavor flavor : VapeFlavor.values()) {
            if (flavor == VapeFlavor.VOZOL_40K) continue; // exklusiv beim Wandering Trader
            if (isRandmFlavor(flavor)) continue; // Randm 15k hat eigene Akku-Logik, nicht generisch verkaufbar
            int price = rnd.nextInt(18, 25); // 18..24 inklusive
            MerchantRecipe r = new MerchantRecipe(im.createVape(flavor, 60), 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, price));
            recipes.add(r);
        }

        // Premium-Slot: Fumot 12k – nur freigeschaltet ab VAPE_TRADER_FUMOT_THRESHOLD Trades.
        // Fester Preis: 18 Smaragde.
        if (currentUses >= VAPE_TRADER_FUMOT_THRESHOLD) {
            ItemStack fumot = im.createFumot();
            MerchantRecipe r = new MerchantRecipe(fumot, 0, Integer.MAX_VALUE, true);
            r.addIngredient(new ItemStack(Material.EMERALD, 18));
            recipes.add(r);
        }

        return recipes;
    }
}
