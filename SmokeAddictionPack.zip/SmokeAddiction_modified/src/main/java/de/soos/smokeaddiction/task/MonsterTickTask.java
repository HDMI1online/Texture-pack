package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Tickt jede Sekunde, um Monster-White-Wirkdauer/BossBar/Überdosis zu aktualisieren. */
public class MonsterTickTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public MonsterTickTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getMonsterManager().tick(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Monster-Tick-Fehler für " + p.getName()
                        + ": " + ex.getMessage());
            }
        }
    }
}
