package de.soos.smokeaddiction.model;

import java.util.UUID;

/**
 * Persistente Daten eines Spielers im Sucht-System.
 *
 * <p>Sucht-Stufen werden so gehandhabt: 0 = nicht süchtig, 1 = stärkste Sucht ... 5 = schwächste Sucht.
 * Spieler beginnen mit Stufe 0, bekommen nach der ersten Zigarette die Nikotin-Leiste angezeigt
 * und steigen mit weiteren Konsumen in stärkere Stufen auf.</p>
 */
public class PlayerData {

    public static final double NICOTINE_MAX        = 10.0;  // Maximale Punkte auf der Leiste (Shisha = Maximum)
    public static final double NICOTINE_PER_CIG    = 8.0;   // Eine Zigarette füllt ~80%
    public static final double NICOTINE_PER_PUFF   = 0.5;   // Ein Vape-Zug
    public static final double NICOTINE_PER_SHISHA = 10.0;  // Eine Shisha-Sitzung füllt komplett auf 10

    // Schwellen: ab wie vielen Zigaretten welche Stufe erreicht wird
    // Stufe 4 nach 3, Stufe 3 nach 3+4=7, Stufe 2 nach 7+5=12, Stufe 1 nach 12+5=17
    public static final int THRESHOLD_LVL_4 = 8;
    public static final int THRESHOLD_LVL_3 = 16;
    public static final int THRESHOLD_LVL_2 = 24;
    public static final int THRESHOLD_LVL_1 = 32;

    private final UUID uuid;

    private boolean addicted;          // Hat der Spieler überhaupt jemals geraucht?
    private int addictionLevel;        // 0=nicht süchtig, 1=schlimm, 5=mild
    private int totalCigarettesSmoked; // Gesamtzahl konsumierter Zigaretten (für Stufenaufstieg)
    private double nicotineLevel;      // Aktuelle Punkte auf der Nikotin-Leiste (0..NICOTINE_MAX)
    private long lastDecayMillis;      // Zeitpunkt des letzten Decay-Schrittes
    private long withdrawalStartMillis;// Wann begann der aktuelle Entzug? (0 wenn nicht im Entzug)
    private boolean inWithdrawal;      // Aktuell auf Nikotin == 0?
    private boolean shishaUsed;        // Hat der Spieler schon einmal an einer Shisha gezogen? (Achievement-Flag)
    private boolean vapeUsed;          // Hat der Spieler schon einmal an einer Vape gezogen? (Achievement-Flag)
    private double bloodAlcohol;       // Promille (‰)
    private long lastAlcDecayMillis;   // Zeitpunkt des letzten Promille-Decay-Schritts
    private long herbBuffUntilMillis;       // Bis wann läuft der Regen-Buff
    private long herbWithdrawalUntilMillis; // Bis wann läuft der Heilungs-Block

    // Custom-Substanzen (Kokain/LSD/Crack/Spritze/Magic Mushroom): pro Typ
    // Wirkungs- und Entzugs-Deadline (epoch-millis, 0 = inaktiv). Wird beim
    // Logout gespeichert und beim Login wiederhergestellt, damit Effekte UND
    // Entzüge einen Rejoin überleben (siehe SubstanceManager).
    private final java.util.EnumMap<SubstanceType, Long> substanceEffectUntil =
            new java.util.EnumMap<>(SubstanceType.class);
    private final java.util.EnumMap<SubstanceType, Long> substanceWithdrawalUntil =
            new java.util.EnumMap<>(SubstanceType.class);

    // Monster White (Koffein-Energy-Drink): Stack-Zähler (0..n, 4 sind effektiv)
    // und Deadline der aktuellen 2-Minuten-Wirkungsphase. 0 = kein aktiver Effekt.
    private int monsterStacks;
    private long monsterUntilMillis;

    // Persönliche Resource-Pack-Präferenz: true = dieser Spieler hat das Pack für
    // sich SELBST deaktiviert (/sa resourcepack disable), bekommt es beim Login also
    // nicht mehr aufgedrängt. Server-weiter Standard bleibt in config.yml; dies ist
    // eine PRO-SPIELER-Ausnahme davon, betrifft also nur den jeweiligen Spieler.
    private boolean resourcePackDisabled;
    private boolean tutorialSeen;
    private boolean scoreboardHidden;
    private int pvpKills;
    private int totalDeaths; // Spieler hat das Scoreboard für sich selbst versteckt // Hat der Spieler das Einführungs-Tutorial bereits gesehen?

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.addicted = false;
        this.addictionLevel = 0;
        this.totalCigarettesSmoked = 0;
        this.nicotineLevel = 0.0;
        this.lastDecayMillis = System.currentTimeMillis();
        this.withdrawalStartMillis = 0L;
        this.inWithdrawal = false;
        this.shishaUsed = false;
        this.vapeUsed = false;
        this.bloodAlcohol = 0.0;
        this.lastAlcDecayMillis = System.currentTimeMillis();
        this.herbBuffUntilMillis = 0L;
        this.herbWithdrawalUntilMillis = 0L;
    }

    /**
     * Berechnet anhand der Gesamtanzahl konsumierter Zigaretten die natürliche Sucht-Stufe.
     * Wird nur zum Aufstieg genutzt – Heilen reduziert die Stufe unabhängig davon.
     */
    public static int levelFromCigaretteCount(int total) {
        if (total >= THRESHOLD_LVL_1) return 1;
        if (total >= THRESHOLD_LVL_2) return 2;
        if (total >= THRESHOLD_LVL_3) return 3;
        if (total >= THRESHOLD_LVL_4) return 4;
        return 5;
    }

    /**
     * Liefert das Decay-Intervall in Sekunden, wie lange es dauert,
     * bis Nikotin von voll auf 0 fällt – abhängig von der Sucht-Stufe.
     */
    public static int decayIntervalSeconds(int level) {
        // Je höher die Sucht-Stufe, desto LÄNGER hält der Nikotin-Spiegel:
        //   Stufe 1 -> 10 Min, Stufe 2 -> 15 Min, Stufe 3 -> 20 Min,
        //   Stufe 4 -> 25 Min, Stufe 5 -> 30 Min, bis die Leiste komplett leer ist.
        switch (level) {
            case 1:  return 10 * 60;
            case 2:  return 15 * 60;
            case 3:  return 20 * 60;
            case 4:  return 25 * 60;
            case 5:  return 30 * 60;
            default: return 10 * 60; // Stufe 0 / unbekannt: schnellster Abbau
        }
    }

    // === Getter / Setter ===

    public UUID getUuid()                  { return uuid; }
    public boolean isAddicted()            { return addicted; }
    public void setAddicted(boolean v)     { this.addicted = v; }

    public int getAddictionLevel()         { return addictionLevel; }
    public void setAddictionLevel(int l)   { this.addictionLevel = Math.max(0, Math.min(5, l)); }

    public int getTotalCigarettesSmoked()  { return totalCigarettesSmoked; }
    public void setTotalCigarettesSmoked(int n) { this.totalCigarettesSmoked = n; }
    public void incrementCigarettesSmoked() { this.totalCigarettesSmoked++; }

    public double getNicotineLevel()       { return nicotineLevel; }
    public void setNicotineLevel(double n) { this.nicotineLevel = Math.max(0.0, Math.min(NICOTINE_MAX, n)); }

    public long getLastDecayMillis()        { return lastDecayMillis; }
    public void setLastDecayMillis(long ms) { this.lastDecayMillis = ms; }

    public long getWithdrawalStartMillis()        { return withdrawalStartMillis; }
    public void setWithdrawalStartMillis(long ms) { this.withdrawalStartMillis = ms; }

    public boolean isInWithdrawal()         { return inWithdrawal; }
    public void setInWithdrawal(boolean v)  { this.inWithdrawal = v; }

    public boolean hasUsedShisha()          { return shishaUsed; }
    public void setShishaUsed(boolean v)    { this.shishaUsed = v; }
    public boolean hasUsedVape()            { return vapeUsed; }
    public void setVapeUsed(boolean v)      { this.vapeUsed = v; }

    public double getBloodAlcohol()         { return bloodAlcohol; }
    public void setBloodAlcohol(double v)   { this.bloodAlcohol = Math.max(0.0, v); }

    public long getLastAlcDecayMillis()        { return lastAlcDecayMillis; }
    public void setLastAlcDecayMillis(long ms) { this.lastAlcDecayMillis = ms; }

    public long getHerbBuffUntilMillis()        { return herbBuffUntilMillis; }
    public void setHerbBuffUntilMillis(long ms) { this.herbBuffUntilMillis = ms; }

    /** Live-Map-Referenz: Wirkungs-Deadline (epoch-millis) je Custom-Substanz, 0/fehlend = inaktiv. */
    public java.util.EnumMap<SubstanceType, Long> getSubstanceEffectUntilMap() { return substanceEffectUntil; }
    /** Live-Map-Referenz: Entzugs-Deadline (epoch-millis) je Custom-Substanz, 0/fehlend = inaktiv. */
    public java.util.EnumMap<SubstanceType, Long> getSubstanceWithdrawalUntilMap() { return substanceWithdrawalUntil; }

    public int getMonsterStacks()             { return monsterStacks; }
    public void setMonsterStacks(int v)       { this.monsterStacks = Math.max(0, v); }
    public long getMonsterUntilMillis()       { return monsterUntilMillis; }
    public void setMonsterUntilMillis(long v) { this.monsterUntilMillis = v; }

    public boolean isResourcePackDisabled()        { return resourcePackDisabled; }
    public void setResourcePackDisabled(boolean v) { this.resourcePackDisabled = v; }
    public boolean hasTutorialSeen()               { return tutorialSeen; }
    public void setTutorialSeen(boolean v)         { this.tutorialSeen = v; }
    public boolean isScoreboardHidden()            { return scoreboardHidden; }
    public void setScoreboardHidden(boolean v)     { this.scoreboardHidden = v; }
    public int getPvpKills()                       { return pvpKills; }
    public void setPvpKills(int v)                 { this.pvpKills = Math.max(0, v); }
    public int getTotalDeaths()                    { return totalDeaths; }
    public void setTotalDeaths(int v)              { this.totalDeaths = Math.max(0, v); }

    public long getHerbWithdrawalUntilMillis()        { return herbWithdrawalUntilMillis; }
    public void setHerbWithdrawalUntilMillis(long ms) { this.herbWithdrawalUntilMillis = ms; }
}
