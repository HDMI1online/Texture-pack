package de.soos.smokeaddiction;

import de.soos.smokeaddiction.listener.AlcoholListener;
import de.soos.smokeaddiction.listener.CityListener;
import de.soos.smokeaddiction.listener.CraftingListener;
import de.soos.smokeaddiction.listener.HerbWithdrawalListener;
import de.soos.smokeaddiction.listener.PackListener;
import de.soos.smokeaddiction.listener.PlayerListener;
import de.soos.smokeaddiction.listener.ResourcePackListener;
import de.soos.smokeaddiction.listener.ShishaListener;
import de.soos.smokeaddiction.listener.SmokeCommand;
import de.soos.smokeaddiction.listener.SmokeListener;
import de.soos.smokeaddiction.listener.SubstanceListener;
import de.soos.smokeaddiction.listener.TobaccoListener;
import de.soos.smokeaddiction.listener.TradeListener;
import de.soos.smokeaddiction.listener.VapeListener;
import de.soos.smokeaddiction.manager.AlcoholManager;
import de.soos.smokeaddiction.manager.CityGenerator;
import de.soos.smokeaddiction.manager.CityRegistry;
import de.soos.smokeaddiction.manager.HerbBushRegistry;
import de.soos.smokeaddiction.manager.TobaccoBushRegistry;
import de.soos.smokeaddiction.manager.HerbManager;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.manager.NicotineManager;
import de.soos.smokeaddiction.manager.PackBlockManager;
import de.soos.smokeaddiction.manager.PlayerDataManager;
import de.soos.smokeaddiction.manager.RecipeManager;
import de.soos.smokeaddiction.manager.ShishaManager;
import de.soos.smokeaddiction.manager.SmokingManager;
import de.soos.smokeaddiction.manager.SubstanceManager;
import de.soos.smokeaddiction.manager.TraderManager;
import de.soos.smokeaddiction.task.AlcoholDecayTask;
import de.soos.smokeaddiction.task.DrunkSpawnTask;
import de.soos.smokeaddiction.task.VapeDropChargeTask;
import de.soos.smokeaddiction.task.HerbTickTask;
import de.soos.smokeaddiction.task.NicotineDecayTask;
import de.soos.smokeaddiction.task.SubstanceTickTask;
import de.soos.smokeaddiction.util.Keys;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Hauptklasse des SmokeAddiction-Plugins.
 *
 * Initialisiert in der korrekten Reihenfolge:
 *   Keys -> Manager (Daten/Items/Nikotin/Schachtel/Rauch) -> Listener -> Tasks.
 */
public class SmokeAddictionPlugin extends JavaPlugin {

    private PlayerDataManager playerDataManager;
    private ItemManager itemManager;
    private NicotineManager nicotineManager;
    private SmokingManager smokingManager;
    private PackBlockManager packBlockManager;
    private de.soos.smokeaddiction.task.VapeDropChargeTask vapeDropChargeTask;
    private de.soos.smokeaddiction.manager.MonsterManager monsterManager;
    private ResourcePackListener resourcePackListener;
    private de.soos.smokeaddiction.manager.TutorialManager tutorialManager;
    private de.soos.smokeaddiction.manager.SaScoreboardManager saScoreboardManager;
    private RecipeManager recipeManager;
    private TobaccoListener tobaccoListener;
    private TraderManager traderManager;
    private ShishaManager shishaManager;
    private AlcoholManager alcoholManager;
    private CityRegistry cityRegistry;
    private CityGenerator cityGenerator;
    private HerbBushRegistry herbBushRegistry;
    private TobaccoBushRegistry tobaccoBushRegistry;
    private HerbManager herbManager;
    private SubstanceManager substanceManager;
    private de.soos.smokeaddiction.manager.EnchantmentManager enchantmentManager;
    private de.soos.smokeaddiction.manager.MineshaftVillageRegistry mineshaftVillageRegistry;
    private de.soos.smokeaddiction.manager.MineshaftVillageGenerator mineshaftVillageGenerator;
    private de.soos.smokeaddiction.manager.CasinoRegistry casinoRegistry;
    private de.soos.smokeaddiction.manager.CasinoManager casinoManager;
    private de.soos.smokeaddiction.manager.DebugManager debugManager;

    @Override
    public void onEnable() {
        // Datenordner sicherstellen
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Konnte Plugin-Ordner nicht anlegen.");
        }

        // Default-Config schreiben falls nicht vorhanden
        saveDefaultConfig();

        // 1) Keys initialisieren (sonst NPE in allen ItemMeta-Operationen)
        Keys.init(this);

        // Debug-Manager sofort initialisieren
        this.debugManager = new de.soos.smokeaddiction.manager.DebugManager(this);

        // 2) Manager
        this.playerDataManager = new PlayerDataManager(this);
        this.itemManager       = new ItemManager();
        this.nicotineManager   = new NicotineManager(this, playerDataManager);
        this.smokingManager    = new SmokingManager(this, nicotineManager);
        this.packBlockManager  = new PackBlockManager(this, itemManager);
        this.monsterManager = new de.soos.smokeaddiction.manager.MonsterManager(this, playerDataManager);
        this.recipeManager     = new RecipeManager(this);
        this.traderManager     = new TraderManager(this);
        this.shishaManager     = new ShishaManager(this);
        this.alcoholManager    = new AlcoholManager(this, playerDataManager);
        this.cityRegistry      = new CityRegistry(this);
        this.cityGenerator     = new CityGenerator(this, traderManager);
        this.herbBushRegistry  = new HerbBushRegistry(this);
        this.tobaccoBushRegistry = new TobaccoBushRegistry(this);
        this.herbManager       = new HerbManager(this, playerDataManager);
        this.substanceManager  = new SubstanceManager(this);
        this.enchantmentManager = new de.soos.smokeaddiction.manager.EnchantmentManager(this);
        this.mineshaftVillageRegistry = new de.soos.smokeaddiction.manager.MineshaftVillageRegistry(this);
        this.mineshaftVillageGenerator = new de.soos.smokeaddiction.manager.MineshaftVillageGenerator(this);
        this.casinoRegistry = new de.soos.smokeaddiction.manager.CasinoRegistry(this);
        this.casinoManager = new de.soos.smokeaddiction.manager.CasinoManager(this);

        // 3) Listener
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new SmokeListener(this), this);
        getServer().getPluginManager().registerEvents(new VapeListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.RandmVapeListener(this), this);
        getServer().getPluginManager().registerEvents(new PackListener(this), this);
        tobaccoListener = new TobaccoListener(this);
        getServer().getPluginManager().registerEvents(tobaccoListener, this);
        getServer().getPluginManager().registerEvents(new CraftingListener(this), this);
        getServer().getPluginManager().registerEvents(new ShishaListener(this), this);
        resourcePackListener = new ResourcePackListener(this);
        getServer().getPluginManager().registerEvents(resourcePackListener, this);
        this.tutorialManager = new de.soos.smokeaddiction.manager.TutorialManager(this);
        this.saScoreboardManager = new de.soos.smokeaddiction.manager.SaScoreboardManager(this);
        getServer().getPluginManager().registerEvents(new AlcoholListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.MonsterListener(this), this);
        getServer().getPluginManager().registerEvents(new CityListener(this), this);
        getServer().getPluginManager().registerEvents(new TradeListener(this), this);
        getServer().getPluginManager().registerEvents(new HerbWithdrawalListener(this), this);
        getServer().getPluginManager().registerEvents(new SubstanceListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.EnchantTableListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.LootListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.WanderingTraderListener(this), this);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.CasinoListener(this), this);

        // 4) Crafting-Rezepte
        recipeManager.registerRecipes();

        // Falls beim /reload bereits Spieler online sind, deren Rezeptbuch sofort updaten
        for (org.bukkit.entity.Player online : getServer().getOnlinePlayers()) {
            recipeManager.discoverAll(online);
        }

        // 5) Command
        SmokeCommand cmd = new SmokeCommand(this);
        PluginCommand pc = getCommand("smokeaddiction");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        // 6) Tasks – jede Sekunde (20 ticks)
        new NicotineDecayTask(this).runTaskTimer(this, 20L, 20L);
        // Natürlicher Tabak/Cannabis-Spawn: jede Minute prüfen
        getServer().getScheduler().runTaskTimer(this, () ->
                tobaccoListener.tickNaturalSpawn(), 200L, 1200L);
        vapeDropChargeTask = new VapeDropChargeTask(this);
        vapeDropChargeTask.runTaskTimer(this, 20L, 20L);
        new AlcoholDecayTask(this).runTaskTimer(this, 20L, 20L);
        // Zombie-Spawn-Check alle 10 Sekunden
        new DrunkSpawnTask(this).runTaskTimer(this, 200L, 200L);
        new HerbTickTask(this).runTaskTimer(this, 20L, 20L);
        new de.soos.smokeaddiction.task.MonsterTickTask(this).runTaskTimer(this, 20L, 20L);
        getServer().getPluginManager().registerEvents(
                new de.soos.smokeaddiction.listener.ScoreboardListener(this), this);
        // Scoreboard alle 2 Sekunden aktualisieren (40 Ticks)
        getServer().getScheduler().runTaskTimer(this,
                () -> saScoreboardManager.update(), 40L, 40L);
        new SubstanceTickTask(this).runTaskTimer(this, 20L, 20L);
        // Alle Registries alle 30 Min auto-speichern
        long saveInterval = 20L * 60L * 30L; // 30 Minuten in Ticks
        getServer().getScheduler().runTaskTimer(this, () -> {
            if (herbBushRegistry         != null) herbBushRegistry.save();
            if (tobaccoBushRegistry      != null) tobaccoBushRegistry.save();
            if (cityRegistry             != null) cityRegistry.save();
            if (mineshaftVillageRegistry != null) mineshaftVillageRegistry.save();
        }, saveInterval, saveInterval);

        // 7) Bossbars für bereits eingeloggte Spieler (Reload-Fall)
        for (var p : getServer().getOnlinePlayers()) {
            // Decay-Timer auf jetzt zurücksetzen, damit Reload nicht durchschlägt
            playerDataManager.get(p).setLastDecayMillis(System.currentTimeMillis());
            nicotineManager.updateBossBar(p);
            nicotineManager.applyEffects(p);
        }

        getLogger().info("SmokeAddiction aktiviert.");
    }

    @Override
    public void onDisable() {
        // Recipes entfernen
        if (recipeManager != null) recipeManager.unregisterRecipes();

        // Schwebende Akkustand-Anzeigen über ladenden Vapes entfernen
        if (vapeDropChargeTask != null) vapeDropChargeTask.clearAllIndicators();

        // Laufende Sessions abbrechen, Bossbars entfernen, Daten speichern.
        // WICHTIG: SubstanceManager hält seinen Live-Zustand (Kokain/LSD/Crack/Spritze/
        // Magic Mushroom) separat vom PlayerData-Cache und schreibt ihn normalerweise
        // erst beim individuellen PlayerQuitEvent dorthin zurück. Bei einem Server-
        // Restart/Reload, der onDisable() direkt aufruft (z.B. /reload confirm oder
        // bestimmte Stop-Abläufe), ist das nicht garantiert für jeden Spieler bereits
        // passiert – deshalb hier defensiv für ALLE Online-Spieler nachholen, bevor
        // gespeichert wird. Nikotin/Alkohol/Heilkraut/Monster White schreiben dagegen
        // immer direkt in PlayerData und brauchen diesen Schritt nicht zusätzlich.
        for (var p : getServer().getOnlinePlayers()) {
            if (smokingManager != null) smokingManager.cancel(p);
            if (shishaManager != null)  shishaManager.cancelSession(p);
            if (nicotineManager != null) nicotineManager.removeBossBar(p);
            if (alcoholManager != null) alcoholManager.removeBossBar(p);
            if (herbManager != null) herbManager.removeBossBars(p);
            if (monsterManager != null) monsterManager.removeBossBar(p);
            if (substanceManager != null) substanceManager.persistToPlayerData(p);
        }
        if (playerDataManager != null) playerDataManager.saveAll();
        if (herbBushRegistry != null) herbBushRegistry.save();
        getLogger().info("SmokeAddiction deaktiviert.");
    }

    // === Getter ===

    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public ItemManager       getItemManager()       { return itemManager; }
    public NicotineManager   getNicotineManager()   { return nicotineManager; }
    public SmokingManager    getSmokingManager()    { return smokingManager; }
    public PackBlockManager  getPackBlockManager()  { return packBlockManager; }
    public de.soos.smokeaddiction.manager.MonsterManager getMonsterManager() { return monsterManager; }
    public ResourcePackListener getResourcePackListener() { return resourcePackListener; }
    public de.soos.smokeaddiction.manager.TutorialManager getTutorialManager() { return tutorialManager; }
    public de.soos.smokeaddiction.manager.SaScoreboardManager getSaScoreboardManager() { return saScoreboardManager; }
    public RecipeManager     getRecipeManager()     { return recipeManager; }
    public TraderManager     getTraderManager()     { return traderManager; }
    public ShishaManager     getShishaManager()     { return shishaManager; }
    public AlcoholManager    getAlcoholManager()    { return alcoholManager; }
    public CityRegistry      getCityRegistry()      { return cityRegistry; }
    public CityGenerator     getCityGenerator()     { return cityGenerator; }
    public HerbBushRegistry     getHerbBushRegistry()     { return herbBushRegistry; }
    public TobaccoBushRegistry  getTobaccoBushRegistry()  { return tobaccoBushRegistry; }
    public HerbManager       getHerbManager()       { return herbManager; }
    public SubstanceManager  getSubstanceManager()  { return substanceManager; }
    public de.soos.smokeaddiction.manager.EnchantmentManager getEnchantmentManager() {
        return enchantmentManager;
    }
    public de.soos.smokeaddiction.manager.MineshaftVillageRegistry getMineshaftVillageRegistry() {
        return mineshaftVillageRegistry;
    }
    public de.soos.smokeaddiction.manager.MineshaftVillageGenerator getMineshaftVillageGenerator() {
        return mineshaftVillageGenerator;
    }
    public de.soos.smokeaddiction.manager.CasinoRegistry getCasinoRegistry() {
        return casinoRegistry;
    }
    public de.soos.smokeaddiction.manager.CasinoManager getCasinoManager() {
        return casinoManager;
    }
    public de.soos.smokeaddiction.manager.DebugManager getDebugManager() {
        return debugManager;
    }
}
