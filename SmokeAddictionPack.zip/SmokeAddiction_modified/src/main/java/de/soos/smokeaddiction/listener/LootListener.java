package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.loot.LootTable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Schaltet Custom-Items in Vanilla-Loot-Truhen ein.
 *
 * Mineshaft-Truhen: Kokain (8%), LSD (5%), Crack (4%) — alle selten, max 1 Stück;
 *                    zusätzlich 50% Chance auf eine zufällige Vape (Vozol selten)
 * Bastion-Truhen:   Leaf (12%) + zufällige Droge, INKLUSIVE Crack — Bastions liegen
 *                    im Nether, das ist der einzige Ort, an dem Crack noch spawnt.
 * Monument-Truhen:  Früher Crack — jetzt durch eine zufällige Vape ersetzt
 *                    (Vozol selten), da Monumente nicht im Nether liegen.
 *
 * ZUSÄTZLICH: Pro Spieler wird gezählt, wieviele Mineshaft-Truhen er bereits
 * geöffnet hat. Ab der 1. Truhe gibt's eine 70% Chance, dass ein Dealer-Dorf
 * in der Nähe entsteht. Min-Distanz 300 Blöcke zwischen Dörfern wird in der
 * Registry geprüft.
 */
public class LootListener implements Listener {

    private final SmokeAddictionPlugin plugin;
    private final Map<UUID, Integer> mineshaftChestCounter = new HashMap<>();

    public LootListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onLoot(LootGenerateEvent e) {
        LootTable table = e.getLootTable();
        if (table == null) return;
        org.bukkit.NamespacedKey key = table.getKey();
        if (key == null) return;
        String tableName = key.toString();

        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        de.soos.smokeaddiction.manager.ItemManager im = plugin.getItemManager();

        // === Mineshafts ===
        // Immer: Bier + Jäger; sonst alles außer Crack (3 Stück zufällige Droge)
        if (tableName.contains("abandoned_mineshaft")) {
            // Bier und Jäger immer dabei
            e.getLoot().add(im.createBeer(rnd.nextInt(2) + 1));
            e.getLoot().add(im.createJaeger(rnd.nextInt(2) + 1));

            // Zufällige Droge (außer Crack/Rauchzucker) — 3 Stück
            ItemStack drug = switch (rnd.nextInt(5)) {
                case 0 -> im.createMagikzucker(3);   // Kokain
                case 1 -> im.createTablette(3);       // LSD
                case 2 -> im.createLeaf(3);            // Leaf
                case 3 -> im.createSpritze(3);         // Heroin
                default -> im.createMagicMushroom(3); // Magic Mushroom
            };
            e.getLoot().add(drug);

            // Zusätzlich 50% Chance auf eine zufällige Vape (Vozol selten)
            if (rnd.nextDouble() < 0.50) {
                e.getLoot().add(createRandomVape(rnd, im));
            }

            // Trigger Dealer-Dorf wenn der Spieler genug Mineshaft-Truhen entdeckt hat
            if (e.getEntity() instanceof Player p) {
                tryTriggerDealerVillage(p, e.getInventoryHolder() instanceof org.bukkit.block.Container c
                        ? c.getBlock().getLocation() : p.getLocation());
            } else if (e.getInventoryHolder() instanceof org.bukkit.block.Container c) {
                Location chestLoc = c.getBlock().getLocation();
                Player nearest = nearestPlayer(chestLoc, 16);
                if (nearest != null) tryTriggerDealerVillage(nearest, chestLoc);
            }
            return;
        }

        // === Bastions ===
        // 3 Stück von einer zufälligen Droge
        if (tableName.contains("bastion")) {
            ItemStack drug = switch (rnd.nextInt(6)) {
                case 0 -> im.createMagikzucker(3);
                case 1 -> im.createTablette(3);
                case 2 -> im.createRauchzucker(3);
                case 3 -> im.createLeaf(3);
                case 4 -> im.createSpritze(3);
                default -> im.createMagicMushroom(3);
            };
            e.getLoot().add(drug);
            return;
        }

        // === Ozeanmonumente ===
        // Vorher Crack — jetzt zufällige Vape (Vozol selten), da Monumente
        // nicht im Nether liegen und Crack dort nicht mehr spawnen soll.
        if (tableName.contains("monument")) {
            e.getLoot().add(createRandomVape(rnd, im));
        }
    }

    /**
     * Erzeugt eine zufällige Vape für Truhen-Loot:
     *  - 65% normale Elfbar (zufällige Standard-Sorte, 60 Züge)
     *  - 25% Randm 15k (zufällige Sorte)
     *  - 10% Vozol 40k (selten, wie gewünscht)
     */
    private ItemStack createRandomVape(ThreadLocalRandom rnd, de.soos.smokeaddiction.manager.ItemManager im) {
        double roll = rnd.nextDouble();
        if (roll < 0.10) {
            return im.createVozol();
        } else if (roll < 0.35) {
            de.soos.smokeaddiction.model.VapeFlavor[] randmFlavors =
                    de.soos.smokeaddiction.model.VapeFlavor.randmFlavors();
            return im.createRandm(randmFlavors[rnd.nextInt(randmFlavors.length)]);
        } else {
            de.soos.smokeaddiction.model.VapeFlavor[] basic = {
                    de.soos.smokeaddiction.model.VapeFlavor.BLUE_RAZZ,
                    de.soos.smokeaddiction.model.VapeFlavor.WATERMELON,
                    de.soos.smokeaddiction.model.VapeFlavor.MANGO_ICE,
                    de.soos.smokeaddiction.model.VapeFlavor.GRAPE,
                    de.soos.smokeaddiction.model.VapeFlavor.APPLE_PEACH,
                    de.soos.smokeaddiction.model.VapeFlavor.COTTON_CANDY,
                    de.soos.smokeaddiction.model.VapeFlavor.MENTHOL,
            };
            return im.createVape(basic[rnd.nextInt(basic.length)], 60);
        }
    }

    private void tryTriggerDealerVillage(Player p, Location chestLoc) {
        UUID id = p.getUniqueId();
        int count = mineshaftChestCounter.getOrDefault(id, 0) + 1;
        mineshaftChestCounter.put(id, count);

        // Ab Truhe 1 bereits möglich (kein Mindest-Counter mehr)
        if (count < 1) return;

        // 70% Chance pro qualifizierter Truhe
        if (ThreadLocalRandom.current().nextDouble() > 0.70) return;

        // Bereits ein Dorf in der Nähe?
        if (plugin.getMineshaftVillageRegistry().isVillageNearby(chestLoc)) return;

        // Counter zurücksetzen damit nicht in Endlosschleife getriggert wird
        mineshaftChestCounter.put(id, 0);

        // Suche eine geeignete Stelle 30-50 Block entfernt vom Spieler, im Y-Bereich 25-50
        Location buildLoc = findBuildLocation(chestLoc);
        if (buildLoc == null) return;

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getMineshaftVillageGenerator().build(buildLoc);
            plugin.getLogger().info("Mineshaft-Dealer-Dorf gebaut bei "
                    + buildLoc.getBlockX() + "/" + buildLoc.getBlockY() + "/" + buildLoc.getBlockZ());
        });
    }

    private Location findBuildLocation(Location origin) {
        // Suche eine Stelle 30-50 Blöcke entfernt mit genug Platz (eher tief, Y 25-50)
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 20; attempt++) {
            double angle = rnd.nextDouble() * Math.PI * 2;
            double dist = 30 + rnd.nextDouble() * 20;
            int dx = (int) (Math.cos(angle) * dist);
            int dz = (int) (Math.sin(angle) * dist);
            int targetY = 25 + rnd.nextInt(26); // 25..50

            Location candidate = origin.clone().add(dx, 0, dz);
            candidate.setY(targetY);
            // Wir bauen die Cave selber aus, Bedingung sind nur Welt-Grenzen
            if (candidate.getWorld() != null
                    && candidate.getBlockY() > candidate.getWorld().getMinHeight() + 5
                    && candidate.getBlockY() < candidate.getWorld().getMaxHeight() - 30) {
                return candidate;
            }
        }
        return null;
    }

    private Player nearestPlayer(Location loc, double maxDist) {
        Player nearest = null;
        double bestSq = maxDist * maxDist;
        if (loc.getWorld() == null) return null;
        for (Player p : loc.getWorld().getPlayers()) {
            double sq = p.getLocation().distanceSquared(loc);
            if (sq < bestSq) {
                bestSq = sq;
                nearest = p;
            }
        }
        return nearest;
    }
}
