package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Prüft alle 10 Sekunden, ob ein Spieler Promille-Schwellen erreicht hat,
 * bei denen halluzinierte Zombies spawnen sollen (ab 2.5 ‰).
 */
public class DrunkSpawnTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public DrunkSpawnTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getAlcoholManager().maybeSpawnZombies(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Zombie-Spawn-Fehler für " + p.getName()
                        + ": " + ex.getMessage());
            }
        }
    }
}
