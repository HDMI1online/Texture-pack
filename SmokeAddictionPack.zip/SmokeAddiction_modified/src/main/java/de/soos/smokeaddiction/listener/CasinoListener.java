package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.CasinoManager;
import de.soos.smokeaddiction.model.CasinoType;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Steuert die Interaktion mit Casino-Blocks:
 *   - Rechtsklick auf registrierten Casino-Block → öffnet GUI
 *   - Klick auf Spin-Button im GUI → triggert Spin
 *   - GUI-Klicks auf andere Slots werden gecancelt
 *   - BlockBreakEvent auf Casino-Block wird gecancelt (außer für OP)
 */
public class CasinoListener implements Listener {

    private final SmokeAddictionPlugin plugin;

    public CasinoListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;

        Location bloc = e.getClickedBlock().getLocation();
        CasinoType type = plugin.getCasinoRegistry().get(bloc);
        if (type == null) return;

        e.setCancelled(true);
        plugin.getCasinoManager().openGui(e.getPlayer(), type, bloc);
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        CasinoManager.ActiveSession s = plugin.getCasinoManager().getSession(p);
        if (s == null) return;
        if (e.getView().getTopInventory() != s.inv) return;

        // Klicks im Spieler-Inventar nicht canceln (sonst kann er nichts mehr machen)
        if (e.getClickedInventory() != s.inv) return;

        e.setCancelled(true);

        // Spin-Button erkennen
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null) return;
        ItemMeta m = clicked.getItemMeta();
        if (m == null) return;
        Byte spin = m.getPersistentDataContainer().get(
                new org.bukkit.NamespacedKey(plugin, "casino_spin"),
                org.bukkit.persistence.PersistentDataType.BYTE);
        if (spin == null || spin != 1) return;

        plugin.getCasinoManager().handleSpin(p);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        plugin.getCasinoManager().closeSession(p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Location loc = e.getBlock().getLocation();
        if (!plugin.getCasinoRegistry().isCasino(loc)) return;
        if (e.getPlayer().isOp()) return; // OPs dürfen entfernen
        e.setCancelled(true);
        e.getPlayer().sendMessage(net.kyori.adventure.text.Component.text(
                "Casino-Automaten sind unzerstörbar.",
                net.kyori.adventure.text.format.NamedTextColor.RED));
    }
}
