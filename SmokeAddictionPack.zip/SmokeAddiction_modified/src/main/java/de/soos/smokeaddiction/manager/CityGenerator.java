package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.Ladder;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Generiert eine City: 5×4 = 20 Hochhäuser auf einem Grid, mit Straßen drumrum,
 * einer umlaufenden Stadtmauer mit vier Toren, Balkonen an den Hochhäusern,
 * einem beleuchteten Brunnen-Stadtplatz, und einem zugewiesenen Villager-Trader
 * pro Hochhaus.
 *
 * Generierung läuft asynchron über mehrere Ticks: pro Tick werden N Block-Operationen
 * abgearbeitet, damit der Server nicht laggt.
 *
 * Layout (Grid-Koordinaten, Spacing 16):
 *   Hochhaus (7×7 footprint, 3 stockwerke à 5 Blöcke = 15 Blöcke hoch, mit Balkon
 *   ab dem 1. OG)
 *   Spacing 16 zwischen Hochhauszentren
 *   5 Spalten × 4 Reihen = 20 Hochhäuser
 *   Gesamtgröße der City: ~80×64 Blöcke + 8 Block Rand, umschlossen von einer
 *   4 Blöcke hohen Stadtmauer mit vier Toren (eines davon das beschilderte Haupttor)
 */
public class CityGenerator {

    public static final int GRID_COLS = 5;
    public static final int GRID_ROWS = 4;
    public static final int GRID_SPACING = 16;
    public static final int BUILDING_FOOTPRINT = 7;       // 7x7
    public static final int FLOORS = 3;
    public static final int FLOOR_HEIGHT = 5;             // 4 inside + 1 ceiling
    public static final int BUILDING_HEIGHT = FLOORS * FLOOR_HEIGHT;

    public static final int WALL_HEIGHT = 4;              // Stadtmauer-Höhe
    public static final int GATE_HALF_WIDTH = 2;           // Tor ist 5 Blöcke breit

    public static final int OPS_PER_TICK = 800;           // wie viele setBlocks pro Tick

    private final SmokeAddictionPlugin plugin;
    private final TraderManager traderManager;

    public CityGenerator(SmokeAddictionPlugin plugin, TraderManager tm) {
        this.plugin = plugin;
        this.traderManager = tm;
    }

    /**
     * Plant und baut eine Stadt zentriert um das gegebene Block-Center.
     * Y wird automatisch auf Durchschnittshöhe der Region gesetzt.
     */
    public void buildCity(Location centerHint) {
        World w = centerHint.getWorld();
        if (w == null) return;
        int cx = centerHint.getBlockX();
        int cz = centerHint.getBlockZ();

        // Durchschnittshöhe um das Stadt-Zentrum bestimmen
        int totalWidth  = GRID_COLS * GRID_SPACING + 8;
        int totalDepth  = GRID_ROWS * GRID_SPACING + 8;
        int xMin = cx - totalWidth / 2;
        int xMax = cx + totalWidth / 2;
        int zMin = cz - totalDepth / 2;
        int zMax = cz + totalDepth / 2;

        long heightSum = 0;
        int  samples = 0;
        for (int sx = xMin; sx <= xMax; sx += 8) {
            for (int sz = zMin; sz <= zMax; sz += 8) {
                heightSum += w.getHighestBlockYAt(sx, sz);
                samples++;
            }
        }
        int baseY = samples > 0 ? (int) (heightSum / samples) : 64;

        Location origin = new Location(w, xMin, baseY, zMin);
        Location center = new Location(w, cx, baseY, cz);

        // Gebauter Op-Plan (sequenziell aus mehreren Phasen)
        Deque<Runnable> ops = new ArrayDeque<>();

        // Phase 1: Plateau anlegen (Stein-Ground)
        layPlateauOps(ops, w, xMin, xMax, zMin, zMax, baseY);

        // Phase 2: Straßen
        layStreetsOps(ops, w, xMin, xMax, zMin, zMax, baseY);

        // Phase 2.5: Stadtmauer mit vier Toren (eines davon das Haupttor mit Schild)
        layWallOps(ops, w, xMin, xMax, zMin, zMax, baseY, cx, cz);

        // Phase 3: Hochhäuser
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        // Trader-Liste: 20 Slots, gemischt
        // 1 von jedem Spezialisten + füllen mit Arbeitslosen
        List<String> assignments = new java.util.ArrayList<>(Arrays.asList(
                "armorer", "weaponsmith", "trim", "firework",
                "vape_trader", "tabak", "beverage",
                // Restliche 13 Slots: arbeitslose und Bonus-Spezialisten
                "unemployed", "unemployed", "unemployed", "unemployed", "unemployed",
                "unemployed", "unemployed", "unemployed", "unemployed", "unemployed",
                "unemployed", "unemployed", "unemployed"
        ));
        Collections.shuffle(assignments, rnd);

        // Hochhausfarben (innenstadt-typische Beton-Farben)
        Material[] palette = {
                Material.WHITE_CONCRETE, Material.LIGHT_GRAY_CONCRETE,
                Material.GRAY_CONCRETE,  Material.CYAN_CONCRETE,
                Material.BLUE_CONCRETE,  Material.LIGHT_BLUE_CONCRETE,
                Material.BROWN_CONCRETE, Material.RED_CONCRETE
        };

        int slot = 0;
        for (int row = 0; row < GRID_ROWS; row++) {
            for (int col = 0; col < GRID_COLS; col++) {
                int bx = xMin + 4 + col * GRID_SPACING;
                int bz = zMin + 4 + row * GRID_SPACING;
                Material mat = palette[rnd.nextInt(palette.length)];
                String trader = assignments.get(slot);
                buildHouseOps(ops, w, bx, baseY + 1, bz, mat, trader);
                slot++;
            }
        }

        // Phase 4: Stadtplatz mit Glocke
        layCenterOps(ops, w, cx, baseY + 1, cz);

        // Phase 5: Casino-Reihe (5 Automaten an einer Plaza-Kante, je 2 Block Abstand)
        layCasinoOps(ops, w, cx, baseY + 1, cz);

        // Asynchron abarbeiten
        new BukkitRunnable() {
            @Override
            public void run() {
                int done = 0;
                while (done < OPS_PER_TICK && !ops.isEmpty()) {
                    Runnable r = ops.poll();
                    try { r.run(); } catch (Exception ex) {
                        plugin.getLogger().warning("City-Bau-Fehler: " + ex.getMessage());
                    }
                    done++;
                }
                if (ops.isEmpty()) {
                    plugin.getCityRegistry().register(center);
                    plugin.getLogger().info("City fertiggestellt bei "
                            + cx + "/" + baseY + "/" + cz);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // ============================================================
    // Phase 1: Plateau
    // ============================================================
    private void layPlateauOps(Deque<Runnable> ops, World w,
                               int xMin, int xMax, int zMin, int zMax, int baseY) {
        for (int x = xMin; x <= xMax; x++) {
            for (int z = zMin; z <= zMax; z++) {
                final int fx = x, fz = z;
                ops.add(() -> {
                    Block top = w.getBlockAt(fx, baseY, fz);
                    // Vegetation/Bäume oberhalb wegräumen
                    for (int dy = 1; dy <= 4; dy++) {
                        Block above = w.getBlockAt(fx, baseY + dy, fz);
                        Material m = above.getType();
                        if (m == Material.AIR || m == Material.WATER) continue;
                        if (m.name().contains("LEAVES") || m.name().contains("LOG")
                                || m.name().contains("FLOWER") || m == Material.GRASS_BLOCK
                                || m.name().contains("BUSH") || m.name().contains("SAPLING")
                                || m == Material.SHORT_GRASS || m == Material.TALL_GRASS
                                || m == Material.FERN || m == Material.LARGE_FERN) {
                            above.setType(Material.AIR, false);
                        }
                    }
                    // Plateau-Block auf baseY setzen
                    top.setType(Material.STONE, false);
                    // Nach unten auffüllen bis zu einem festen Block (Höhlen, Wasser etc.)
                    for (int dy = 1; dy <= 16; dy++) {
                        Block below = w.getBlockAt(fx, baseY - dy, fz);
                        Material bm = below.getType();
                        if (bm == Material.AIR || bm == Material.WATER
                                || bm == Material.LAVA || bm == Material.CAVE_AIR
                                || bm == Material.VOID_AIR) {
                            below.setType(Material.STONE, false);
                        } else {
                            break; // fester Block gefunden, kein weiteres Auffüllen nötig
                        }
                    }
                });
            }
        }
    }

    // ============================================================
    // Phase 2: Straßen
    // ============================================================
    private void layStreetsOps(Deque<Runnable> ops, World w,
                               int xMin, int xMax, int zMin, int zMax, int baseY) {
        // Über das ganze Plateau Steinplatten als "Bürgersteig", drüber an
        // den Spalten Polierten Andesit als "Straße"
        for (int x = xMin; x <= xMax; x++) {
            for (int z = zMin; z <= zMax; z++) {
                final int fx = x, fz = z;
                int colIdx = (fx - xMin - 4);
                int rowIdx = (fz - zMin - 4);
                // Straßenraster: zwischen den Hochhaus-Footprints
                boolean inHouseCol = false;
                for (int c = 0; c < GRID_COLS; c++) {
                    int center = 4 + c * GRID_SPACING;
                    if (Math.abs((fx - xMin) - center) <= BUILDING_FOOTPRINT / 2) {
                        inHouseCol = true; break;
                    }
                }
                boolean inHouseRow = false;
                for (int r = 0; r < GRID_ROWS; r++) {
                    int center = 4 + r * GRID_SPACING;
                    if (Math.abs((fz - zMin) - center) <= BUILDING_FOOTPRINT / 2) {
                        inHouseRow = true; break;
                    }
                }
                Material road;
                if (inHouseCol && inHouseRow) {
                    // Hochhaus-Boden – wird beim Hauserbau überschrieben
                    road = Material.SMOOTH_STONE;
                } else if (inHouseCol || inHouseRow) {
                    road = Material.POLISHED_ANDESITE;
                } else {
                    road = Material.STONE_BRICKS;
                }
                final Material froad = road;
                ops.add(() -> w.getBlockAt(fx, baseY, fz).setType(froad, false));
            }
        }
        // Straßenlaternen an Kreuzungen
        for (int c = 0; c < GRID_COLS - 1; c++) {
            for (int r = 0; r < GRID_ROWS - 1; r++) {
                int lx = xMin + 4 + c * GRID_SPACING + GRID_SPACING / 2;
                int lz = zMin + 4 + r * GRID_SPACING + GRID_SPACING / 2;
                final int flx = lx, flz = lz;
                ops.add(() -> {
                    w.getBlockAt(flx, baseY + 1, flz).setType(Material.OAK_FENCE, false);
                    w.getBlockAt(flx, baseY + 2, flz).setType(Material.OAK_FENCE, false);
                    w.getBlockAt(flx, baseY + 3, flz).setType(Material.OAK_FENCE, false);
                    w.getBlockAt(flx, baseY + 4, flz).setType(Material.LANTERN, false);
                });
            }
        }
    }

    // ============================================================
    // Phase 2.5: Stadtmauer mit Toren
    // ============================================================
    /**
     * Baut eine 4 Blöcke hohe Mauer um das gesamte Stadt-Rechteck mit Zinnen
     * (jeder 2. Block bekommt einen Mauer-Aufsatz). An allen vier Seiten gibt es
     * ein 5 Blöcke breites Tor, ausgerichtet auf die jeweils mittlere Innenstraße
     * (passt exakt zum Straßenraster). Das Südtor (z = zMax) ist das Haupttor mit
     * einem Begrüßungsschild.
     */
    private void layWallOps(Deque<Runnable> ops, World w,
                            int xMin, int xMax, int zMin, int zMax, int baseY,
                            int cx, int cz) {
        buildNSWall(ops, w, xMin, xMax, zMin, baseY, cx, false);
        buildNSWall(ops, w, xMin, xMax, zMax, baseY, cx, true);
        buildEWWall(ops, w, zMin, zMax, xMin, baseY, cz, false);
        buildEWWall(ops, w, zMin, zMax, xMax, baseY, cz, false);
    }

    /** Mauerlinie entlang X (konstantes Z) mit Tor bei x = gateX. */
    private void buildNSWall(Deque<Runnable> ops, World w, int xMin, int xMax, int z,
                             int baseY, int gateX, boolean mainGate) {
        for (int x = xMin; x <= xMax; x++) {
            final int fx = x;
            final boolean isGate = Math.abs(x - gateX) <= GATE_HALF_WIDTH;
            ops.add(() -> {
                if (isGate) {
                    for (int dy = 1; dy < WALL_HEIGHT; dy++) {
                        w.getBlockAt(fx, baseY + dy, z).setType(Material.AIR, false);
                    }
                    w.getBlockAt(fx, baseY + WALL_HEIGHT, z).setType(Material.STONE_BRICKS, false);
                } else {
                    for (int dy = 1; dy < WALL_HEIGHT; dy++) {
                        w.getBlockAt(fx, baseY + dy, z).setType(Material.STONE_BRICKS, false);
                    }
                    if (Math.floorMod(fx, 2) == 0) {
                        w.getBlockAt(fx, baseY + WALL_HEIGHT, z).setType(Material.STONE_BRICK_WALL, false);
                    }
                }
            });
        }
        buildGatePosts(ops, w, gateX, z, baseY, true);
        if (mainGate) buildGateSign(ops, w, gateX, z, baseY);
    }

    /** Mauerlinie entlang Z (konstantes X) mit Tor bei z = gateZ. */
    private void buildEWWall(Deque<Runnable> ops, World w, int zMin, int zMax, int x,
                             int baseY, int gateZ, boolean mainGate) {
        for (int z = zMin; z <= zMax; z++) {
            final int fz = z;
            final boolean isGate = Math.abs(z - gateZ) <= GATE_HALF_WIDTH;
            ops.add(() -> {
                if (isGate) {
                    for (int dy = 1; dy < WALL_HEIGHT; dy++) {
                        w.getBlockAt(x, baseY + dy, fz).setType(Material.AIR, false);
                    }
                    w.getBlockAt(x, baseY + WALL_HEIGHT, fz).setType(Material.STONE_BRICKS, false);
                } else {
                    for (int dy = 1; dy < WALL_HEIGHT; dy++) {
                        w.getBlockAt(x, baseY + dy, fz).setType(Material.STONE_BRICKS, false);
                    }
                    if (Math.floorMod(fz, 2) == 0) {
                        w.getBlockAt(x, baseY + WALL_HEIGHT, fz).setType(Material.STONE_BRICK_WALL, false);
                    }
                }
            });
        }
        buildGatePosts(ops, w, x, gateZ, baseY, false);
    }

    /** Zwei volle Torpfosten mit Laterne obenauf, links und rechts vom Tor. */
    private void buildGatePosts(Deque<Runnable> ops, World w, int gateAxisCoord, int fixedCoord,
                                int baseY, boolean alongX) {
        int post1 = gateAxisCoord - GATE_HALF_WIDTH - 1;
        int post2 = gateAxisCoord + GATE_HALF_WIDTH + 1;
        for (int p : new int[]{post1, post2}) {
            final int fp = p;
            ops.add(() -> {
                int x = alongX ? fp : fixedCoord;
                int z = alongX ? fixedCoord : fp;
                for (int dy = 1; dy <= WALL_HEIGHT; dy++) {
                    w.getBlockAt(x, baseY + dy, z).setType(Material.STONE_BRICKS, false);
                }
                w.getBlockAt(x, baseY + WALL_HEIGHT + 1, z).setType(Material.LANTERN, false);
            });
        }
    }

    /** Begrüßungsschild am Haupttor (Südseite), steht auf dem Boden direkt außerhalb der Mauer. */
    private void buildGateSign(Deque<Runnable> ops, World w, int gateX, int z, int baseY) {
        // Schild liegt außerhalb der Stadt (z + 1, da Haupttor an zMax liegt → außen ist +Z)
        final int signX = gateX - GATE_HALF_WIDTH + 1;
        final int signZ = z + 1;
        ops.add(() -> {
            Block signBlock = w.getBlockAt(signX, baseY + 1, signZ);
            signBlock.setType(Material.OAK_SIGN, false);
            BlockData bd = signBlock.getBlockData();
            if (bd instanceof org.bukkit.block.data.Rotatable rot) {
                rot.setRotation(BlockFace.SOUTH);
                signBlock.setBlockData(rot, false);
            }
            if (signBlock.getState() instanceof org.bukkit.block.Sign sign) {
                org.bukkit.block.sign.SignSide side = sign.getSide(org.bukkit.block.sign.Side.FRONT);
                side.line(0, net.kyori.adventure.text.Component.text("§6§l~ Stadttor ~"));
                side.line(1, net.kyori.adventure.text.Component.text("§7Willkommen!"));
                sign.update();
            }
        });
    }

    // ============================================================
    // Phase 3: Hochhaus + Trader
    // ============================================================
    /**
     * Baut ein Hochhaus mit Mittelpunkt (cx, cz) auf groundY.
     * groundY ist die erste Innenraum-Reihe (also baseY + 1).
     */
    private void buildHouseOps(Deque<Runnable> ops, World w, int cx, int groundY, int cz,
                               Material wallMat, String traderType) {
        int half = BUILDING_FOOTPRINT / 2;

        // Boden Erdgeschoss (groundY selbst – wird sonst von der Straße/Plateau belegt,
        // aber da baseY der Plateau-Block ist und groundY = baseY+1, liegt hier Luft)
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                final int fx = cx + dx, fz = cz + dz;
                ops.add(() -> w.getBlockAt(fx, groundY, fz).setType(Material.SMOOTH_STONE, false));
            }
        }

        // Wände + Stockwerke
        for (int floor = 0; floor < FLOORS; floor++) {
            int fy = groundY + floor * FLOOR_HEIGHT;

            // Boden (außer Erdgeschoss – das ist die Straße/Plateau)
            if (floor > 0) {
                for (int dx = -half; dx <= half; dx++) {
                    for (int dz = -half; dz <= half; dz++) {
                        final int fx = cx + dx, fz = cz + dz, ffy = fy;
                        ops.add(() -> w.getBlockAt(fx, ffy, fz).setType(Material.SMOOTH_STONE, false));
                    }
                }
            }

            // Wände (Außenring) für das Stockwerk – 4 Blöcke hoch
            for (int dy = (floor == 0 ? 1 : 1); dy < FLOOR_HEIGHT; dy++) {
                for (int dx = -half; dx <= half; dx++) {
                    for (int dz = -half; dz <= half; dz++) {
                        if (Math.abs(dx) != half && Math.abs(dz) != half) continue;
                        final int fx = cx + dx, fz = cz + dz, fy_ = fy + dy;
                        // Fenster: in Höhe 2 in der Mitte der Wand
                        boolean isWindow = (dy == 2)
                                && ((Math.abs(dx) == half && Math.abs(dz) <= 1)
                                 || (Math.abs(dz) == half && Math.abs(dx) <= 1));
                        // Tür-Position: vorne (dz == half) Mitte, nur Erdgeschoss
                        boolean isDoorTop = floor == 0 && dz == half && dx == 0
                                && (dy == 1 || dy == 2);
                        // Balkontür: ab 1. OG, Mitte der Südwand, untere Hälfte des
                        // Fensters wird ebenfalls zu Glas → 2 Blöcke hohe Balkontür
                        boolean isBalconyDoor = floor > 0 && dy == 1 && dx == 0 && dz == half;
                        if (isDoorTop) {
                            // Wird unten als Tür gesetzt
                            continue;
                        }
                        if (isWindow || isBalconyDoor) {
                            ops.add(() -> w.getBlockAt(fx, fy_, fz).setType(Material.GLASS, false));
                        } else {
                            ops.add(() -> w.getBlockAt(fx, fy_, fz).setType(wallMat, false));
                        }
                    }
                }
            }

            // Balkon: ab 1. OG, vor der Balkontür auf der Südseite, mit Geländer
            if (floor > 0) {
                final int ffy = fy;
                final int balconyZ = cz + half + 1;
                for (int dx = -1; dx <= 1; dx++) {
                    final int fx = cx + dx;
                    ops.add(() -> w.getBlockAt(fx, ffy, balconyZ).setType(Material.SMOOTH_STONE_SLAB, false));
                    ops.add(() -> w.getBlockAt(fx, ffy + 1, balconyZ).setType(Material.OAK_FENCE, false));
                }
                final int leftX = cx - 1, rightX = cx + 1, doorZ = cz + half;
                ops.add(() -> w.getBlockAt(leftX, ffy + 1, doorZ).setType(Material.OAK_FENCE, false));
                ops.add(() -> w.getBlockAt(rightX, ffy + 1, doorZ).setType(Material.OAK_FENCE, false));
            }
        }

        // Dach (oberste Decke)
        int roofY = groundY + FLOORS * FLOOR_HEIGHT;
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                final int fx = cx + dx, fz = cz + dz;
                ops.add(() -> w.getBlockAt(fx, roofY, fz).setType(Material.SMOOTH_STONE_SLAB, false));
            }
        }

        // Tür im Erdgeschoss (Eingang vorne, dz = +half)
        final int doorX = cx, doorY = groundY + 1, doorZ = cz + half;
        ops.add(() -> {
            Block bottom = w.getBlockAt(doorX, doorY, doorZ);
            Block top    = w.getBlockAt(doorX, doorY + 1, doorZ);
            bottom.setType(Material.OAK_DOOR, false);
            top.setType(Material.OAK_DOOR, false);
            // BlockData für die Tür-Hälften
            BlockData bd = bottom.getBlockData();
            if (bd instanceof Door door) {
                door.setHalf(org.bukkit.block.data.Bisected.Half.BOTTOM);
                door.setFacing(BlockFace.SOUTH);
                bottom.setBlockData(door, false);
            }
            BlockData td = top.getBlockData();
            if (td instanceof Door door) {
                door.setHalf(org.bukkit.block.data.Bisected.Half.TOP);
                door.setFacing(BlockFace.SOUTH);
                top.setBlockData(door, false);
            }
        });

        // Fassaden-Laternen links und rechts vom Eingang, direkt auf der Straße
        final int lampZ = doorZ + 1;
        for (int lx : new int[]{cx - 2, cx + 2}) {
            final int flx = lx;
            ops.add(() -> {
                w.getBlockAt(flx, groundY, lampZ).setType(Material.OAK_FENCE, false);
                w.getBlockAt(flx, groundY + 1, lampZ).setType(Material.LANTERN, false);
            });
        }

        // Leiter durchs ganze Hochhaus (in einer Ecke, an der West-Wand)
        // Position: Westen (dx = -half), Mitte (dz = 0)
        int ladderX = cx - half + 1; // ein Block innen vor der Wand
        int ladderZ = cz;
        // Löcher müssen NACH allen Böden gesetzt werden – separater Pass am Ende
        Deque<Runnable> laderOps = new ArrayDeque<>();
        // Leiter lückenlos von EG-Boden+1 bis unterm Dach
        int ladderBottom = groundY + 1; // unterster Leiterblock (Boden EG ist groundY)
        int ladderTop    = groundY + FLOORS * FLOOR_HEIGHT - 1; // oberster (unter Dach)
        for (int ly = ladderBottom; ly <= ladderTop; ly++) {
            final int fx = ladderX, fz = ladderZ, fy_ = ly;
            ops.add(() -> {
                Block b = w.getBlockAt(fx, fy_, fz);
                b.setType(Material.LADDER, false);
                BlockData bd = b.getBlockData();
                if (bd instanceof Ladder ladder) {
                    ladder.setFacing(BlockFace.EAST); // Leiter "klebt" an West-Wand → faces east
                    b.setBlockData(ladder, false);
                }
            });
        }
        // Loch in jeder Stockwerk-Decke über der Leiter – danach Leiter neu setzen
        // (Boden des nächsten Stockwerks wird erst nach ops gesetzt und würde die Leiter killen)
        for (int floor = 0; floor < FLOORS - 1; floor++) {
            int holeY = groundY + (floor + 1) * FLOOR_HEIGHT;
            final int fx = ladderX, fz = ladderZ;
            final int hy = holeY;
            laderOps.add(() -> {
                Block b = w.getBlockAt(fx, hy, fz);
                b.setType(Material.LADDER, false);
                BlockData bd = b.getBlockData();
                if (bd instanceof Ladder lad) {
                    lad.setFacing(BlockFace.EAST);
                    b.setBlockData(lad, false);
                }
            });
        }
        // Loch-Ops ans Ende anhängen (nach allen Böden)
        ops.addAll(laderOps);

        // Innenausstattung + Trader pro Stockwerk
        // Wir spawnen Trader nur im Erdgeschoss (1 pro Hochhaus), in einem Zaun-Käfig
        ops.add(() -> {
            // Beleuchtung
            for (int floor = 0; floor < FLOORS; floor++) {
                int fy = groundY + floor * FLOOR_HEIGHT + FLOOR_HEIGHT - 1;
                w.getBlockAt(cx, fy, cz).setType(Material.GLOWSTONE, false);
            }
            // Zaun-Käfig im Erdgeschoss vor der Hinterwand (Norden, dz = -half + 1)
            int penZ = cz - half + 1;
            int penX = cx;
            int penY = groundY + 1;
            // Vorderseite (Süden) des Käfigs auf 3 Blöcke breit
            w.getBlockAt(penX - 1, penY, penZ + 1).setType(Material.OAK_FENCE, false);
            w.getBlockAt(penX + 1, penY, penZ + 1).setType(Material.OAK_FENCE, false);
            // Mitte: Eingang oder offen lassen für Trade-Click
            w.getBlockAt(penX, penY, penZ + 1).setType(Material.OAK_FENCE_GATE, false);
            // Seitenfences (links + rechts)
            w.getBlockAt(penX - 1, penY, penZ).setType(Material.OAK_FENCE, false);
            w.getBlockAt(penX + 1, penY, penZ).setType(Material.OAK_FENCE, false);
            // Hinten (gegen Wand) bleibt offen, weil Wand schon da ist

            // Counter (Stufenstein als "Theke")
            w.getBlockAt(penX, penY, penZ + 1).setType(Material.OAK_FENCE_GATE, false);

            // Villager-Spawn IN dem Käfig
            Location spawn = new Location(w, penX + 0.5, penY, penZ + 0.5);
            spawnTraderByType(spawn, traderType);
        });
    }

    private void spawnTraderByType(Location loc, String type) {
        switch (type) {
            case "armorer":     traderManager.spawnArmorer(loc); break;
            case "weaponsmith": traderManager.spawnWeaponsmith(loc); break;
            case "trim":        traderManager.spawnTrimSeller(loc); break;
            case "firework":    traderManager.spawnFireworkSeller(loc); break;
            case "vape_trader": traderManager.spawnVapeTrader(loc); break;
            case "tabak":       traderManager.spawnCigaretteSeller(loc); break;
            case "beverage":    traderManager.spawnBeverageSeller(loc); break;
            case "unemployed":
            default:            traderManager.spawnUnemployed(loc); break;
        }
    }

    // ============================================================
    // Phase 4: Stadtplatz (Glocke, Brunnen, Aussichtsturm mit Leitern, Bänke, Beleuchtung)
    // ============================================================
    private void layCenterOps(Deque<Runnable> ops, World w, int cx, int groundY, int cz) {
        ops.add(() -> {
            // Großes 7x7 Plaza mit polished_andesite (außen) und stone_bricks (Mitte)
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    Block floor = w.getBlockAt(cx + dx, groundY - 1, cz + dz);
                    boolean inner = Math.abs(dx) <= 1 && Math.abs(dz) <= 1;
                    floor.setType(inner ? Material.STONE_BRICKS : Material.POLISHED_ANDESITE, false);
                    // Über dem Plaza alles weg räumen
                    for (int dy = 0; dy <= 4; dy++) {
                        Block above = w.getBlockAt(cx + dx, groundY + dy, cz + dz);
                        if (above.getType() != Material.AIR) above.setType(Material.AIR, false);
                    }
                }
            }

            // Brunnen-Becken (3x3): Ecken leuchten (Seelaterne), Kanten Mauerring,
            // Mitte Wasser mit einer Seelaterne darunter für einen Glüheffekt von unten.
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block ring = w.getBlockAt(cx + dx, groundY, cz + dz);
                    boolean corner = Math.abs(dx) == 1 && Math.abs(dz) == 1;
                    boolean edge   = (Math.abs(dx) == 1) ^ (Math.abs(dz) == 1);
                    if (corner) {
                        ring.setType(Material.SEA_LANTERN, false);
                    } else if (edge) {
                        ring.setType(Material.STONE_BRICK_WALL, false);
                    } else {
                        // Mittlerer Block: Wasser, mit Glühstein/Seelaterne als Boden darunter
                        ring.setType(Material.WATER, false);
                        w.getBlockAt(cx + dx, groundY - 1, cz + dz).setType(Material.SEA_LANTERN, false);
                    }
                }
            }

            // Aussichtsturm: 4 Block hohe Säule MIT Glocke obenauf MIT Leiter
            // Position: Brunnen-Mitte selbst, Säule schießt über das Wasser
            // → Wir bauen die Säule 1 Block neben dem Brunnen, an Position (cx, groundY+1..+5)
            // Stattdessen: Glocke in 5 Block Höhe auf einer Säule die NICHT im Wasser steht.
            // Säulen-Position: (cx+2, cz+2) - Ecke des Plaza
            int towerX = cx + 2, towerZ = cz + 2;
            for (int dy = 0; dy < 6; dy++) {
                Block t = w.getBlockAt(towerX, groundY + dy, towerZ);
                if (dy == 0) t.setType(Material.STONE_BRICKS, false);
                else if (dy < 5) t.setType(Material.POLISHED_ANDESITE, false);
                else t.setType(Material.BELL, false); // Glocke ganz oben
            }
            // Leiter an der Tower-Säule (Ostseite, faces west)
            for (int dy = 1; dy < 5; dy++) {
                Block lad = w.getBlockAt(towerX + 1, groundY + dy, towerZ);
                lad.setType(Material.LADDER, false);
                BlockData bd = lad.getBlockData();
                if (bd instanceof Ladder ladder) {
                    ladder.setFacing(BlockFace.EAST);
                    lad.setBlockData(ladder, false);
                }
            }
            // Auf dem Tower-Top eine kleine Plattform aus Slabs (1 Block über die Glocke)
            Block topSlab = w.getBlockAt(towerX, groundY + 6, towerZ);
            topSlab.setType(Material.SMOOTH_STONE_SLAB, false);

            // Vier Bänke (Treppen-Stufen) drumrum, je auf den Plaza-Kanten
            // Süd-Bank: faces north
            for (int dx = -2; dx <= 2; dx++) {
                Block bench = w.getBlockAt(cx + dx, groundY, cz + 3);
                if (bench.getType() != Material.STONE_BRICK_WALL) {
                    bench.setType(Material.OAK_STAIRS, false);
                    BlockData bd = bench.getBlockData();
                    if (bd instanceof org.bukkit.block.data.type.Stairs s) {
                        s.setFacing(BlockFace.NORTH);
                        bench.setBlockData(s, false);
                    }
                }
            }
            // Nord-Bank: faces south
            for (int dx = -2; dx <= 2; dx++) {
                Block bench = w.getBlockAt(cx + dx, groundY, cz - 3);
                if (bench.getType() != Material.STONE_BRICK_WALL) {
                    bench.setType(Material.OAK_STAIRS, false);
                    BlockData bd = bench.getBlockData();
                    if (bd instanceof org.bukkit.block.data.type.Stairs s) {
                        s.setFacing(BlockFace.SOUTH);
                        bench.setBlockData(s, false);
                    }
                }
            }
            // West-Bank: faces east
            for (int dz = -2; dz <= 2; dz++) {
                Block bench = w.getBlockAt(cx - 3, groundY, cz + dz);
                if (bench.getType() != Material.STONE_BRICK_WALL) {
                    bench.setType(Material.OAK_STAIRS, false);
                    BlockData bd = bench.getBlockData();
                    if (bd instanceof org.bukkit.block.data.type.Stairs s) {
                        s.setFacing(BlockFace.EAST);
                        bench.setBlockData(s, false);
                    }
                }
            }
            // Ost-Bank: faces west
            for (int dz = -2; dz <= 2; dz++) {
                Block bench = w.getBlockAt(cx + 3, groundY, cz + dz);
                if (bench.getType() != Material.STONE_BRICK_WALL) {
                    bench.setType(Material.OAK_STAIRS, false);
                    BlockData bd = bench.getBlockData();
                    if (bd instanceof org.bukkit.block.data.type.Stairs s) {
                        s.setFacing(BlockFace.WEST);
                        bench.setBlockData(s, false);
                    }
                }
            }

            // Vier Eck-Lampen (Fence + Lantern) an den Plaza-Ecken
            int[][] corners = {{-3, -3}, {3, -3}, {-3, 3}, {3, 3}};
            for (int[] corner : corners) {
                int lx = cx + corner[0], lz = cz + corner[1];
                w.getBlockAt(lx, groundY, lz).setType(Material.OAK_FENCE, false);
                w.getBlockAt(lx, groundY + 1, lz).setType(Material.OAK_FENCE, false);
                w.getBlockAt(lx, groundY + 2, lz).setType(Material.OAK_FENCE, false);
                w.getBlockAt(lx, groundY + 3, lz).setType(Material.LANTERN, false);
            }

            // Blumen-Akzente in den Brunnen-Ecken (Plaza-Innenecken)
            int[][] flowerSpots = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}};
            for (int[] f : flowerSpots) {
                Block under = w.getBlockAt(cx + f[0] * 2, groundY - 1, cz + f[1] * 2);
                if (under.getType() == Material.POLISHED_ANDESITE) {
                    Block flower = w.getBlockAt(cx + f[0] * 2, groundY, cz + f[1] * 2);
                    Material[] flowers = {Material.POPPY, Material.DANDELION, Material.AZURE_BLUET,
                                         Material.OXEYE_DAISY, Material.CORNFLOWER};
                    flower.setType(flowers[Math.abs(f[0] + f[1] * 3) % flowers.length], false);
                }
            }
        });
    }

    // ============================================================
    // Phase 5: Casino-Reihe (5 Automaten an einer Plaza-Kante)
    // ============================================================
    private void layCasinoOps(Deque<Runnable> ops, World w, int cx, int groundY, int cz) {
        ops.add(() -> {
            de.soos.smokeaddiction.model.CasinoType[] types =
                    de.soos.smokeaddiction.model.CasinoType.values();

            // 5 Automaten in einer Linie auf cz - 6 (Nordseite des Plaza,
            // außerhalb des Plaza-Rings)
            int row = cz - 6;
            int startX = cx - 4; // -4, -2, 0, 2, 4 → 5 Automaten

            for (int i = 0; i < types.length; i++) {
                int bx = startX + i * 2;
                int by = groundY;
                int bz = row;

                // Boden (1 Block unter dem Casino-Block) als Polished Andesite
                w.getBlockAt(bx, by - 1, bz).setType(org.bukkit.Material.POLISHED_ANDESITE, false);

                // Bereich darüber freiräumen (3 Block hoch)
                for (int dy = 0; dy < 4; dy++) {
                    w.getBlockAt(bx, by + dy, bz).setType(org.bukkit.Material.AIR, false);
                }

                // Casino-Block setzen
                org.bukkit.block.Block casinoBlock = w.getBlockAt(bx, by, bz);
                casinoBlock.setType(types[i].blockMaterial, false);
                plugin.getCasinoRegistry().register(casinoBlock.getLocation(), types[i]);

                // Schild davor (Süd-Seite, Spieler steht im Plaza und liest's)
                org.bukkit.block.Block signBlock = w.getBlockAt(bx, by, bz + 1);
                signBlock.setType(org.bukkit.Material.OAK_WALL_SIGN, false);
                org.bukkit.block.data.BlockData bd = signBlock.getBlockData();
                if (bd instanceof org.bukkit.block.data.type.WallSign ws) {
                    ws.setFacing(org.bukkit.block.BlockFace.SOUTH);
                    signBlock.setBlockData(ws, false);
                }
                if (signBlock.getState() instanceof org.bukkit.block.Sign sign) {
                    org.bukkit.block.sign.SignSide side = sign.getSide(
                            org.bukkit.block.sign.Side.FRONT);
                    side.line(0, net.kyori.adventure.text.Component.text("§6§l[CASINO]"));
                    side.line(1, net.kyori.adventure.text.Component.text("§e" + types[i].displayName));
                    side.line(2, net.kyori.adventure.text.Component.text("§7Rechtsklick"));
                    side.line(3, net.kyori.adventure.text.Component.text("§7zum Spielen"));
                    sign.update();
                }

                // Lampe oben drauf für Sichtbarkeit
                w.getBlockAt(bx, by + 1, bz).setType(org.bukkit.Material.SEA_LANTERN, false);
            }
        });
    }
}
