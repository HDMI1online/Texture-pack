package de.soos.smokeaddiction.model;

import org.bukkit.Color;

/**
 * Verschiedene Elfbar-Sorten/Farben. Genutzt für Anzeigenamen und Item-Tönung.
 */
public enum VapeFlavor {

    BLUE_RAZZ("Blue Razz",         Color.fromRGB( 30, 100, 230)),
    WATERMELON("Watermelon",        Color.fromRGB(230,  60,  90)),
    MANGO_ICE("Mango Ice",         Color.fromRGB(240, 180,  60)),
    GRAPE("Grape",             Color.fromRGB(140,  60, 200)),
    APPLE_PEACH("Apple Peach",       Color.fromRGB(180, 230, 100)),
    COTTON_CANDY("Cotton Candy",      Color.fromRGB(250, 130, 200)),
    MENTHOL("Menthol",           Color.fromRGB(200, 240, 230)),
    VOZOL_40K("Vozol 40k",          Color.fromRGB(240, 150,  40)),
    RANDM_PEACH_ICE("Randm 15k – Peach Ice",            Color.fromRGB(235, 175, 120)),
    RANDM_PINK_LEMONADE("Randm 15k – Pink Lemonade",        Color.fromRGB(235,  90, 160)),
    RANDM_STRAWBERRY_KIWI("Randm 15k – Strawberry Kiwi",      Color.fromRGB(200,  40,  60)),
    RANDM_WILD_BERRY_CHERRY("Randm 15k – Wild Berry Cherry",    Color.fromRGB(120,  60, 170));

    private final String displayName;
    private final Color color;

    VapeFlavor(String displayName, Color color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() { return displayName; }
    public Color getColor()        { return color; }

    public static VapeFlavor fromName(String name) {
        if (name == null) return BLUE_RAZZ;
        for (VapeFlavor f : values()) {
            if (f.name().equalsIgnoreCase(name)) return f;
        }
        return BLUE_RAZZ;
    }

    /** Alle Geschmacksrichtungen, die für die Randm 15k verfügbar sind. */
    public static VapeFlavor[] randmFlavors() {
        return new VapeFlavor[] {
                RANDM_PEACH_ICE, RANDM_PINK_LEMONADE, RANDM_STRAWBERRY_KIWI, RANDM_WILD_BERRY_CHERRY
        };
    }
}
