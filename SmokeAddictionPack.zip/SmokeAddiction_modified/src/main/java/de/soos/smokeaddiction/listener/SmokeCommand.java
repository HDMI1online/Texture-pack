package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.ItemManager;
import de.soos.smokeaddiction.model.CigaretteBrand;
import de.soos.smokeaddiction.model.PlayerData;
import de.soos.smokeaddiction.model.VapeFlavor;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * /smokeaddiction give cigarette <marke> [anzahl]
 * /smokeaddiction give pack <marke> [füllung]
 * /smokeaddiction give vape <flavor>
 * /smokeaddiction give lighter
 * /smokeaddiction status [spieler]
 * /smokeaddiction reset [spieler]
 */
public class SmokeCommand implements CommandExecutor, TabCompleter {

    private final SmokeAddictionPlugin plugin;

    public SmokeCommand(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("Nutzung: /sa <give|status|reset|resourcepack>", NamedTextColor.YELLOW));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give":        return handleGive(sender, args);
            case "status":      return handleStatus(sender, args);
            case "reset":       return handleReset(sender, args);
            case "spawnvendor": return handleSpawnVendor(sender, args);
            case "refresh":     return handleRefresh(sender);
            case "buildcity":   return handleBuildCity(sender);
            case "builddealer": return handleBuildDealerVillage(sender);
            case "debug":       return handleDebug(sender, args);
            case "resourcepack":
            case "rp":          return handleResourcePack(sender, args);
            case "tutorial":    return handleTutorial(sender, args);
            case "scoreboard":  return handleScoreboard(sender, args);
            default:
                sender.sendMessage(Component.text("Unbekannter Subbefehl.", NamedTextColor.RED));
                return true;
        }
    }

    private boolean handleBuildCity(CommandSender sender) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur Spieler.", NamedTextColor.RED));
            return true;
        }
        sender.sendMessage(Component.text("Baue City an deiner Position ...", NamedTextColor.GREEN));
        plugin.getCityGenerator().buildCity(p.getLocation());
        return true;
    }

    private boolean handleBuildDealerVillage(CommandSender sender) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur Spieler.", NamedTextColor.RED));
            return true;
        }
        sender.sendMessage(Component.text("Baue Dealer-Dorf an deiner Position ...",
                NamedTextColor.DARK_PURPLE));
        plugin.getMineshaftVillageGenerator().build(p.getLocation());
        return true;
    }

    private boolean handleSpawnVendor(CommandSender sender, String[] args) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur Spieler.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            p.sendMessage(Component.text("Nutzung: /sa spawnvendor <cigarette|vape>", NamedTextColor.YELLOW));
            return true;
        }
        switch (args[1].toLowerCase()) {
            case "cigarette":
                plugin.getTraderManager().spawnCigaretteSeller(p.getLocation());
                p.sendMessage(Component.text("Zigaretten-Verkäufer gespawnt.", NamedTextColor.GREEN));
                break;
            case "vape":
                plugin.getTraderManager().spawnVapeSeller(p.getLocation());
                p.sendMessage(Component.text("Vape-Verkäufer gespawnt.", NamedTextColor.GREEN));
                break;
            case "beverage":
                plugin.getTraderManager().spawnBeverageSeller(p.getLocation());
                p.sendMessage(Component.text("Getränke-Verkäufer gespawnt.", NamedTextColor.GREEN));
                break;
            default:
                p.sendMessage(Component.text("Unbekannter Typ.", NamedTextColor.RED));
        }
        return true;
    }

    private boolean handleRefresh(CommandSender sender) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur Spieler.", NamedTextColor.RED));
            return true;
        }
        int count = 0;
        for (var ent : p.getWorld().getNearbyEntities(p.getLocation(), 16, 8, 16)) {
            if (ent instanceof org.bukkit.entity.Villager v
                    && plugin.getTraderManager().isTrader(v)) {
                plugin.getTraderManager().refreshTrades(v);
                count++;
            }
        }
        p.sendMessage(Component.text("Trades von " + count + " Händler(n) erneuert.",
                NamedTextColor.GREEN));
        return true;
    }

    private boolean handleGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur ein Spieler kann Items erhalten.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            p.sendMessage(Component.text("Nutzung: /sa give <cigarette|pack|vape|lighter> [...]",
                    NamedTextColor.YELLOW));
            return true;
        }

        ItemManager im = plugin.getItemManager();
        ItemStack item;
        switch (args[1].toLowerCase()) {
            case "cigarette": {
                CigaretteBrand brand = args.length >= 3 ? CigaretteBrand.fromName(args[2]) : CigaretteBrand.MARLBORO;
                int amt = 1;
                if (args.length >= 4) try { amt = Integer.parseInt(args[3]); } catch (NumberFormatException ignored) {}
                item = im.createCigarette(brand, Math.max(1, Math.min(8, amt)));
                break;
            }
            case "pack": {
                CigaretteBrand brand = args.length >= 3 ? CigaretteBrand.fromName(args[2]) : CigaretteBrand.MARLBORO;
                int fill = 8;
                if (args.length >= 4) try { fill = Integer.parseInt(args[3]); } catch (NumberFormatException ignored) {}
                item = im.createPack(brand, Math.max(0, Math.min(8, fill)));
                break;
            }
            case "vape": {
                VapeFlavor flavor = args.length >= 3 ? VapeFlavor.fromName(args[2]) : VapeFlavor.BLUE_RAZZ;
                item = im.createVape(flavor, 60);
                break;
            }
            case "lighter": {
                item = im.createLighter();
                break;
            }
            case "shisha": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createShisha(Math.max(1, Math.min(64, amt)));
                break;
            }
            case "fumot": {
                item = im.createFumot();
                break;
            }
            case "vozol": {
                item = im.createVozol();
                break;
            }
            case "randm": {
                de.soos.smokeaddiction.model.VapeFlavor[] flavors =
                        de.soos.smokeaddiction.model.VapeFlavor.randmFlavors();
                de.soos.smokeaddiction.model.VapeFlavor flavor = flavors[0];
                if (args.length >= 3) {
                    for (de.soos.smokeaddiction.model.VapeFlavor f : flavors) {
                        if (f.name().toLowerCase().contains(args[2].toLowerCase())) { flavor = f; break; }
                    }
                }
                item = im.createRandm(flavor);
                break;
            }
            case "beer": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createBeer(Math.max(1, Math.min(6, amt)));
                break;
            }
            case "jaeger": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createJaeger(Math.max(1, Math.min(6, amt)));
                break;
            }
            case "monster": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createMonsterWhite(Math.max(1, Math.min(8, amt)));
                break;
            }
            case "herb": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createHerbDried(Math.max(1, Math.min(64, amt)));
                break;
            }
            case "herb_raw": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createHerbRaw(Math.max(1, Math.min(64, amt)));
                break;
            }
            case "herb_seeds": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createHerbSeeds(Math.max(1, Math.min(64, amt)));
                break;
            }
            case "joint": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createCigarette(de.soos.smokeaddiction.model.CigaretteBrand.HERB_JOINT,
                        Math.max(1, Math.min(8, amt)));
                break;
            }
            case "magikzucker": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createMagikzucker(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "tablette": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createTablette(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "rauchzucker": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createRauchzucker(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "leaf": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createLeaf(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "spritze": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createSpritze(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "magicmushroom":
            case "shroom": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createMagicMushroom(Math.max(1, Math.min(16, amt)));
                break;
            }
            case "tobacco": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createTobacco(Math.max(1, Math.min(64, amt)));
                break;
            }
            case "seeds": {
                int amt = 1;
                if (args.length >= 3) try { amt = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                item = im.createTobaccoSeeds(Math.max(1, Math.min(64, amt)));
                break;
            }
            default:
                p.sendMessage(Component.text("Unbekannter Item-Typ.", NamedTextColor.RED));
                return true;
        }
        p.getInventory().addItem(item);
        p.sendMessage(Component.text("Item erhalten.", NamedTextColor.GREEN));
        return true;
    }

    /**
     * /sa resourcepack enable|disable|load
     * Wirkt jeweils NUR auf den ausführenden Spieler selbst (Pro-Spieler-Präferenz
     * in PlayerData), nicht serverweit – andere Spieler sind nicht betroffen.
     *  - enable:  hebt eine eigene vorherige Deaktivierung wieder auf und schickt das
     *             Pack sofort an einen selbst.
     *  - disable: deaktiviert das erzwungene Pack NUR für einen selbst – bei künftigen
     *             eigenen Logins wird es nicht mehr aufgedrängt.
     *  - load:    schickt das Pack EINMALIG an einen selbst, unabhängig vom
     *             eigenen enabled/disabled-Status (praktisch zum Testen).
     */
    private boolean handleResourcePack(CommandSender sender, String[] args) {
        if (!(sender instanceof Player self)) {
            sender.sendMessage(Component.text("Nur als Spieler ausführbar.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Component.text("Nutzung: /sa resourcepack <enable|disable|load>",
                    NamedTextColor.YELLOW));
            return true;
        }

        String sub = args[1].toLowerCase();
        switch (sub) {
            case "enable": {
                plugin.getPlayerDataManager().get(self).setResourcePackDisabled(false);
                plugin.getResourcePackListener().pushPack(self);
                sender.sendMessage(Component.text("Resource Pack ist für DICH jetzt aktiviert "
                        + "und wird dir gerade geschickt.", NamedTextColor.GREEN));
                return true;
            }
            case "disable": {
                plugin.getPlayerDataManager().get(self).setResourcePackDisabled(true);
                sender.sendMessage(Component.text("Resource Pack ist für DICH jetzt deaktiviert "
                        + "(nur für dich – andere Spieler sind unberührt). Mit "
                        + "/sa resourcepack load kannst du es dir trotzdem einmalig laden.",
                        NamedTextColor.YELLOW));
                return true;
            }
            case "load": {
                plugin.getResourcePackListener().pushPack(self);
                sender.sendMessage(Component.text("Resource Pack wird dir einmalig geschickt "
                        + "(deine Aktivierungs-Präferenz bleibt unverändert).", NamedTextColor.GREEN));
                return true;
            }
            default:
                sender.sendMessage(Component.text("Nutzung: /sa resourcepack <enable|disable|load>",
                        NamedTextColor.YELLOW));
                return true;
        }
    }

    /**
     * /sa tutorial       – Startet die animierte Einführung für den Spieler selbst.
     * /sa tutorial skip  – Bricht ein laufendes Tutorial sofort ab.
     * Jeder Spieler kann diesen Befehl nutzen (keine Admin-Permission nötig).
     */
    /** /sa scoreboard hide|show – Pro-Spieler-Toggle für die Sidebar-Scoreboard-Anzeige. */
    private boolean handleScoreboard(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur als Spieler ausführbar.", NamedTextColor.RED));
            return true;
        }
        if (!plugin.getSaScoreboardManager().isGloballyEnabled()) {
            sender.sendMessage(Component.text("Das Scoreboard ist serverseitig deaktiviert (config.yml).",
                    NamedTextColor.RED));
            return true;
        }

        boolean currentlyHidden = plugin.getPlayerDataManager().get(p).isScoreboardHidden();

        if (args.length < 2) {
            // Toggle
            plugin.getSaScoreboardManager().setHidden(p, !currentlyHidden);
            sender.sendMessage(Component.text("Scoreboard " + (!currentlyHidden ? "versteckt" : "sichtbar") + ".",
                    !currentlyHidden ? NamedTextColor.YELLOW : NamedTextColor.GREEN));
            return true;
        }

        boolean hide = args[1].equalsIgnoreCase("hide");
        plugin.getSaScoreboardManager().setHidden(p, hide);
        sender.sendMessage(Component.text("Scoreboard " + (hide ? "versteckt" : "wird angezeigt") + ".",
                hide ? NamedTextColor.YELLOW : NamedTextColor.GREEN));
        return true;
    }

    private boolean handleTutorial(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("Nur als Spieler ausführbar.", NamedTextColor.RED));
            return true;
        }
        var tm = plugin.getTutorialManager();
        if (args.length >= 2 && args[1].equalsIgnoreCase("skip")) {
            if (tm.isRunning(p)) {
                tm.stop(p);
            } else {
                p.sendMessage(Component.text("Kein Tutorial läuft gerade.", NamedTextColor.GRAY));
            }
            return true;
        }
        if (tm.isRunning(p)) {
            p.sendMessage(Component.text("Tutorial läuft bereits! Tippe ", NamedTextColor.YELLOW)
                    .append(Component.text("/sa tutorial skip", NamedTextColor.WHITE))
                    .append(Component.text(" zum Abbrechen.", NamedTextColor.YELLOW)));
            return true;
        }
        tm.start(p);
        return true;
    }

    private boolean handleDebug(CommandSender sender, String[] args) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            boolean current = plugin.getDebugManager().isEnabled();
            sender.sendMessage(Component.text(
                    "Debug ist aktuell: " + (current ? "AN" : "AUS") +
                    " | Nutzung: /sa debug <true|false|list>",
                    NamedTextColor.YELLOW));
            return true;
        }

        if (args[1].equalsIgnoreCase("list")) {
            return handleDebugList(sender);
        }

        boolean enable = args[1].equalsIgnoreCase("true") || args[1].equalsIgnoreCase("on");
        plugin.getDebugManager().setEnabled(enable, sender);
        sender.sendMessage(Component.text(
                "Debug-Modus " + (enable ? "aktiviert ✔" : "deaktiviert ✖") +
                (enable ? " – Spawn-Events werden dir im Chat angezeigt." : ""),
                enable ? NamedTextColor.GREEN : NamedTextColor.RED));
        return true;
    }

    /**
     * /sa debug list – listet alle registrierten Dealer-Dörfer (Mineshaft-Villages) und
     * alle generierten Cities mit Welt + Koordinaten. Nur für Operatoren, unabhängig von
     * eventuellen smokeaddiction.admin-Permission-Zuweisungen über ein Permission-Plugin –
     * das sind sensible rohe Koordinaten.
     */
    private boolean handleDebugList(CommandSender sender) {
        if (!sender.isOp()) {
            sender.sendMessage(Component.text("Nur für Operatoren.", NamedTextColor.RED));
            return true;
        }

        sender.sendMessage(Component.text("═══ Dealer-Dörfer ═══", NamedTextColor.GOLD));
        var villages = plugin.getMineshaftVillageRegistry().getVillages();
        int dealerCount = 0;
        for (var entry : villages.entrySet()) {
            org.bukkit.World w = plugin.getServer().getWorld(entry.getKey());
            String worldName = (w != null) ? w.getName() : entry.getKey().toString();
            for (org.bukkit.Location loc : entry.getValue()) {
                dealerCount++;
                sender.sendMessage(Component.text("  " + dealerCount + ". ", NamedTextColor.GRAY)
                        .append(Component.text(worldName, NamedTextColor.AQUA))
                        .append(Component.text(" @ " + loc.getBlockX() + ", "
                                + loc.getBlockY() + ", " + loc.getBlockZ(), NamedTextColor.WHITE)));
            }
        }
        if (dealerCount == 0) {
            sender.sendMessage(Component.text("  (keine registriert)", NamedTextColor.DARK_GRAY));
        }

        sender.sendMessage(Component.text("═══ Cities ═══", NamedTextColor.GOLD));
        var cities = plugin.getCityRegistry().getCities();
        if (cities.isEmpty()) {
            sender.sendMessage(Component.text("  (keine registriert)", NamedTextColor.DARK_GRAY));
        } else {
            int i = 0;
            for (org.bukkit.Location loc : cities) {
                i++;
                String worldName = (loc.getWorld() != null) ? loc.getWorld().getName() : "?";
                sender.sendMessage(Component.text("  " + i + ". ", NamedTextColor.GRAY)
                        .append(Component.text(worldName, NamedTextColor.AQUA))
                        .append(Component.text(" @ " + loc.getBlockX() + ", "
                                + loc.getBlockY() + ", " + loc.getBlockZ(), NamedTextColor.WHITE)));
            }
        }

        sender.sendMessage(Component.text("═══════════════════", NamedTextColor.GOLD));
        sender.sendMessage(Component.text(dealerCount + " Dealer-Dorf/Dörfer, "
                + cities.size() + " City/Cities insgesamt.", NamedTextColor.GRAY));
        return true;
    }

    private boolean handleStatus(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = plugin.getServer().getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Spieler nicht online.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Nutzung: /sa status <spieler>", NamedTextColor.YELLOW));
            return true;
        }

        PlayerData d = plugin.getPlayerDataManager().get(target);
        sender.sendMessage(Component.text("=== Sucht-Status: " + target.getName() + " ===", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("Süchtig: " + d.isAddicted(), NamedTextColor.GRAY));
        sender.sendMessage(Component.text("Sucht-Stufe: " + d.getAddictionLevel(), NamedTextColor.GRAY));
        sender.sendMessage(Component.text("Zigaretten gesamt: " + d.getTotalCigarettesSmoked(), NamedTextColor.GRAY));
        sender.sendMessage(Component.text("Nikotin: " + String.format("%.2f", d.getNicotineLevel()) + "/8",
                NamedTextColor.GRAY));
        sender.sendMessage(Component.text("Im Entzug: " + d.isInWithdrawal(), NamedTextColor.GRAY));
        return true;
    }

    private boolean handleReset(CommandSender sender, String[] args) {
        if (!sender.hasPermission("smokeaddiction.admin")) {
            sender.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED));
            return true;
        }
        Player target;
        if (args.length >= 2) {
            target = plugin.getServer().getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Spieler nicht online.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Nutzung: /sa reset <spieler>", NamedTextColor.YELLOW));
            return true;
        }

        PlayerData d = plugin.getPlayerDataManager().get(target);
        d.setAddicted(false);
        d.setAddictionLevel(0);
        d.setTotalCigarettesSmoked(0);
        d.setNicotineLevel(0.0);
        d.setInWithdrawal(false);
        d.setWithdrawalStartMillis(0L);
        d.setLastDecayMillis(System.currentTimeMillis());
        plugin.getNicotineManager().removeBossBar(target);
        plugin.getNicotineManager().removeAllPluginEffects(target);
        sender.sendMessage(Component.text("Sucht-Daten zurückgesetzt für " + target.getName(),
                NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return Arrays.asList("give", "status", "reset",
                "spawnvendor", "refresh", "buildcity", "builddealer", "debug",
                "resourcepack", "tutorial", "scoreboard");
        if (args.length == 2 && args[0].equalsIgnoreCase("scoreboard")) {
            return Arrays.asList("hide", "show");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("tutorial")) {
            return Arrays.asList("skip");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("debug")) {
            return Arrays.asList("true", "false", "list");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("resourcepack")) {
            return Arrays.asList("enable", "disable", "load");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("spawnvendor")) {
            return Arrays.asList("cigarette", "vape", "beverage");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Arrays.asList("cigarette", "pack", "vape", "lighter", "tobacco", "seeds",
                    "shisha", "fumot", "vozol", "randm", "beer", "jaeger", "monster",
                    "herb", "herb_raw", "herb_seeds", "joint",
                    "magikzucker", "tablette", "rauchzucker", "leaf", "spritze", "magicmushroom");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            String type = args[1].toLowerCase();
            if (type.equals("cigarette") || type.equals("pack")) {
                List<String> out = new ArrayList<>();
                for (CigaretteBrand b : CigaretteBrand.values()) out.add(b.name());
                return out;
            }
            if (type.equals("vape")) {
                List<String> out = new ArrayList<>();
                for (VapeFlavor f : VapeFlavor.values()) out.add(f.name());
                return out;
            }
        }
        return new ArrayList<>();
    }
}
