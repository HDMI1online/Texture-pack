package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.util.Keys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Baut ein verfallenes Dealer-Dorf in einer Mineshaft-Cave-Region.
 * Layout:
 *   - 35x35 ausgeräumter Bereich (Y bis Y+10)
 *   - Boden: Mix aus Cobblestone, Mossy Cobblestone, gerissene/moosige Steinziegel
 *   - 5 ramshackle Häuser im Kreis um eine zentrale Lagerfeuer-Stelle
 *   - Häuser haben kaputte Wände (paar Lücken), zerbrochene Glasfenster, alte Türen
 *   - 1 Lagerfeuer in der Mitte (Soul Campfire für düstere Atmosphäre)
 *   - 4 Underground-Dealer-Villager + 1 Wandering Trader mit Plugin-Trades
 */
public class MineshaftVillageGenerator {

    private static final int OPS_PER_TICK = 400;
    private static final int RADIUS = 17; // 35x35
    private static final int HEIGHT = 10;

    private final SmokeAddictionPlugin plugin;

    public MineshaftVillageGenerator(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    /** Baut ein Mineshaft-Dorf in der Nähe der angegebenen Location. */
    public void build(Location centerHint) {
        World w = centerHint.getWorld();
        if (w == null) return;

        // Y-Höhe so wählen, dass wir genug Platz haben (zwischen Y 20 und 50)
        int targetY = clamp(centerHint.getBlockY(), 20, 50);
        int cx = centerHint.getBlockX();
        int cz = centerHint.getBlockZ();
        Location center = new Location(w, cx, targetY, cz);

        plugin.getMineshaftVillageRegistry().register(center);

        Deque<Runnable> ops = new LinkedList<>();
        Random rnd = new Random((long) cx * 31 + cz);

        // Phase 1: Cave aushöhlen + Boden legen
        layCaveOps(ops, w, cx, targetY, cz, rnd);

        // Phase 2: 5 Häuser bauen
        // Häuser-Positionen rund um Zentrum, ca. 10 Block Abstand
        int[][] houseOffsets = {
                { -10,  0 },   // West
                {  10,  0 },   // Ost
                {   0, -10 },  // Nord
                {   0,  10 },  // Süd
                {   8,  8 },   // Süd-Ost (5. Haus diagonal)
        };
        for (int i = 0; i < houseOffsets.length; i++) {
            int hx = cx + houseOffsets[i][0];
            int hz = cz + houseOffsets[i][1];
            int seed = i;
            layHouseOps(ops, w, hx, targetY, hz, rnd, seed);
        }

        // Phase 3: Zentrum mit Lagerfeuer + Beleuchtung
        layCenterOps(ops, w, cx, targetY, cz);

        // Phase 4: Trader spawnen
        ops.add(() -> {
            spawnDealers(w, cx, targetY, cz);
            for (org.bukkit.entity.Player p : w.getPlayers()) {
                if (p.getLocation().distance(center) < 100) {
                    p.sendMessage(Component.text("Du hast ein verfallenes Dealer-Dorf entdeckt ...",
                            NamedTextColor.DARK_PURPLE)
                            .decoration(TextDecoration.ITALIC, true));
                }
            }
        });

        // Asynchron abarbeiten
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                int processed = 0;
                while (processed < OPS_PER_TICK && !ops.isEmpty()) {
                    try { ops.pollFirst().run(); }
                    catch (Throwable t) {
                        plugin.getLogger().warning("Mineshaft-Village-Build-Fehler: " + t.getMessage());
                    }
                    processed++;
                }
                if (ops.isEmpty()) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // ============================================================
    // Phase 1: Cave aushöhlen + verfallener Boden
    // ============================================================
    private void layCaveOps(Deque<Runnable> ops, World w, int cx, int cy, int cz, Random rnd) {
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                int distSq = dx * dx + dz * dz;
                if (distSq > RADIUS * RADIUS) continue;
                int fx = cx + dx;
                int fz = cz + dz;
                ops.add(() -> {
                    // Boden: Mix aus Cobble, Mossy, Cracked Stone Bricks
                    Block floor = w.getBlockAt(fx, cy - 1, fz);
                    Material[] floorMats = {
                            Material.COBBLESTONE, Material.MOSSY_COBBLESTONE,
                            Material.STONE_BRICKS, Material.CRACKED_STONE_BRICKS,
                            Material.MOSSY_STONE_BRICKS,
                            Material.GRAVEL, Material.DIRT
                    };
                    floor.setType(floorMats[(fx * 7 + fz * 11) & (floorMats.length - 1) % floorMats.length],
                            false);

                    // Cave-Bereich freiräumen
                    for (int dy = 0; dy < HEIGHT; dy++) {
                        Block b = w.getBlockAt(fx, cy + dy, fz);
                        if (b.getType() != Material.AIR) {
                            b.setType(Material.AIR, false);
                        }
                    }
                });
            }
        }
    }

    // ============================================================
    // Phase 2: Ein verfallenes Haus (5x5 Footprint, 4 Block hoch)
    // ============================================================
    private void layHouseOps(Deque<Runnable> ops, World w, int hx, int hy, int hz,
                              Random globalRnd, int seed) {
        Random rnd = new Random((long) hx * 17 + hz * 31 + seed);
        ops.add(() -> {
            // Wände (5x5 Footprint, hohl, 4 Block hoch)
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean isWall = (Math.abs(dx) == 2 || Math.abs(dz) == 2);
                    if (!isWall) continue;
                    for (int dy = 0; dy < 4; dy++) {
                        Block b = w.getBlockAt(hx + dx, hy + dy, hz + dz);
                        // 15% Chance dass Wand-Block fehlt (verfallener Look)
                        if (rnd.nextDouble() < 0.15 && dy < 3) {
                            b.setType(Material.AIR, false);
                            continue;
                        }
                        Material wall;
                        double r = rnd.nextDouble();
                        if (r < 0.3) wall = Material.CRACKED_STONE_BRICKS;
                        else if (r < 0.55) wall = Material.MOSSY_STONE_BRICKS;
                        else if (r < 0.8) wall = Material.STONE_BRICKS;
                        else if (r < 0.95) wall = Material.COBBLESTONE;
                        else wall = Material.COBWEB;
                        b.setType(wall, false);
                    }
                }
            }

            // Tür: Süd-Mitte (dz = 2, dx = 0), zwei Block hoch
            // 50% Chance dass Tür fehlt (kaputt)
            if (rnd.nextDouble() < 0.5) {
                Block doorBottom = w.getBlockAt(hx, hy, hz + 2);
                Block doorTop    = w.getBlockAt(hx, hy + 1, hz + 2);
                doorBottom.setType(Material.OAK_DOOR, false);
                BlockData bd = doorBottom.getBlockData();
                if (bd instanceof Directional dir) {
                    dir.setFacing(BlockFace.SOUTH);
                    doorBottom.setBlockData(dir, false);
                }
                if (bd instanceof org.bukkit.block.data.Bisected bisB) {
                    bisB.setHalf(org.bukkit.block.data.Bisected.Half.BOTTOM);
                    doorBottom.setBlockData(bisB, false);
                }
                doorTop.setType(Material.OAK_DOOR, false);
                BlockData tBd = doorTop.getBlockData();
                if (tBd instanceof org.bukkit.block.data.Bisected bisT) {
                    bisT.setHalf(org.bukkit.block.data.Bisected.Half.TOP);
                    doorTop.setBlockData(bisT, false);
                }
            } else {
                // Tür-Loch
                w.getBlockAt(hx, hy, hz + 2).setType(Material.AIR, false);
                w.getBlockAt(hx, hy + 1, hz + 2).setType(Material.AIR, false);
            }

            // Fenster: 2 zerbrochene Glas-Stellen (an den Seiten)
            int[] windowDx = { -2, 2 };
            for (int wx : windowDx) {
                Block win = w.getBlockAt(hx + wx, hy + 2, hz);
                // 40% kaputt → AIR, sonst zerbrochenes Glas (Glass Pane)
                if (rnd.nextDouble() < 0.4) {
                    win.setType(Material.AIR, false);
                } else {
                    win.setType(Material.GLASS_PANE, false);
                }
            }

            // Dach: 5x5 dunkles Eichenholz
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    Block roof = w.getBlockAt(hx + dx, hy + 4, hz + dz);
                    // 20% Chance dass Dach-Block fehlt (Loch)
                    if (rnd.nextDouble() < 0.2) {
                        roof.setType(Material.AIR, false);
                    } else {
                        roof.setType(rnd.nextBoolean() ? Material.SPRUCE_PLANKS : Material.DARK_OAK_PLANKS,
                                false);
                    }
                }
            }

            // Innen-Deko: Kiste, Crafting Table, Bettrest, Spinnweben
            Block crafter = w.getBlockAt(hx - 1, hy, hz - 1);
            crafter.setType(rnd.nextBoolean() ? Material.CRAFTING_TABLE : Material.BARREL, false);
            // Spinnweben in den Ecken
            w.getBlockAt(hx + 1, hy + 3, hz + 1).setType(Material.COBWEB, false);
            w.getBlockAt(hx - 1, hy + 3, hz - 1).setType(Material.COBWEB, false);
            // Vereinzelte Lampe / Laterne unter dem Dach
            if (rnd.nextDouble() < 0.6) {
                w.getBlockAt(hx, hy + 3, hz).setType(Material.SOUL_LANTERN, false);
                BlockData lan = w.getBlockAt(hx, hy + 3, hz).getBlockData();
                if (lan instanceof org.bukkit.block.data.type.Lantern lantern) {
                    lantern.setHanging(true);
                    w.getBlockAt(hx, hy + 3, hz).setBlockData(lantern, false);
                }
            }
        });
    }

    // ============================================================
    // Phase 3: Zentrum mit Soul-Campfire
    // ============================================================
    private void layCenterOps(Deque<Runnable> ops, World w, int cx, int cy, int cz) {
        ops.add(() -> {
            // Kleine Kreis-Plattform aus Andesite
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx * dx + dz * dz > 4) continue;
                    Block floor = w.getBlockAt(cx + dx, cy - 1, cz + dz);
                    floor.setType(Material.POLISHED_BLACKSTONE, false);
                }
            }
            // Soul-Campfire in der Mitte
            Block fire = w.getBlockAt(cx, cy, cz);
            fire.setType(Material.SOUL_CAMPFIRE, false);

            // 4 Stühle drumrum (Spruce Stairs)
            int[][] chairs = { { -2, 0, BlockFace.EAST.ordinal() },
                               {  2, 0, BlockFace.WEST.ordinal() },
                               {  0, -2, BlockFace.SOUTH.ordinal() },
                               {  0,  2, BlockFace.NORTH.ordinal() } };
            for (int[] c : chairs) {
                Block chair = w.getBlockAt(cx + c[0], cy, cz + c[1]);
                chair.setType(Material.SPRUCE_STAIRS, false);
                BlockData bd = chair.getBlockData();
                if (bd instanceof org.bukkit.block.data.type.Stairs s) {
                    s.setFacing(BlockFace.values()[c[2]]);
                    chair.setBlockData(s, false);
                }
            }
        });
    }

    // ============================================================
    // Phase 4: Trader spawnen (4 Villager + 1 Wandering Trader)
    // ============================================================
    private void spawnDealers(World w, int cx, int cy, int cz) {
        // Villager-Positionen: jeweils nahe einem der 5 Häuser, auf dem Boden
        int[][] spawnPositions = {
                { cx - 8, cz },
                { cx + 8, cz },
                { cx, cz - 8 },
                { cx, cz + 8 },
        };

        // 4 Villager mit Underground-Dealer-Trades
        for (int[] pos : spawnPositions) {
            Location loc = new Location(w, pos[0] + 0.5, cy, pos[1] + 0.5);
            Villager villager = (Villager) w.spawnEntity(loc, EntityType.VILLAGER);
            villager.setProfession(Villager.Profession.NITWIT);
            villager.customName(Component.text("Dealer", NamedTextColor.DARK_PURPLE));
            villager.setCustomNameVisible(true);
            villager.setPersistent(true);
            villager.setRemoveWhenFarAway(false);
            villager.setInvulnerable(true);
            villager.getPersistentDataContainer().set(Keys.TRADER_TYPE,
                    PersistentDataType.STRING, "underground_dealer");
            villager.setRecipes(buildDealerTrades());
        }

        // 1 Wandering Trader im Zentrum
        Location wtLoc = new Location(w, cx + 0.5, cy, cz - 3 + 0.5);
        WanderingTrader wt = (WanderingTrader) w.spawnEntity(wtLoc, EntityType.WANDERING_TRADER);
        wt.customName(Component.text("Schmuggler", NamedTextColor.RED));
        wt.setCustomNameVisible(true);
        wt.setPersistent(true);
        wt.setRemoveWhenFarAway(false);
        wt.setInvulnerable(true);
        wt.getPersistentDataContainer().set(Keys.TRADER_TYPE,
                PersistentDataType.STRING, "underground_smuggler");
        wt.setRecipes(buildDealerTrades());
    }

    private List<MerchantRecipe> buildDealerTrades() {
        ItemManager im = plugin.getItemManager();
        List<MerchantRecipe> trades = new ArrayList<>();

        // Leaf: 25 Emeralds
        MerchantRecipe leaf = new MerchantRecipe(im.createLeaf(1), 0, Integer.MAX_VALUE, false);
        leaf.addIngredient(new ItemStack(Material.EMERALD, 25));
        trades.add(leaf);

        // LSD: 35 Emeralds
        MerchantRecipe lsd = new MerchantRecipe(im.createTablette(1), 0, Integer.MAX_VALUE, false);
        lsd.addIngredient(new ItemStack(Material.EMERALD, 35));
        trades.add(lsd);

        // Kokain: 32 Emeralds
        MerchantRecipe coke = new MerchantRecipe(im.createMagikzucker(1), 0, Integer.MAX_VALUE, false);
        coke.addIngredient(new ItemStack(Material.EMERALD, 32));
        trades.add(coke);

        // Bier: 5 Emeralds
        MerchantRecipe beer = new MerchantRecipe(im.createBeer(1), 0, Integer.MAX_VALUE, false);
        beer.addIngredient(new ItemStack(Material.EMERALD, 5));
        trades.add(beer);

        // Jägermeister: 8 Emeralds
        MerchantRecipe jaeger = new MerchantRecipe(im.createJaeger(1), 0, Integer.MAX_VALUE, false);
        jaeger.addIngredient(new ItemStack(Material.EMERALD, 8));
        trades.add(jaeger);

        return trades;
    }

    private static int clamp(int v, int min, int max) {
        return v < min ? min : (v > max ? max : v);
    }
}
