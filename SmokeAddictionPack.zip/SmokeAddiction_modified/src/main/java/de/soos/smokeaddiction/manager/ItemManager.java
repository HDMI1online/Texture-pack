package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.model.CigaretteBrand;
import de.soos.smokeaddiction.model.VapeFlavor;
import de.soos.smokeaddiction.util.CMDValues;
import de.soos.smokeaddiction.util.Keys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * Erzeugt und identifiziert alle Custom-Items des Plugins.
 * Items werden über den PersistentDataContainer markiert (Keys.ITEM_TYPE).
 */
public class ItemManager {

    public static final String TYPE_CIGARETTE = "cigarette";
    public static final String TYPE_PACK      = "pack";
    public static final String TYPE_VAPE      = "vape";
    public static final String TYPE_LIGHTER   = "lighter";
    public static final String TYPE_TOBACCO       = "tobacco";        // getrocknet
    public static final String TYPE_TOBACCO_RAW   = "tobacco_raw";    // frisch, muss erst getrocknet werden
    public static final String TYPE_TOBACCO_SEEDS = "tobacco_seeds";
    public static final String TYPE_SHISHA        = "shisha";
    public static final String TYPE_FUMOT         = "fumot12k";       // Fumot Tornado Digital Box 12000
    public static final String TYPE_VOZOL         = "vozol40k";       // Vozol 40k – Akku-Vape, exklusiv beim Wandering Trader
    public static final String TYPE_RANDM         = "randm15k";       // Randm 15k – Akku-Vape mit Stärke-Modi, beim Wandering Trader
    public static final String TYPE_BEER          = "beer";
    public static final String TYPE_JAEGER        = "jaegermeister";
    public static final String TYPE_MONSTER_WHITE = "monster_white";
    public static final String TYPE_HERB_RAW      = "herb_raw";
    public static final String TYPE_HERB_DRIED    = "herb_dried";
    public static final String TYPE_HERB_SEEDS    = "herb_seeds";
    public static final String TYPE_MAGIKZUCKER   = "magikzucker";
    public static final String TYPE_TABLETTE      = "tablette";
    public static final String TYPE_RAUCHZUCKER   = "rauchzucker";
    public static final String TYPE_LEAF          = "leaf";
    public static final String TYPE_SPRITZE       = "spritze";
    public static final String TYPE_MAGIC_MUSHROOM = "magic_mushroom";

    public static final int FUMOT_MAX_PUFFS   = 120;
    public static final int FUMOT_MAX_BATTERY = 100;

    /** Vozol 40k: 400 Züge gesamt, Akku reicht für 150 Züge pro Ladung. */
    public static final int VOZOL_MAX_PUFFS         = 400;
    public static final int VOZOL_PUFFS_PER_CHARGE  = 150;

    /** Randm 15k: 150 Liquid gesamt, Akku reicht für 50 Liquid-Einheiten pro Ladung. */
    public static final double RANDM_MAX_LIQUID         = 150.0;
    public static final double RANDM_LIQUID_PER_CHARGE  = 50.0;

    /** Eine einzelne Zigarette (max stack 8). */
    public ItemStack createCigarette(CigaretteBrand brand, int amount) {
        ItemStack item = new ItemStack(Material.BAMBOO, Math.max(1, Math.min(8, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(Component.text("Zigarette (" + brand.getDisplayName() + ")")
                .color(NamedTextColor.WHITE)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Marke: " + brand.getDisplayName()).color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Halte sie in der Haupthand und").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("nutze ein Feuerzeug in der Offhand,").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("um zu rauchen.").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setMaxStackSize(8);

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_CIGARETTE);
        pdc.set(Keys.BRAND, PersistentDataType.STRING, brand.name());
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.forCigarette(brand));

        item.setItemMeta(meta);
        return item;
    }

    /** Eine Schachtel (max stack 64) mit gegebener Marke und Anzahl Zigaretten (0..8). */
    public ItemStack createPack(CigaretteBrand brand, int cigarettesInside) {
        ItemStack item = new ItemStack(Material.LEATHER_HORSE_ARMOR);
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) {
            return item;
        }
        lm.setColor(brand.getColor());

        lm.displayName(Component.text("Schachtel " + brand.getDisplayName())
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Inhalt: " + cigarettesInside + "/8").color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Platzieren als Block.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Linksklick: Zigarette entnehmen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Rechtsklick mit Zigarette: einzeln einlegen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sneak + Rechtsklick: Schachtel auffüllen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sneak + Linksklick: Schachtel abbauen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lm.lore(lore);
        lm.setMaxStackSize(64);

        PersistentDataContainer pdc = lm.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_PACK);
        pdc.set(Keys.BRAND, PersistentDataType.STRING, brand.name());
        pdc.set(Keys.PACK_CIGS, PersistentDataType.INTEGER, Math.max(0, Math.min(8, cigarettesInside)));
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(lm, CMDValues.forPack(brand));

        item.setItemMeta(lm);
        return item;
    }

    /** Eine Elfbar mit gegebener Sorte und Zügen (default 60). */
    public ItemStack createVape(VapeFlavor flavor, int puffs) {
        ItemStack item = new ItemStack(Material.LEATHER_HORSE_ARMOR);
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) return item;
        lm.setColor(flavor.getColor());

        lm.displayName(Component.text("Elfbar – " + flavor.getDisplayName())
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Züge: " + puffs + "/60").color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Rechtsklick: Zug nehmen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lm.lore(lore);
        lm.setMaxStackSize(1);

        PersistentDataContainer pdc = lm.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_VAPE);
        pdc.set(Keys.VAPE_FLAVOR, PersistentDataType.STRING, flavor.name());
        pdc.set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER, Math.max(0, Math.min(120, puffs)));
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(lm, CMDValues.forVape(flavor));

        item.setItemMeta(lm);
        return item;
    }

    /** Ein Feuerzeug (Flint and Steel mit reduzierter Haltbarkeit oder normal). */
    public ItemStack createLighter() {
        ItemStack item = new ItemStack(Material.FLINT_AND_STEEL);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(Component.text("Feuerzeug")
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Notwendig zum Anzünden").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("einer Zigarette (Offhand).").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_LIGHTER);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.LIGHTER);

        item.setItemMeta(meta);
        return item;
    }

    // === Identifikation ===

    public boolean isType(ItemStack stack, String type) {
        if (stack == null || !stack.hasItemMeta()) return false;
        PersistentDataContainer pdc = stack.getItemMeta().getPersistentDataContainer();
        String t = pdc.get(Keys.ITEM_TYPE, PersistentDataType.STRING);
        return type.equals(t);
    }

    public boolean isCigarette(ItemStack stack) { return isType(stack, TYPE_CIGARETTE); }
    public boolean isPack(ItemStack stack)      { return isType(stack, TYPE_PACK); }
    public boolean isVape(ItemStack stack)      { return isType(stack, TYPE_VAPE) || isType(stack, TYPE_FUMOT) || isType(stack, TYPE_VOZOL) || isType(stack, TYPE_RANDM); }
    public boolean isElfbar(ItemStack stack)    { return isType(stack, TYPE_VAPE); }
    public boolean isVozol(ItemStack stack)     { return isType(stack, TYPE_VOZOL); }
    public boolean isRandm(ItemStack stack)     { return isType(stack, TYPE_RANDM); }

    /** Hat einen unabhängigen Akku-Kreislauf (Fumot/Vozol/Randm), der per Redstone geladen wird. */
    public boolean isChargeableVape(ItemStack stack) {
        return isFumot(stack) || isVozol(stack) || isRandm(stack);
    }

    /** Akkustand in Prozent (0-100), unabhängig vom konkreten Vape-Typ. */
    public int getBatteryPercent(ItemStack stack) {
        if (isFumot(stack)) return getFumotBattery(stack);
        if (isVozol(stack)) return (int) Math.round((getVozolChargeLeft(stack) / (double) VOZOL_PUFFS_PER_CHARGE) * 100);
        if (isRandm(stack))  return (int) Math.round((getRandmChargeLeft(stack) / RANDM_LIQUID_PER_CHARGE) * 100);
        return 100;
    }

    /** Ist der Akku-Kreislauf voll (100%)? */
    public boolean isFullyCharged(ItemStack stack) {
        if (isFumot(stack)) return getFumotBattery(stack) >= FUMOT_MAX_BATTERY;
        if (isVozol(stack)) return getVozolChargeLeft(stack) >= VOZOL_PUFFS_PER_CHARGE;
        if (isRandm(stack))  return getRandmChargeLeft(stack) >= RANDM_LIQUID_PER_CHARGE;
        return true;
    }
    public boolean isLighter(ItemStack stack)   { return isType(stack, TYPE_LIGHTER); }
    public boolean isTobacco(ItemStack stack)       { return isType(stack, TYPE_TOBACCO); }
    public boolean isTobaccoRaw(ItemStack stack)    { return isType(stack, TYPE_TOBACCO_RAW); }
    public boolean isTobaccoSeeds(ItemStack stack)  { return isType(stack, TYPE_TOBACCO_SEEDS); }
    public boolean isShisha(ItemStack stack)        { return isType(stack, TYPE_SHISHA); }
    public boolean isFumot(ItemStack stack)         { return isType(stack, TYPE_FUMOT); }
    public boolean isBeer(ItemStack stack)          { return isType(stack, TYPE_BEER); }
    public boolean isJaeger(ItemStack stack)        { return isType(stack, TYPE_JAEGER); }
    public boolean isMonsterWhite(ItemStack stack)  { return isType(stack, TYPE_MONSTER_WHITE); }
    public boolean isHerbRaw(ItemStack stack)       { return isType(stack, TYPE_HERB_RAW); }
    public boolean isHerbDried(ItemStack stack)     { return isType(stack, TYPE_HERB_DRIED); }
    public boolean isHerbSeeds(ItemStack stack)     { return isType(stack, TYPE_HERB_SEEDS); }
    public boolean isMagikzucker(ItemStack stack)   { return isType(stack, TYPE_MAGIKZUCKER); }
    public boolean isTablette(ItemStack stack)      { return isType(stack, TYPE_TABLETTE); }
    public boolean isRauchzucker(ItemStack stack)   { return isType(stack, TYPE_RAUCHZUCKER); }
    public boolean isLeaf(ItemStack stack)          { return isType(stack, TYPE_LEAF); }
    public boolean isSpritze(ItemStack stack)       { return isType(stack, TYPE_SPRITZE); }
    public boolean isMagicMushroom(ItemStack stack) { return isType(stack, TYPE_MAGIC_MUSHROOM); }

    /** Bier (max stack 6). +0.5‰, +4 HP, +6 Hunger. */
    public ItemStack createBeer(int amount) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE, Math.max(1, Math.min(6, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Bier")
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Ein kühles, frisches Bier.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("+ 4 HP", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+ 6 Hunger", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+ 0.5 \u2030", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setMaxStackSize(6);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_BEER);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.BEER);
        item.setItemMeta(meta);
        return item;
    }

    /** Frische Herb-Pflanze – muss im Ofen getrocknet werden. */
    public ItemStack createHerbRaw(int amount) {
        ItemStack item = new ItemStack(Material.SUGAR_CANE, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Cannabis (frisch)")
                .color(NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Eine geheimnisvolle Pflanze.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Trockne sie im Ofen.").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_HERB_RAW);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.HERB_RAW);
        item.setItemMeta(meta);
        return item;
    }

    /** Getrocknete Herb-Pflanze – Crafting-Zutat für Joints und Shisha-Inhalt. */
    public ItemStack createHerbDried(int amount) {
        ItemStack item = new ItemStack(Material.DRIED_KELP, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Cannabis (getrocknet)")
                .color(NamedTextColor.DARK_GREEN)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Verarbeitbar zu Joints").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("oder als Shisha-Inhalt.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_HERB_DRIED);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.HERB_DRIED);
        item.setItemMeta(meta);
        return item;
    }

    /** Samen für Cannabis-Anbau. */
    public ItemStack createHerbSeeds(int amount) {
        ItemStack item = new ItemStack(Material.BEETROOT_SEEDS, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Cannabis-Samen")
                .color(NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Pflanze auf Erde / Gras.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Wächst nur an sonnigen Plätzen.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_HERB_SEEDS);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.HERB_SEEDS);
        item.setItemMeta(meta);
        return item;
    }

    // ============================================================
    // Custom-Substanzen
    // ============================================================

    /** Kokain – ermöglicht 1-Klick-Abbau aller Blöcke. Nutzung: Rechtsklick (schnupfen). */
    public ItemStack createMagikzucker(int amount) {
        ItemStack item = new ItemStack(Material.SUGAR, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Kokain")
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Ermöglicht es dir, alles abzubauen.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Wirkung: 3-5 Min", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Entzug: 5 Min Adventure-Mode", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Rechtsklick zum Schnupfen.", NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_MAGIKZUCKER);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.MAGIKZUCKER);
        item.setItemMeta(meta);
        return item;
    }

    /** LSD – +3 Schaden für 10 Min, danach Schwäche. Nutzung: Essen. */
    public ItemStack createTablette(int amount) {
        // Material.MELON_SLICE ist essbar und stackt
        ItemStack item = new ItemStack(Material.MELON_SLICE, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("LSD")
                .color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Verleiht etwas Schlagkraft.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Wirkung: +3 Schaden, 10 Min", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Entzug: 5 Min Schwäche III", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Rechtsklick zum Schlucken.", NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_TABLETTE);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.TABLETTE);
        item.setItemMeta(meta);
        return item;
    }

    /** Crack – Resistance/Absorption für 6 Min, danach Blindness/Slowness. Wird in Zigarette verarbeitet. */
    public ItemStack createRauchzucker(int amount) {
        ItemStack item = new ItemStack(Material.SUGAR, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Crack")
                .color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Starker Schutz beim Konsum.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Wirkung: Resistenz IV + Absorption IV", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Dauer: 6 Min", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Entzug: 3 Min Orientierungslosigkeit", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_RAUCHZUCKER);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.RAUCHZUCKER);
        item.setItemMeta(meta);
        return item;
    }

    /** Leaf – Reinigt alle Effekte und Entzugserscheinungen. Rechtsklick. */
    public ItemStack createLeaf(int amount) {
        ItemStack item = new ItemStack(Material.OAK_LEAVES, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Leaf")
                .color(NamedTextColor.DARK_GREEN)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Reinigt deinen Körper")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("von allen Effekten.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Entfernt:", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("- Alle Potion-Effekte", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("- Adventure-Mode-Strafe", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("- Promille, Cannabis-Entzug, Withdrawal", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_LEAF);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.LEAF);
        item.setItemMeta(meta);
        return item;
    }

    /** Heroin – Fliegen für 3-5 Min, danach kein Springen für 5 Min. Rechtsklick. */
    public ItemStack createSpritze(int amount) {
        ItemStack item = new ItemStack(Material.GHAST_TEAR, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Heroin")
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Lässt dich fliegen.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Wirkung: Flug, 3-5 Min", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Entzug: 5 Min kein Springen", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_SPRITZE);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.SPRITZE);
        item.setItemMeta(meta);
        return item;
    }

    /** Magic Mushroom – 5 Min Mob-Ignore, danach zufällige Nebenwirkung. Essbar. */
    public ItemStack createMagicMushroom(int amount) {
        ItemStack item = new ItemStack(Material.PUFFERFISH, Math.max(1, Math.min(16, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Magic Mushroom")
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        java.util.List<Component> lore = new java.util.ArrayList<>();
        lore.add(Component.text("Mobs ignorieren dich völlig.")
                .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Wirkung: 5 Min Mob-Ignore", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Nachwirkung: zufällig", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Konsum: Essen", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_MAGIC_MUSHROOM);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.MAGIC_MUSHROOM);
        item.setItemMeta(meta);
        return item;
    }

    // ============================================================

    /** Kleiner Jägermeister (max stack 6). +0.2‰, +2 HP, +5 Hunger. Schnellerer Konsum. */
    public ItemStack createJaeger(int amount) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE, Math.max(1, Math.min(6, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Kleiner Jägermeister")
                .color(NamedTextColor.DARK_GREEN)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Ein eiskalter Kräuterlikör.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("+ 2 HP", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+ 5 Hunger", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+ 0.2 \u2030", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Schneller getrunken als Bier.", NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setMaxStackSize(6);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_JAEGER);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.JAEGER);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Monster White (Koffein-Energy-Drink). Stapelbar mit allen anderen Effekten.
     * Pro Dose: +0,5 Geschwindigkeit, +0,5 Schild, 2 Min Wirkdauer (verlängert sich
     * bei erneutem Konsum), stackt bis 4. Ab der 5. Dose in Folge (während die
     * Bar noch läuft): Vergiftung bis die Bar verschwindet.
     */
    public ItemStack createMonsterWhite(int amount) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE, Math.max(1, Math.min(8, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Monster White")
                .color(NamedTextColor.WHITE)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Eiskalter Koffein-Energy-Drink.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("+ 0,5 Geschwindigkeit", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+ 0,5 Schild", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("2 Min. Wirkdauer, stapelt bis 4×", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Stapelt sich mit anderen Effekten.", NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Zu viele Dosen hintereinander: Vergiftung!", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setMaxStackSize(8);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_MONSTER_WHITE);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.MONSTER_WHITE);
        item.setItemMeta(meta);
        return item;
    }

    /** Shisha-Item – nicht stapelbar, als Block platzierbar. */
    public ItemStack createShisha(int amount) {
        ItemStack item = new ItemStack(Material.END_ROD, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Shisha")
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Platziere sie als Block.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sneak + Rechtsklick: Inventar öffnen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Rechtsklick: Zug nehmen (30 s)").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Nur Netherit-Spitzhacke baut sie ab.").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.setMaxStackSize(1); // Nicht stackbar
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_SHISHA);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.SHISHA);
        item.setItemMeta(meta);
        return item;
    }

    /** Getrocknetes Tabakblatt – Crafting-Zutat. Wird durch Trocknen von frischem Tabak im Ofen gewonnen. */
    public ItemStack createTobacco(int amount) {
        ItemStack item = new ItemStack(Material.DRIED_KELP, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Tabakblatt (getrocknet)")
                .color(NamedTextColor.DARK_GREEN)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Getrocknetes Tabakblatt.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Bereit zum Verarbeiten.").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_TOBACCO);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.TOBACCO_DRIED);
        item.setItemMeta(meta);
        return item;
    }

    /** Frisches, ungetrocknetes Tabakblatt. Muss im Ofen getrocknet werden, bevor es verarbeitet werden kann. */
    /** Alias: getrockneter Tabak = createTobacco (fertig zum Verarbeiten). */
    public ItemStack createTobaccoDried(int amount) {
        return createTobacco(amount);
    }

    public ItemStack createTobaccoRaw(int amount) {
        ItemStack item = new ItemStack(Material.SUGAR_CANE, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Tabakblatt (frisch)")
                .color(NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Frisch geerntet, noch zu feucht.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Trockne es im Ofen, um es nutzbar zu machen.").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_TOBACCO_RAW);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.TOBACCO_RAW);
        item.setItemMeta(meta);
        return item;
    }

    /** Tabaksamen – pflanzbar in Tabak-Biomen. */
    public ItemStack createTobaccoSeeds(int amount) {
        ItemStack item = new ItemStack(Material.MELON_SEEDS, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Component.text("Tabaksamen")
                .color(NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Pflanze sie auf Gras, Erde oder Mud").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("in warmen, feuchten Biomen.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_TOBACCO_SEEDS);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.TOBACCO_SEEDS);
        item.setItemMeta(meta);
        return item;
    }

    public CigaretteBrand getBrand(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return CigaretteBrand.MARLBORO;
        String b = stack.getItemMeta().getPersistentDataContainer().get(Keys.BRAND, PersistentDataType.STRING);
        return CigaretteBrand.fromName(b);
    }

    public int getPackContents(ItemStack stack) {
        if (!isPack(stack)) return 0;
        Integer i = stack.getItemMeta().getPersistentDataContainer().get(Keys.PACK_CIGS, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    public VapeFlavor getVapeFlavor(ItemStack stack) {
        if (!isVape(stack)) return VapeFlavor.BLUE_RAZZ;
        String f = stack.getItemMeta().getPersistentDataContainer().get(Keys.VAPE_FLAVOR, PersistentDataType.STRING);
        return VapeFlavor.fromName(f);
    }

    public int getVapePuffs(ItemStack stack) {
        if (!isVape(stack)) return 0;
        Integer i = stack.getItemMeta().getPersistentDataContainer().get(Keys.VAPE_PUFFS, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    /** Setzt die Anzahl der Züge auf einer Elfbar und aktualisiert das Lore. */
    public void setVapePuffs(ItemStack stack, int puffs) {
        if (!isElfbar(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) return;
        int v = Math.max(0, Math.min(60, puffs));
        lm.getPersistentDataContainer().set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER, v);

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Züge: " + v + "/60").color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Rechtsklick: Zug nehmen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lm.lore(lore);
        stack.setItemMeta(lm);
    }

    /** Liefert den Akku-Stand (0..100) der Fumot 12k. Gibt 100 für Nicht-Fumot zurück. */
    public int getFumotBattery(ItemStack stack) {
        if (!isFumot(stack)) return 100;
        Integer i = stack.getItemMeta().getPersistentDataContainer().get(Keys.VAPE_BATTERY, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    /** Setzt den Akku der Fumot 12k (PDC; Display muss separat per updateFumotDisplay aktualisiert werden). */
    public void setFumotBatteryRaw(ItemStack stack, int battery) {
        if (!isFumot(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.VAPE_BATTERY, PersistentDataType.INTEGER,
                Math.max(0, Math.min(FUMOT_MAX_BATTERY, battery)));
        stack.setItemMeta(meta);
    }

    /** Setzt die verbleibenden Züge der Fumot 12k (PDC; Display separat). */
    public void setFumotPuffsRaw(ItemStack stack, int puffs) {
        if (!isFumot(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER,
                Math.max(0, Math.min(FUMOT_MAX_PUFFS, puffs)));
        stack.setItemMeta(meta);
    }

    /**
     * Erzeugt eine fabrikneue Fumot 12k mit voller Ladung und allen Zügen.
     * Diese Vape ist NICHT bei Händlern erhältlich – nur per Befehl.
     */
    public ItemStack createFumot() {
        ItemStack item = new ItemStack(Material.ECHO_SHARD, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setMaxStackSize(1);
        var pdc = meta.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_FUMOT);
        pdc.set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER, FUMOT_MAX_PUFFS);
        pdc.set(Keys.VAPE_BATTERY, PersistentDataType.INTEGER, FUMOT_MAX_BATTERY);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.FUMOT12K);
        item.setItemMeta(meta);
        updateFumotDisplay(item, FumotState.IDLE);
        return item;
    }

    /** Status der Fumot für die Display-Anzeige (Name-Suffix). */
    public enum FumotState { IDLE, IN_USE, CHARGING, FULLY_CHARGED, EMPTY_BATTERY, EMPTY_PUFFS }

    /**
     * Aktualisiert Name + Lore einer Fumot 12k anhand des aktuellen PDC-Zustands.
     * Die Anzeige soll möglichst auffällig sein:
     *  - Name enthält Akku-Prozent und Züge (sichtbar im Hotbar-Tooltip)
     *  - Lore enthält ASCII-Bar und Statushinweis
     */
    public void updateFumotDisplay(ItemStack stack, FumotState state) {
        if (!isFumot(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        Integer p = pdc.get(Keys.VAPE_PUFFS, PersistentDataType.INTEGER);
        Integer b = pdc.get(Keys.VAPE_BATTERY, PersistentDataType.INTEGER);
        int puffs   = p == null ? 0 : p;
        int battery = b == null ? 0 : b;

        // Statussuffix für den Namen
        String status;
        NamedTextColor statusColor;
        switch (state) {
            case CHARGING:        status = "Lädt " + battery + "%"; statusColor = NamedTextColor.YELLOW; break;
            case FULLY_CHARGED:   status = "VOLL geladen!";          statusColor = NamedTextColor.GREEN;  break;
            case EMPTY_BATTERY:   status = "Akku LEER";              statusColor = NamedTextColor.RED;    break;
            case EMPTY_PUFFS:     status = "AUFGEBRAUCHT";           statusColor = NamedTextColor.DARK_RED; break;
            default:              status = battery + "% │ " + puffs + "Z"; statusColor = NamedTextColor.AQUA;
        }

        meta.displayName(Component.text("Fumot 12k", NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.text(" │ ", NamedTextColor.DARK_GRAY))
                .append(Component.text(status, statusColor)));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Akku:  ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(battery, 100, 10), batteryColor(battery)))
                .append(Component.text("  " + battery + "%", NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Züge:  ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(puffs, FUMOT_MAX_PUFFS, 10), puffColor(puffs)))
                .append(Component.text("  " + puffs + "/" + FUMOT_MAX_PUFFS, NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        switch (state) {
            case CHARGING:
                lore.add(Component.text("Lädt an Redstone-Quelle ...", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case FULLY_CHARGED:
                lore.add(Component.text("Akku vollständig geladen!", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_BATTERY:
                lore.add(Component.text("Drop sie an einer", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Redstone-Quelle zum Laden.", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_PUFFS:
                lore.add(Component.text("Liquid aufgebraucht.", NamedTextColor.DARK_RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            default:
                lore.add(Component.text("Rechtsklick: Zug nehmen", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Bei leerem Akku: an Redstone laden.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.setMaxStackSize(1);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.FUMOT12K);
        stack.setItemMeta(meta);
    }

    private static String makeBar(int value, int max, int width) {
        int filled = Math.max(0, Math.min(width, (int) Math.round((value / (double) max) * width)));
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < width; i++) sb.append(i < filled ? '#' : '.');
        sb.append(']');
        return sb.toString();
    }

    private static NamedTextColor batteryColor(int v) {
        if (v >= 60) return NamedTextColor.GREEN;
        if (v >= 25) return NamedTextColor.YELLOW;
        if (v > 0)   return NamedTextColor.RED;
        return NamedTextColor.DARK_RED;
    }

    // ================================================================
    // Vozol 40k – 400 Züge, Akku reicht für 150 Züge, danach laden
    // (Sneak + Rechtsklick auf Redstone-Block zum Platzieren/Laden)
    // ================================================================

    /** Erzeugt eine fabrikneue Vozol 40k mit vollem Akku und allen Zügen. */
    public ItemStack createVozol() {
        ItemStack item = new ItemStack(Material.LEATHER_HORSE_ARMOR);
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) return item;
        lm.setColor(VapeFlavor.VOZOL_40K.getColor());
        lm.setMaxStackSize(1);

        PersistentDataContainer pdc = lm.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_VOZOL);
        pdc.set(Keys.VAPE_FLAVOR, PersistentDataType.STRING, VapeFlavor.VOZOL_40K.name());
        pdc.set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER, VOZOL_MAX_PUFFS);
        pdc.set(Keys.VOZOL_CHARGE_LEFT, PersistentDataType.DOUBLE, (double) VOZOL_PUFFS_PER_CHARGE);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(lm, CMDValues.VAPE_VOZOL_40K);

        item.setItemMeta(lm);
        updateVozolDisplay(item, VozolState.IDLE);
        return item;
    }

    /** Verbleibende Züge im aktuellen Akku-Zyklus (0..150), als Double für exaktes Laden. */
    public double getVozolChargeLeft(ItemStack stack) {
        if (!isVozol(stack)) return 0.0;
        Double d = stack.getItemMeta().getPersistentDataContainer()
                .get(Keys.VOZOL_CHARGE_LEFT, PersistentDataType.DOUBLE);
        return d == null ? 0.0 : d;
    }

    /** Setzt die verbleibenden Züge im aktuellen Akku-Zyklus (PDC; Display separat). */
    public void setVozolChargeLeftRaw(ItemStack stack, double chargeLeft) {
        if (!isVozol(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.VOZOL_CHARGE_LEFT, PersistentDataType.DOUBLE,
                Math.max(0.0, Math.min(VOZOL_PUFFS_PER_CHARGE, chargeLeft)));
        stack.setItemMeta(meta);
    }

    /** Setzt die gesamten verbleibenden Züge der Vozol 40k (PDC; Display separat). */
    public void setVozolPuffsRaw(ItemStack stack, int puffs) {
        if (!isVozol(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.VAPE_PUFFS, PersistentDataType.INTEGER,
                Math.max(0, Math.min(VOZOL_MAX_PUFFS, puffs)));
        stack.setItemMeta(meta);
    }

    /** Status der Vozol für die Display-Anzeige. */
    public enum VozolState { IDLE, IN_USE, CHARGING, FULLY_CHARGED, EMPTY_BATTERY, EMPTY_PUFFS }

    /** Aktualisiert Name + Lore einer Vozol 40k anhand des aktuellen PDC-Zustands. */
    public void updateVozolDisplay(ItemStack stack, VozolState state) {
        if (!isVozol(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        Integer p = pdc.get(Keys.VAPE_PUFFS, PersistentDataType.INTEGER);
        Double c = pdc.get(Keys.VOZOL_CHARGE_LEFT, PersistentDataType.DOUBLE);
        int puffs      = p == null ? 0 : p;
        double chargeLeft = c == null ? 0.0 : c;
        int batteryPct = (int) Math.round((chargeLeft / (double) VOZOL_PUFFS_PER_CHARGE) * 100);

        String status;
        NamedTextColor statusColor;
        switch (state) {
            case CHARGING:        status = "Lädt " + batteryPct + "%";  statusColor = NamedTextColor.YELLOW; break;
            case FULLY_CHARGED:   status = "VOLL geladen!";              statusColor = NamedTextColor.GREEN;  break;
            case EMPTY_BATTERY:   status = "Akku LEER";                  statusColor = NamedTextColor.RED;    break;
            case EMPTY_PUFFS:     status = "AUFGEBRAUCHT";               statusColor = NamedTextColor.DARK_RED; break;
            default:              status = batteryPct + "% │ " + puffs + "Z"; statusColor = NamedTextColor.AQUA;
        }

        meta.displayName(Component.text("Vozol 40k", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.text(" │ ", NamedTextColor.DARK_GRAY))
                .append(Component.text(status, statusColor)));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Akku:  ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(batteryPct, 100, 10), batteryColor(batteryPct)))
                .append(Component.text("  " + batteryPct + "%", NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Züge:  ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(puffs, VOZOL_MAX_PUFFS, 10), puffColor(puffs)))
                .append(Component.text("  " + puffs + "/" + VOZOL_MAX_PUFFS, NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        switch (state) {
            case CHARGING:
                lore.add(Component.text("Lädt auf Redstone-Block ...", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case FULLY_CHARGED:
                lore.add(Component.text("Akku vollständig geladen!", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_BATTERY:
                lore.add(Component.text("Drop sie an einer", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Redstone-Quelle zum Laden.", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_PUFFS:
                lore.add(Component.text("Liquid aufgebraucht.", NamedTextColor.DARK_RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            default:
                lore.add(Component.text("Rechtsklick: Zug nehmen", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Alle 150 Züge: Akku leer.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Bei leerem Akku: an Redstone laden.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.setMaxStackSize(1);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.VAPE_VOZOL_40K);
        stack.setItemMeta(meta);
    }

    // ================================================================
    // Randm 15k – 150 Liquid, Akku reicht für 50 Liquid pro Ladung,
    // 4 Geschmäcker, Stärke-Modi per Linksklick (Leicht/Normal/Stark/Surge)
    // (Sneak + Rechtsklick auf Redstone-Block zum Platzieren/Laden)
    // ================================================================

    /** Erzeugt eine fabrikneue Randm 15k mit vollem Akku, vollem Liquid und Stärke "Normal". */
    public ItemStack createRandm(VapeFlavor flavor) {
        ItemStack item = new ItemStack(Material.LEATHER_HORSE_ARMOR);
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) return item;
        lm.setColor(flavor.getColor());
        lm.setMaxStackSize(1);

        PersistentDataContainer pdc = lm.getPersistentDataContainer();
        pdc.set(Keys.ITEM_TYPE, PersistentDataType.STRING, TYPE_RANDM);
        pdc.set(Keys.VAPE_FLAVOR, PersistentDataType.STRING, flavor.name());
        pdc.set(Keys.RANDM_LIQUID, PersistentDataType.DOUBLE, RANDM_MAX_LIQUID);
        pdc.set(Keys.RANDM_CHARGE_LEFT, PersistentDataType.DOUBLE, RANDM_LIQUID_PER_CHARGE);
        pdc.set(Keys.RANDM_STRENGTH, PersistentDataType.STRING,
                de.soos.smokeaddiction.model.RandmStrength.NORMAL.name());
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(lm, CMDValues.forVape(flavor));

        item.setItemMeta(lm);
        updateRandmDisplay(item, RandmState.IDLE);
        return item;
    }

    /** Verbleibendes Liquid (0..150). */
    public double getRandmLiquid(ItemStack stack) {
        if (!isRandm(stack)) return 0.0;
        Double d = stack.getItemMeta().getPersistentDataContainer()
                .get(Keys.RANDM_LIQUID, PersistentDataType.DOUBLE);
        return d == null ? 0.0 : d;
    }

    /** Setzt das verbleibende Liquid (PDC; Display separat). */
    public void setRandmLiquidRaw(ItemStack stack, double liquid) {
        if (!isRandm(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.RANDM_LIQUID, PersistentDataType.DOUBLE,
                Math.max(0.0, Math.min(RANDM_MAX_LIQUID, liquid)));
        stack.setItemMeta(meta);
    }

    /** Verbleibende Ladung im aktuellen Akku-Zyklus (0..50). */
    public double getRandmChargeLeft(ItemStack stack) {
        if (!isRandm(stack)) return 0.0;
        Double d = stack.getItemMeta().getPersistentDataContainer()
                .get(Keys.RANDM_CHARGE_LEFT, PersistentDataType.DOUBLE);
        return d == null ? 0.0 : d;
    }

    /** Setzt die verbleibende Ladung im aktuellen Akku-Zyklus (PDC; Display separat). */
    public void setRandmChargeLeftRaw(ItemStack stack, double chargeLeft) {
        if (!isRandm(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.RANDM_CHARGE_LEFT, PersistentDataType.DOUBLE,
                Math.max(0.0, Math.min(RANDM_LIQUID_PER_CHARGE, chargeLeft)));
        stack.setItemMeta(meta);
    }

    /** Aktuell eingestellte Zugstärke (Default: NORMAL). */
    public de.soos.smokeaddiction.model.RandmStrength getRandmStrength(ItemStack stack) {
        if (!isRandm(stack)) return de.soos.smokeaddiction.model.RandmStrength.NORMAL;
        String s = stack.getItemMeta().getPersistentDataContainer()
                .get(Keys.RANDM_STRENGTH, PersistentDataType.STRING);
        return de.soos.smokeaddiction.model.RandmStrength.fromName(s);
    }

    /** Setzt die Zugstärke (PDC; Display separat). */
    public void setRandmStrengthRaw(ItemStack stack, de.soos.smokeaddiction.model.RandmStrength strength) {
        if (!isRandm(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.RANDM_STRENGTH, PersistentDataType.STRING, strength.name());
        stack.setItemMeta(meta);
    }

    /** Status der Randm für die Display-Anzeige. */
    public enum RandmState { IDLE, IN_USE, SURGE_CHARGING, CHARGING, FULLY_CHARGED, EMPTY_BATTERY, EMPTY_LIQUID }

    /** Aktualisiert Name + Lore einer Randm 15k anhand des aktuellen PDC-Zustands. */
    public void updateRandmDisplay(ItemStack stack, RandmState state) {
        if (!isRandm(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        Double liq = pdc.get(Keys.RANDM_LIQUID, PersistentDataType.DOUBLE);
        Double chg = pdc.get(Keys.RANDM_CHARGE_LEFT, PersistentDataType.DOUBLE);
        String strRaw = pdc.get(Keys.RANDM_STRENGTH, PersistentDataType.STRING);
        double liquid     = liq == null ? 0.0 : liq;
        double chargeLeft = chg == null ? 0.0 : chg;
        de.soos.smokeaddiction.model.RandmStrength strength =
                de.soos.smokeaddiction.model.RandmStrength.fromName(strRaw);
        int batteryPct = (int) Math.round((chargeLeft / RANDM_LIQUID_PER_CHARGE) * 100);
        int liquidRounded = (int) Math.round(liquid);
        VapeFlavor flavor = getVapeFlavor(stack);

        String status;
        NamedTextColor statusColor;
        switch (state) {
            case CHARGING:        status = "Lädt " + batteryPct + "%";   statusColor = NamedTextColor.YELLOW; break;
            case FULLY_CHARGED:   status = "VOLL geladen!";               statusColor = NamedTextColor.GREEN;  break;
            case EMPTY_BATTERY:   status = "Akku LEER";                   statusColor = NamedTextColor.RED;    break;
            case EMPTY_LIQUID:    status = "AUFGEBRAUCHT";                statusColor = NamedTextColor.DARK_RED; break;
            case SURGE_CHARGING:  status = "SURGE ...";                   statusColor = NamedTextColor.LIGHT_PURPLE; break;
            default:              status = strength.getDisplayName() + " │ " + batteryPct + "%"; statusColor = NamedTextColor.AQUA;
        }

        meta.displayName(Component.text("Randm 15k", NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.text(" (" + flavor.getDisplayName().replace("Randm 15k – ", "") + ") │ ",
                        NamedTextColor.DARK_GRAY))
                .append(Component.text(status, statusColor)));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Stärke: ", NamedTextColor.GRAY)
                .append(Component.text(strength.getDisplayName(), strengthColor(strength)))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Akku:   ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(batteryPct, 100, 10), batteryColor(batteryPct)))
                .append(Component.text("  " + batteryPct + "%", NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Liquid: ", NamedTextColor.GRAY)
                .append(Component.text(makeBar(liquidRounded, (int) RANDM_MAX_LIQUID, 10), puffColor(liquidRounded)))
                .append(Component.text("  " + liquidRounded + "/" + (int) RANDM_MAX_LIQUID, NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        switch (state) {
            case CHARGING:
                lore.add(Component.text("Lädt an Redstone-Quelle ...", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case FULLY_CHARGED:
                lore.add(Component.text("Akku vollständig geladen!", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_BATTERY:
                lore.add(Component.text("Drop sie an einer", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Redstone-Quelle zum Laden.", NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case EMPTY_LIQUID:
                lore.add(Component.text("Liquid aufgebraucht.", NamedTextColor.DARK_RED)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            case SURGE_CHARGING:
                lore.add(Component.text("Ziehen halten für mehr Nikotin ...", NamedTextColor.LIGHT_PURPLE)
                        .decoration(TextDecoration.ITALIC, false));
                break;
            default:
                lore.add(Component.text("Linksklick: Stärke wechseln", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Rechtsklick: Zug nehmen (Surge: halten)", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("Bei leerem Akku: an Redstone laden.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.setMaxStackSize(1);
        de.soos.smokeaddiction.util.CustomModelDataHelper.apply(meta, CMDValues.forVape(flavor));
        stack.setItemMeta(meta);
    }

    private static NamedTextColor strengthColor(de.soos.smokeaddiction.model.RandmStrength s) {
        switch (s) {
            case LEICHT: return NamedTextColor.GREEN;
            case NORMAL: return NamedTextColor.YELLOW;
            case STARK:  return NamedTextColor.RED;
            case SURGE:  return NamedTextColor.LIGHT_PURPLE;
            default:     return NamedTextColor.YELLOW;
        }
    }

    private static NamedTextColor puffColor(int v) {
        if (v >= 60) return NamedTextColor.AQUA;
        if (v >= 20) return NamedTextColor.YELLOW;
        if (v > 0)   return NamedTextColor.RED;
        return NamedTextColor.DARK_RED;
    }

    /** Updated Inhalt einer Schachtel (Lore + PDC). */
    /** Legt eine verzauberte Zigarette in die PDC-Liste des Pack-ItemStacks. */
    public void pushPackCigarette(ItemStack pack, ItemStack cig) {
        if (pack == null || cig == null) return;
        ItemMeta meta = pack.getItemMeta();
        if (meta == null) return;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        // Vorhandene Liste lesen
        byte[] existing = pdc.getOrDefault(Keys.PACK_ITEM_LIST, PersistentDataType.BYTE_ARRAY, new byte[0]);
        byte[] cigBytes = cig.serializeAsBytes();
        // Format: [4-Byte-Länge][Daten][4-Byte-Länge][Daten]...
        byte[] lenBytes = java.nio.ByteBuffer.allocate(4).putInt(cigBytes.length).array();
        byte[] combined = new byte[existing.length + 4 + cigBytes.length];
        System.arraycopy(existing, 0, combined, 0, existing.length);
        System.arraycopy(lenBytes, 0, combined, existing.length, 4);
        System.arraycopy(cigBytes, 0, combined, existing.length + 4, cigBytes.length);
        pdc.set(Keys.PACK_ITEM_LIST, PersistentDataType.BYTE_ARRAY, combined);
        pack.setItemMeta(meta);
    }

    /** Entnimmt die zuletzt eingelegte Zigarette aus der PDC-Liste. Gibt null zurück wenn leer. */
    public ItemStack popPackCigarette(ItemStack pack) {
        if (pack == null) return null;
        ItemMeta meta = pack.getItemMeta();
        if (meta == null) return null;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        byte[] data = pdc.getOrDefault(Keys.PACK_ITEM_LIST, PersistentDataType.BYTE_ARRAY, new byte[0]);
        if (data.length < 4) return null;
        // Letzten Eintrag lesen (Stack = LIFO)
        java.nio.ByteBuffer buf = java.nio.ByteBuffer.wrap(data);
        java.util.List<byte[]> entries = new java.util.ArrayList<>();
        while (buf.remaining() >= 4) {
            int len = buf.getInt();
            if (len <= 0 || len > buf.remaining()) break;
            byte[] entry = new byte[len];
            buf.get(entry);
            entries.add(entry);
        }
        if (entries.isEmpty()) return null;
        byte[] last = entries.remove(entries.size() - 1);
        // Restliche Einträge zurückschreiben
        int totalLen = entries.stream().mapToInt(e -> 4 + e.length).sum();
        byte[] newData = new byte[totalLen];
        java.nio.ByteBuffer wb = java.nio.ByteBuffer.wrap(newData);
        for (byte[] e : entries) { wb.putInt(e.length); wb.put(e); }
        pdc.set(Keys.PACK_ITEM_LIST, PersistentDataType.BYTE_ARRAY, newData);
        pack.setItemMeta(meta);
        try {
            return ItemStack.deserializeBytes(last);
        } catch (Exception ex) {
            return null;
        }
    }

    public void setPackContents(ItemStack stack, int cigarettes) {
        if (!isPack(stack)) return;
        ItemMeta meta = stack.getItemMeta();
        if (!(meta instanceof LeatherArmorMeta lm)) return;
        int v = Math.max(0, Math.min(8, cigarettes));
        lm.getPersistentDataContainer().set(Keys.PACK_CIGS, PersistentDataType.INTEGER, v);

        CigaretteBrand brand = getBrand(stack);
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Inhalt: " + v + "/8").color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Platzieren als Block.").color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Linksklick: Zigarette entnehmen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Rechtsklick mit Zigarette: einzeln einlegen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sneak + Rechtsklick: Schachtel auffüllen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Sneak + Linksklick: Schachtel abbauen").color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lm.lore(lore);
        stack.setItemMeta(lm);
        // Brand bleibt gleich
    }

    /** Reduziert Haltbarkeit eines Feuerzeugs, gibt true zurück, wenn es zerbrochen ist. */
    public boolean damageLighter(ItemStack lighter) {
        if (!isLighter(lighter)) return false;
        ItemMeta meta = lighter.getItemMeta();
        if (!(meta instanceof Damageable dmg)) return false;
        int newDmg = dmg.getDamage() + 1;
        int max = lighter.getType().getMaxDurability();
        if (newDmg >= max) {
            lighter.setAmount(0);
            return true;
        }
        dmg.setDamage(newDmg);
        lighter.setItemMeta(meta);
        return false;
    }
}
