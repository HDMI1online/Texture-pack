package de.soos.smokeaddiction.task;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tickt jede Sekunde, um Heilkraut-Phasen-Übergänge (Buff-Ende, Withdrawal-Ende)
 * an den jeweiligen Spieler zu melden.
 */
public class HerbTickTask extends BukkitRunnable {

    private final SmokeAddictionPlugin plugin;

    public HerbTickTask(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            try {
                plugin.getHerbManager().tick(p);
            } catch (Exception ex) {
                plugin.getLogger().warning("Herb-Tick-Fehler für " + p.getName()
                        + ": " + ex.getMessage());
            }
        }
    }
}
