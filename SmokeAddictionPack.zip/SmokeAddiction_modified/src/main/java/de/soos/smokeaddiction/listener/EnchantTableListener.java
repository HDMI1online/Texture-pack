package de.soos.smokeaddiction.listener;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import de.soos.smokeaddiction.manager.EnchantmentManager;
import de.soos.smokeaddiction.manager.EnchantmentManager.EnchantType;
import de.soos.smokeaddiction.manager.ItemManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Custom-Enchant-GUI:
 *   - Rechtsklick auf Zaubertisch mit Cig/Joint/Elfbar in der Hand → öffnet 9-Slot-GUI
 *   - Im GUI werden verfügbare Enchants als Items angezeigt (mit Level-Cost)
 *   - Klick auf ein Enchant-Item: Levels werden vom Spieler abgezogen, Enchant aufs Item gesetzt
 */
public class EnchantTableListener implements Listener {

    private static final String GUI_TITLE = "§5Verzaubern";

    /** Speichert pro offenem GUI das zu verzaubernde Item (in der Haupthand). */
    private final Map<UUID, ItemStack> pendingItems = new HashMap<>();

    private final SmokeAddictionPlugin plugin;

    public EnchantTableListener(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.HIGH, ignoreCancelled = true)
    public void onClickTable(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() != Material.ENCHANTING_TABLE) return;

        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        ItemManager im = plugin.getItemManager();

        boolean isCig    = im.isCigarette(hand);
        boolean isVape   = im.isVape(hand) && !im.isFumot(hand) && !im.isVozol(hand) && !im.isRandm(hand); // nur Elfbar, kein Fumot/Vozol/Randm
        if (!isCig && !isVape) return;

        // Custom-GUI öffnen – SmokeListener soll NICHT feuern
        e.setCancelled(true);
        openEnchantGui(p, hand, isCig);
    }

    private void openEnchantGui(Player p, ItemStack item, boolean forCig) {
        Inventory inv = plugin.getServer().createInventory(null, 9,
                net.kyori.adventure.text.Component.text("Verzaubern",
                        NamedTextColor.DARK_PURPLE));

        if (forCig) {
            // 3 Munis-Stufen
            EnchantmentManager em = plugin.getEnchantmentManager();
            int currentLvl = em.getMunis(item);
            inv.setItem(1, makeEnchantOption(EnchantType.MUNIS, 1,  5, currentLvl));
            inv.setItem(3, makeEnchantOption(EnchantType.MUNIS, 2, 15, currentLvl));
            inv.setItem(5, makeEnchantOption(EnchantType.MUNIS, 3, 30, currentLvl));
            inv.setItem(7, infoIcon("Munis verkürzt die Rauchsession",
                    "§7I = 30s · II = 20s · III = 10s"));
        } else {
            // Vape-Enchants
            EnchantmentManager em = plugin.getEnchantmentManager();
            inv.setItem(2, makeEnchantOption(EnchantType.DURABILITY, 1, 15,
                    em.getDurability(item)));
            inv.setItem(4, makeEnchantOption(EnchantType.MORE_SMOKE, 1, 10,
                    em.getMoreSmoke(item)));
            inv.setItem(7, infoIcon("Vape-Verzauberungen",
                    "§7Haltbarkeit verdoppelt die Züge",
                    "§7Mehr Rauch = extreme Wolken"));
        }

        // Filler
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);
        for (int slot = 0; slot < 9; slot++) {
            if (inv.getItem(slot) == null) inv.setItem(slot, filler);
        }

        pendingItems.put(p.getUniqueId(), item);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 0.6f, 1.2f);
    }

    private ItemStack makeEnchantOption(EnchantType type, int targetLevel, int cost, int currentLvl) {
        Material icon = switch (type) {
            case MUNIS      -> Material.SUGAR;
            case DURABILITY -> Material.NETHERITE_INGOT;
            case MORE_SMOKE -> Material.WHITE_DYE;
        };
        ItemStack opt = new ItemStack(icon);
        ItemMeta m = opt.getItemMeta();
        boolean already = currentLvl >= targetLevel;

        m.displayName(Component.text(type.displayName + " " + roman(targetLevel))
                .color(already ? NamedTextColor.GRAY : NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        if (already) {
            lore.add(Component.text("Bereits verzaubert", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Kosten: " + cost + " Level", NamedTextColor.YELLOW)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Klicken zum Verzaubern", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        // Cost im PDC speichern, damit der Listener weiß wieviel abzuziehen ist
        m.getPersistentDataContainer().set(
                new org.bukkit.NamespacedKey(plugin, "ench_cost"),
                org.bukkit.persistence.PersistentDataType.INTEGER, cost);
        m.getPersistentDataContainer().set(
                new org.bukkit.NamespacedKey(plugin, "ench_type"),
                org.bukkit.persistence.PersistentDataType.STRING, type.name());
        m.getPersistentDataContainer().set(
                new org.bukkit.NamespacedKey(plugin, "ench_lvl"),
                org.bukkit.persistence.PersistentDataType.INTEGER, targetLevel);
        m.lore(lore);
        opt.setItemMeta(m);
        return opt;
    }

    private ItemStack infoIcon(String title, String... lines) {
        ItemStack book = new ItemStack(Material.BOOK);
        ItemMeta m = book.getItemMeta();
        m.displayName(Component.text(title, NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String l : lines) {
            lore.add(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacySection().deserialize(l)
                    .decoration(TextDecoration.ITALIC, false));
        }
        m.lore(lore);
        book.setItemMeta(m);
        return book;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        UUID uid = p.getUniqueId();
        if (!pendingItems.containsKey(uid)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) {
            // Klicks im Spieler-Inventar nicht canceln, aber auch nichts tun
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true);

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null) return;
        ItemMeta m = clicked.getItemMeta();
        if (m == null) return;

        org.bukkit.persistence.PersistentDataContainer pdc = m.getPersistentDataContainer();
        Integer cost = pdc.get(new org.bukkit.NamespacedKey(plugin, "ench_cost"),
                org.bukkit.persistence.PersistentDataType.INTEGER);
        String  typeName = pdc.get(new org.bukkit.NamespacedKey(plugin, "ench_type"),
                org.bukkit.persistence.PersistentDataType.STRING);
        Integer lvl = pdc.get(new org.bukkit.NamespacedKey(plugin, "ench_lvl"),
                org.bukkit.persistence.PersistentDataType.INTEGER);
        if (cost == null || typeName == null || lvl == null) return;

        EnchantType type = EnchantType.valueOf(typeName);
        ItemStack pending = pendingItems.get(uid);

        // Item noch in der Hand?
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!hand.equals(pending) && !hand.isSimilar(pending)) {
            p.sendMessage(Component.text("Item ist nicht mehr in deiner Hand.",
                    NamedTextColor.RED));
            p.closeInventory();
            return;
        }

        EnchantmentManager em = plugin.getEnchantmentManager();
        int current = switch (type) {
            case MUNIS      -> em.getMunis(hand);
            case DURABILITY -> em.getDurability(hand);
            case MORE_SMOKE -> em.getMoreSmoke(hand);
        };
        if (current >= lvl) {
            p.sendMessage(Component.text("Bereits verzaubert mit dieser oder höherer Stufe.",
                    NamedTextColor.GRAY));
            return;
        }
        if (p.getLevel() < cost) {
            p.sendMessage(Component.text("Du brauchst " + cost + " Level.",
                    NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            return;
        }

        // Anwenden
        p.setLevel(p.getLevel() - cost);
        em.apply(hand, type, lvl);
        p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.4f);
        p.sendMessage(Component.text("Verzaubert mit " + type.displayName + " " + roman(lvl) + "!",
                NamedTextColor.LIGHT_PURPLE));
        p.closeInventory();
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        pendingItems.remove(e.getPlayer().getUniqueId());
    }

    private String roman(int n) {
        switch (n) {
            case 1: return "I";
            case 2: return "II";
            case 3: return "III";
            default: return String.valueOf(n);
        }
    }
}
