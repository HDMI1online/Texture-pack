package de.soos.smokeaddiction.manager;

import de.soos.smokeaddiction.SmokeAddictionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Speichert die Block-Locations aller Herb-Bushes (im Gegensatz zu Tabak-Bushes,
 * die nicht registriert sind). So können wir beim Ernten/Brechen unterscheiden,
 * ob ein Sweet-Berry-Bush Tabak oder Herb ist – ohne ein zweites Vanilla-Material
 * zu nutzen.
 *
 * Speicher-Format: pro Welt eine Liste von "x,y,z"-Strings.
 */
public class HerbBushRegistry {

    private final SmokeAddictionPlugin plugin;
    private final File file;
    private final Set<String> entries = new HashSet<>();

    public HerbBushRegistry(SmokeAddictionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "herb_bushes.yml");
        load();
    }

    private static String key(World w, int x, int y, int z) {
        return w.getUID() + ":" + x + "," + y + "," + z;
    }
    private static String key(Location loc) {
        return key(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    private static String key(Block b) {
        return key(b.getWorld(), b.getX(), b.getY(), b.getZ());
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        List<String> list = cfg.getStringList("entries");
        entries.addAll(list);
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("entries", new ArrayList<>(entries));
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Konnte herb_bushes.yml nicht speichern: " + e.getMessage());
        }
    }

    public boolean isHerb(Block b) {
        return entries.contains(key(b));
    }

    public boolean isHerb(Location loc) {
        return entries.contains(key(loc));
    }

    public void register(Block b) {
        entries.add(key(b));
        // Performance: Ich speichere nicht bei jedem Add, nur regelmäßig (z.B. beim Quit/Disable)
    }

    public void register(Location loc) {
        entries.add(key(loc));
    }

    public void unregister(Block b) {
        entries.remove(key(b));
    }

    public void unregister(Location loc) {
        entries.remove(key(loc));
    }

    public int size() { return entries.size(); }
}
